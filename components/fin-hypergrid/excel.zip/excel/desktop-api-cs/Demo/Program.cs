﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Demo
{
    class Program
    {
        static void Main2(string[] args)
        {
            string json = @"{CPU: 'Intel', Drives: ['DVD read/writer','500 gigabyte hard drive']}";
            JObject o = JObject.Parse(json);
            var k = o.SelectToken("CPU").Value<string>();
            Console.WriteLine(k);

            JObject obj = new JObject();
            JObject obj2 = new JObject();
            JProperty p2 = new JProperty("P2", 100);
            obj2.Add(p2);
            JProperty p1 = new JProperty("P1", obj2);
            obj.Add(p1);
            Console.WriteLine(obj.ToString());

            JProperty p11 = new JProperty("P1", 200);
//            obj.Remove("P1");
//            obj.Add(p11);            
            JToken p1old = obj.SelectToken("P1");
            p1old.Replace(200);
            Console.WriteLine(obj.ToString());
            obj.Remove("P5");
            Console.WriteLine(obj.ToString());
        }
    }
}
