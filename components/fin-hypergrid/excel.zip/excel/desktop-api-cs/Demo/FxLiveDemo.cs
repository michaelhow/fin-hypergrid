﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Openfin.Desktop;

namespace Demo
{
    class DemoDesktopStateListener : DesktopStateListener
    {
        private DesktopConnection controller;
        private Application application;

        public DemoDesktopStateListener(DesktopConnection controller)
        {
            this.controller = controller;
        }

        private void processMessage(String sourceUuid, String topic, object message)
        {
            Console.WriteLine("processMessage: {0}", message);
        }

        private void ackCallback(Ack ack)
        {
            Console.WriteLine("ackCallback: {0}", ack.getJsonObject().ToString());
        }

        public void onReady()
        {


            Openfin.Desktop.Window dockWindow = Openfin.Desktop.Window.wrap("openchat-dev", "raman$openfin.co@openchat.co", controller);

            dockWindow.addEventListener("group-changed", (gPayload) => {
                Openfin.Desktop.Window.GroupChangedPayload payload = new Openfin.Desktop.Window.GroupChangedPayload(gPayload, controller); 
            });

            /*
            Console.WriteLine("Connection authorized.");

            controller.addExternalMessageHandler((resultHandler, payload) =>
            {
                resultHandler.send(true, "Workers");
                int a;
                a = 2;
            }, this);

            Console.WriteLine("Creating app...");
            ApplicationOptions options = new ApplicationOptions("ExternalClientUtils", "ExternalClientUtils", 
                            "https://developer.openf.in/externalclientutils/1.0.0.0b/");

            WindowOptions windowOptions = options.MainWindowOptions;

            System.
            options.Version = "v1.0.0.0b";
            options.IsAdmin = true;
            windowOptions.AutoShow = false;
            windowOptions.DefaultLeft = 60;
            windowOptions.DefaultTop = 60;
            windowOptions.DefaultHeight = 50;
            windowOptions.DefaultWidth = 50;
            windowOptions.State = "restored";
            windowOptions.Resizable = false;
            windowOptions.Frame = false;
            windowOptions.AlwaysOnBottom = false;
            windowOptions.ShowTaskbarIcon = false;
            windowOptions.Draggable = false;

            controller.getInterApplicationBus().subscribe("550e8400-e29b-41d4-a716-4466333333000", "EURUSD", processMessage);

            application = new Application(options, controller, ackCallback);		*/	
        }

        public void onError(String reason)
        {
            Console.WriteLine("onError onMessage: {0}", reason);
        }

        public void onMessage(String message)
        {
            Console.WriteLine("DemoDesktopStateListener onMessage: {0}", message);
        }

        public void onOutgoingMessage(String message)
        {
        }

        /// <summary>
        ///     Callback when the connection with the Desktop has closed.
        /// </summary>
        public void onClosed()
        {

        }
    
    }

    class FxLiveDemo
    {

        public void connect(int port)
        {
            DesktopConnection controller = new DesktopConnection("OpenFinDesktopCSharpDemo", "localhost", port);

            InterApplicationBus interAppBus = controller.getInterApplicationBus();

			DemoDesktopStateListener stateListner = new DemoDesktopStateListener(controller);

            controller.connect(stateListner);

            //String authorizationToken = "7feb24af-fc38-44de-bc38-04defc3804de";
            //controller.launchDesktopAndConnect(@"c:\Program Files (x86)\OpenFin Desktop", "", authorizationToken, stateListner, 10000);

            controller.joinWebSocketThread();

        }

        static void Main(string[] args)
        {
            int port = 9696;
            if (args.Length >= 1)
            {
                port = Convert.ToInt32(args[0]);
            } else {
                Console.WriteLine("Missing port# ");
            }

            Console.WriteLine("Starting Demo at port {0} ", port);
            FxLiveDemo demo = new FxLiveDemo();
            demo.connect(port);
        }
    }
}
