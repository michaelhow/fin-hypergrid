﻿/*
 * File ExternalWindow.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Delegate for consuming external messages targeted at an application originating from HTTP/HTTPS.
    /// </summary>
    /// <param name="resultHandler">Sends the result status to the container</param>
    /// <param name="payload">The JSON sent via HTTP/HTTPS</param>
    public delegate void ExternalMessageHandlerDelegate(ExternalMessageResultHandler resultHandler, JObject payload);

    /// <summary>
    ///     Interface for handling the result status and message from ExternalMessageResultHandler.send()
    /// </summary>
    internal interface IExternalMessageResultDispatcher
    {
        /// <summary>
        ///     Invoked by ExternalMessageResultHandler.send()
        /// </summary>
        /// <param name="id">The UUID of the ExternalMessageResultHandler the result came from</param>
        /// <param name="result">true for success, false for failure.</param>
        /// <param name="message">A string response to be sent back over HTTP/HTTPS</param>
        bool handleResult(String id, bool result, String message);
    }

    /// <summary>
    ///     Utility class to communicate results from calls to an ExternalMessageHandlerDelegate back to the AppDesktop.
    /// </summary>
    public class ExternalMessageResultHandler : IDisposable
    {
        IExternalMessageResultDispatcher dispatcher_;   // The dispatcher is notified in resposne to send()
        String id_ = Guid.NewGuid().ToString();         // A UUID generated for every instance of ExternalMessageResultHandler
        bool sent_ = false;                             // Ensures that dispatcher_ is not notified more than once for results from send()

        internal ExternalMessageResultHandler(IExternalMessageResultDispatcher dispatcher)
        {
            dispatcher_ = dispatcher;
        }

        /// <summary>
        ///     A unique identifier for every instance of ExternalMessageResultHandler.
        /// </summary>
        public String ID {
            get 
            {
                return id_;
            }
        }

        /// <summary>
        ///     Will call send() if not done so already.
        /// </summary>
        public void Dispose()
        {
            // Default to success if not handled
            send(true, "");
        }

        /// <summary>
        ///     Record the result of an ExternalMessageHandlerDelegate to be sent back to the AppDesktop.
        /// </summary>
        /// <param name="result">true for success, false for failure.</param>
        /// <param name="message">A string response to be sent back over HTTP/HTTPS</param>
        public bool send(bool result, String message) {
            bool didSend = false;
            if(!sent_) {
                sent_ = true;
                didSend = dispatcher_.handleResult(ID, result, message);
            }

            return didSend;
        }
    }
}
