﻿/*
 * File Notification.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A Notification represents a window on App Desktop which is shown briefly 
    ///     to the user on the bottom-right corner of the primary monitor. 
    ///     <para>
    ///         A notification is typically used to alert the user of some important event 
    ///         which requires his or her attention.
    ///     </para>
    /// </summary>
    /// <remarks>
    ///     Multiple notifications can be generated at once but will queue if more 
    ///     than 5 are already displayed. Notifications can be dismissed by dragging 
    ///     them to the right with the mouse and can communicate securely with their 
    ///     invoking applications.
    /// </remarks>
    public class Notification
    {
        private DesktopConnection desktopConnection_;
        private readonly uint id_ = 0;
        private JObject closePayload_ = null;
        private JObject sendMessagePayload_ = null;


        /// <summary>
        ///     Notification Constructor.
        /// </summary>
        /// <param name="options">The options of the notification.<see cref="NotificationOptions"/></param>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        /// <param name="callback">A function that is called if the method succeeds.</param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails. 
        ///     The reason for failure is passed as an argument.
        /// </param>
        public Notification(NotificationOptions options, 
                            DesktopConnection desktopConnection, 
                            AckCallback callback = null, 
                            AckCallback errorCallback = null)
        {
            desktopConnection_ = desktopConnection;
            if (options != null)
            {
                id_ = desktopConnection_.registerNotificationCallbacks(options, this);
                if(id_ > 0) 
                {
                    JObject payload = new JObject();
                    DesktopUtils.updateJSONValue(payload, "url", options.URL);
                    DesktopUtils.updateJSONValue(payload, "notificationId", id_);
                    DesktopUtils.updateJSONValue(payload, "message", options.Message);
                    if (options.Timeout > -1)
                    {
                        DesktopUtils.updateJSONValue(payload, "timeout", options.Timeout);
                    }
                    else
                    {
                        DesktopUtils.updateJSONValue(payload, "timeout", "never");
                    }

                    desktopConnection_.sendActionToNotificationsCenter("create-notification", payload, callback, errorCallback, this);
                }
            }
        }

        /// <summary>
        ///     Closes the notification.
        /// </summary>
        /// <param name="callback">A function that is called if the method succeeds.</param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails. 
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void close(AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (closePayload_ == null)
            {
                closePayload_ = new JObject();
                DesktopUtils.updateJSONValue(closePayload_, "notificationId", id_);
            }
            desktopConnection_.sendActionToNotificationsCenter("close-notification", closePayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Sends a message to the notification.
        /// </summary>
        /// <param name="message">The JSON message to be sent to the notification.</param>
        /// <param name="callback">A function that is called if the method succeeds.</param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails. 
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// 
        public void sendMessage(JObject message, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (sendMessagePayload_ == null)
            {
                sendMessagePayload_ = new JObject();
                DesktopUtils.updateJSONValue(sendMessagePayload_, "notificationId", id_);
            }
            DesktopUtils.updateJSONValue(sendMessagePayload_, "message", message);
            desktopConnection_.sendActionToNotificationsCenter("send-notification-message", sendMessagePayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Sends a message from the notification to the application that 
        ///     created the notification. The message is handled by the 
        ///     notification's onMessage callback.
        /// </summary>
        /// <param name="message">The JSON message to be sent to the notification.</param>
        /// <param name="callback">A function that is called if the method succeeds.</param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails. 
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void sendMessageToApplication(JObject message, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (sendMessagePayload_ == null)
            {
                sendMessagePayload_ = new JObject();
                DesktopUtils.updateJSONValue(sendMessagePayload_, "notificationId", id_);
            }
            DesktopUtils.updateJSONValue(sendMessagePayload_, "message", message);
            desktopConnection_.sendActionToNotificationsCenter("send-application-message", sendMessagePayload_, callback, errorCallback, this);
        }
    }
}
