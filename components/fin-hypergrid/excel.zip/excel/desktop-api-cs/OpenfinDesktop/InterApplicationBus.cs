﻿/*
 * File InterApplicationBus.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A delegate that handles all sent/published messages.
    /// </summary>
    public delegate void InterAppMessageHandler(String sourceUuid, String topic, object message);

    /// <summary>
    ///     A delegate that handles (un)subscription events on a 
    ///     DesktopConnection's InterApplicationBus.
    /// </summary>
    public delegate void InterAppSubscriptionListener(String uuid, String topic);

    /// <summary>
    ///     A messaging bus that allows for pub / sub messaging between different applications.
    ///     Available via getInterApplicationBus() method on DesktopConnection
    /// </summary>
    public class InterApplicationBus
    {
        private DesktopConnection desktopConnection;
        private Dictionary<String, Dictionary<String, LinkedList<InterAppMessageHandler>>> callbackMap;
        private LinkedList<InterAppSubscriptionListener> subscribeCallbacks;
        private LinkedList<InterAppSubscriptionListener> unsubscribeCallbacks;

        /// <summary>InterApplicationBus Constructor</summary>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        public InterApplicationBus(DesktopConnection desktopConnection)
        {
            callbackMap = new Dictionary<String, Dictionary<String, LinkedList<InterAppMessageHandler>>>();
            subscribeCallbacks = new LinkedList<InterAppSubscriptionListener>();
            unsubscribeCallbacks = new LinkedList<InterAppSubscriptionListener>();
            this.desktopConnection = desktopConnection;
        }

        /// <summary>
        ///     Registers a listener which is called whenever a subscription occurs.
        /// </summary>
        /// <param name="listener">
        ///     A function that is called whenever a subscription occurs.
        ///     It is passed the topic and application UUID that trigered the event.
        /// </param>
        public void addSubscribeListener(InterAppSubscriptionListener listener)
        {
            subscribeCallbacks.AddLast(listener);
        }

        /// <summary>
        ///     Registers a listener which is called whenever an unsubscription occurs.
        /// </summary>
        /// <param name="listener">
        ///     A function that is called whenever a unsubscription occurs.
        ///     It is passed the topic and application UUID that trigered the event.
        /// </param>
        public void addUnsubscribeListener(InterAppSubscriptionListener listener)
        {
            unsubscribeCallbacks.AddLast(listener);
        }

        /// <summary>
        ///     Dispatches a messages to listeners
        /// </summary>
        /// <param name="sourceUuid">UUID of the application from which messages are sent.</param>
        /// <param name="topic">Topic to which the mssage is published.</param>
        /// <param name="message">The JSON message to be dispatched</param>
        public void dispatchMessageToCallbacks(String sourceUuid, String topic, Object message)
        {
            // Handle wildcard subscription
            Dictionary<String, LinkedList<InterAppMessageHandler>> cbByTopic;
            if (callbackMap.TryGetValue("*", out cbByTopic))
            {
                LinkedList<InterAppMessageHandler> cbList;
                if (cbByTopic.TryGetValue(topic, out cbList))
                {
                    foreach (InterAppMessageHandler cb in cbList)
                    {
                        cb(sourceUuid, topic, message);
                    }
                }
            }

            // Handle UUID specific
            cbByTopic = null;
            if (callbackMap.TryGetValue(sourceUuid, out cbByTopic))
            {
                LinkedList<InterAppMessageHandler> cbList;
                if (cbByTopic.TryGetValue(topic, out cbList))
                {
                    foreach (InterAppMessageHandler cb in cbList)
                    {
                        cb(sourceUuid, topic, message);
                    }
                }
            }
        }

        /// <summary>
        ///     Dispatches to subscription listeners
        /// </summary>
        /// <param name="uuid">The subscribing application.</param>
        /// <param name="topic">The topic that was subscribed to.</param>
        public void dispatchToSubscribeListeners(String uuid, String topic)
        {
            foreach (InterAppSubscriptionListener callback in subscribeCallbacks)
            {
                callback(uuid, topic);
            }
        }

        /// <summary>
        ///     Dispatches to unsubscription listeners
        /// </summary>
        /// <param name="uuid">The unsubscribing application.</param>
        /// <param name="topic">The topic that was unsubscribed from.</param>
        public void dispatchToUnsubscribeListeners(String uuid, String topic)
        {
            foreach (InterAppSubscriptionListener callback in unsubscribeCallbacks)
            {
                callback(uuid, topic);
            }
        }

        /// <summary>
        ///     Retrieves the callback list associated with the passed UUID and topic.
        ///     <para>This method inserts empty entries if none are found.</para>
        /// </summary>
        /// <param name="uuid">The application from which messages are communicated with.</param>
        /// <param name="topic">The topic that is being communicated on.</param>
        private LinkedList<InterAppMessageHandler> getCallbackList(String uuid, String topic)
        {
            LinkedList<InterAppMessageHandler> cbList = null;

            Dictionary<String, LinkedList<InterAppMessageHandler>> cbByTopic;
            if (!callbackMap.TryGetValue(uuid, out cbByTopic))
            {
                cbByTopic = new Dictionary<String, LinkedList<InterAppMessageHandler>>();
                callbackMap[uuid] = cbByTopic;
            }

            if (!cbByTopic.TryGetValue(topic, out cbList))
            {
                cbList = new LinkedList<InterAppMessageHandler>();
                cbByTopic[topic] = cbList;
            }

            return cbList;
        }

        /// <summary>
        ///     Publishes a message to a topic
        /// </summary>
        /// <param name="topic">The topic to which the message is published.</param>
        /// <param name="message">the JSON message to publish.</param>
        public void publish(String topic, JObject message)
        {
            JObject payload = new JObject();

            try
            {
                DesktopUtils.updateJSONValue(payload, "topic", topic);
                if (message != null)
                {
                    DesktopUtils.updateJSONValue(payload, "message", message);
                }
                else
                {
                    DesktopUtils.updateJSONValue(payload, "message", new JObject());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            desktopConnection.sendAction("publish-message", payload);
        }

        /// <summary>
        ///     Removes the passed listener. 
        ///     It is no longer called for subscription events.
        /// </summary>
        /// <param name="listener">The listener to remove.</param>
        public void removeSubscribeListener(InterAppSubscriptionListener listener)
        {
            subscribeCallbacks.Remove(listener);
        }

        /// <summary>
        ///     Removes the passed listener. 
        ///     It is no longer called for unsubscription events.
        /// </summary>
        /// <param name="listener">The listener to remove.</param>
        public void removeUnsubscribeListener(InterAppSubscriptionListener listener)
        {
            unsubscribeCallbacks.Remove(listener);
        }

        /// <summary>
        ///     Sends a message to an application
        /// </summary>
        /// <param name="destinationUuid">UUID of the application from which messages are sent.</param>
        /// <param name="topic">The topic to which the message is published.</param>
        /// <param name="message">The JSON message to publish.</param>
        public void send(String destinationUuid, String topic, JObject message)
        {
            JObject payload = new JObject();

            try
            {
                DesktopUtils.updateJSONValue(payload, "destinationUuid", destinationUuid);
                DesktopUtils.updateJSONValue(payload, "topic", topic);
                if (message != null)
                {
                    DesktopUtils.updateJSONValue(payload, "message", message);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            desktopConnection.sendAction("send-message", payload);
        }

        /// <summary>
        ///     Subscribes to messages on the specified topic
        /// </summary>
        /// <param name="senderUuid">UUID of the application</param>
        /// <param name="topic">The topic to be subscribed to.</param>
        /// <param name="listener">
        ///     The listener that is to be passed messages on the specified topic
        /// </param>
        public void subscribe(String senderUuid, String topic, InterAppMessageHandler listener)
        {
            LinkedList<InterAppMessageHandler>  cbList = getCallbackList(senderUuid, topic);
            cbList.AddLast(listener);

            JObject payload = new JObject();
            DesktopUtils.updateJSONValue(payload, "sourceUuid", senderUuid);
            DesktopUtils.updateJSONValue(payload, "topic", topic);
            desktopConnection.sendAction("subscribe", payload);
        }

        /// <summary>
        ///     Unsubscribes to messages on the specified topic.
        /// </summary>
        /// <param name="sourceUuid">UUID of the application from which messages are sent.</param>
        /// <param name="topic">The topic to be unsubscribed from.</param>
        /// <param name="listener">
        ///     The listener that will be removed and no longer passed messages on the topic.
        /// </param>
        public void unsubscribe(String sourceUuid, String topic, InterAppMessageHandler listener)
        {
            LinkedList<InterAppMessageHandler> cbList = getCallbackList(sourceUuid, topic);
            cbList.Remove(listener);

            JObject payload = new JObject();
            DesktopUtils.updateJSONValue(payload, "sourceUuid", sourceUuid);
            DesktopUtils.updateJSONValue(payload, "topic", topic);
            desktopConnection.sendAction("unsubscribe", payload);
        }
    }
}
