﻿/*
 * File AnimationTransitions.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A base class representing a transition of the window.
    /// </summary>
    public abstract class IAnimationTransition
    {
        private JObject options_ = new JObject();

        /// <summary>
        ///     The Raw property represents the underliying 
        ///     JObject containing the transition's settings.
        /// </summary> 
        /// <value>
        ///     The Raw property gets/sets the value of the underlying JObject.
        /// </value> 
        public JObject Raw
        {
            get { return options_; }
        }
    }

    /// <summary>
    ///     A class representing a transition of a Window's opacity.
    /// </summary>
    public class OpacityTransition : IAnimationTransition
    {
        /// <summary>
        ///     The Opacity property represents the resulting opacity of the window.
        ///     <para>This value is clamped beween 0.0 and 1.0</para>
        ///     <para>Default: 1.0</para>
        /// </summary> 
        /// <value>
        ///     The Opacity property gets/sets the value of the underlying 
        ///     JObject field, "opacity".
        /// </value> 
        public double Opacity
        {
            get { return DesktopUtils.getJSON<double>(Raw, "opacity", 1.0); }
            set { DesktopUtils.updateJSONValue(Raw, "opacity", Math.Max(0.0, Math.Min(1.0, value))); }
        }

        /// <summary>
        ///     The Duration property represents the total time in milliseconds
        ///     for the transition to complete.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Duration property gets/sets the value of the underlying 
        ///     JObject field, "duration".
        /// </value>
        public int Duration
        {
            get { return DesktopUtils.getJSON<int>(Raw, "duration", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "duration", value); }
        }

        /// <summary>
        ///     Constructs an empty instance.
        /// </summary>
        public OpacityTransition() { }

        /// <summary>
        ///     Constructs an instance setting all the properties.
        /// </summary>
        /// <param name="opacity">The resulting opacity of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public OpacityTransition(double opacity, int duration)
        {
            Opacity = opacity;
            Duration = duration;
        }
    }

    /// <summary>
    ///     A class representing a transition of a Window's dimensions.
    /// </summary>
    public class SizeTransition : IAnimationTransition
    {
        /// <summary>
        ///     The Width property represents the resulting width of the window.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Width property gets/sets the value of the underlying 
        ///     JObject field, "width".
        /// </value> 
        public int Width
        {
            get { return DesktopUtils.getJSON<int>(Raw, "width", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "width", value); }
        }

        /// <summary>
        ///     The Height property represents the resulting height of the window.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Height property gets/sets the value of the underlying 
        ///     JObject field, "height".
        /// </value> 
        public int Height
        {
            get { return DesktopUtils.getJSON<int>(Raw, "height", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "height", value); }
        }

        /// <summary>
        ///     The Duration property represents the total time in milliseconds
        ///     for the transition to complete.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Duration property gets/sets the value of the underlying 
        ///     JObject field, "duration".
        /// </value>
        public int Duration
        {
            get { return DesktopUtils.getJSON<int>(Raw, "duration", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "duration", value); }
        }

        /// <summary>
        ///     Constructs an empty instance.
        /// </summary>
        public SizeTransition() { }

        /// <summary>
        ///     Constructs an instance setting all the properties.
        /// </summary>
        /// <param name="width">The resulting width of the window.</param>
        /// <param name="height">The resulting height of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public SizeTransition(int width, int height, int duration)
        {
            Width = width;
            Height = height;
            Duration = duration;
        }

        /// <summary>
        ///     Constructs an instance that only transitions the Window's width.
        /// </summary>
        /// <param name="width">The resulting width of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public static SizeTransition onlyWidth(int width, int duration)
        {
            SizeTransition transition = new SizeTransition();
            transition.Width = width;
            transition.Duration = duration;
            return transition;
        }

        /// <summary>
        ///     Constructs an instance that only transitions the Window's height.
        /// </summary>
        /// <param name="height">The resulting height of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public static SizeTransition onlyHeight(int height, int duration)
        {
            SizeTransition transition = new SizeTransition();
            transition.Height = height;
            transition.Duration = duration;
            return transition;
        }
    }

    /// <summary>
    ///     A class representing a transition of a Window's position.
    /// </summary>
    public class PositionTransition : IAnimationTransition
    {
        /// <summary>
        ///     The Left property represents the resulting left position of the window.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Left property gets/sets the value of the underlying 
        ///     JObject field, "left".
        /// </value> 
        public int Left
        {
            get { return DesktopUtils.getJSON<int>(Raw, "left", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "left", value); }
        }

        /// <summary>
        ///     The Top property represents the resulting top position of the window.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Top property gets/sets the value of the underlying 
        ///     JObject field, "top".
        /// </value>
        public int Top
        {
            get { return DesktopUtils.getJSON<int>(Raw, "top", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "top", value); }
        }

        /// <summary>
        ///     The Duration property represents the total time in milliseconds
        ///     for the transition to complete.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The Duration property gets/sets the value of the underlying 
        ///     JObject field, "duration".
        /// </value>
        public int Duration
        {
            get { return DesktopUtils.getJSON<int>(Raw, "duration", 0); }
            set { DesktopUtils.updateJSONValue(Raw, "duration", value); }
        }

        /// <summary>
        ///     Constructs an empty instance.
        /// </summary>
        public PositionTransition() { }

        /// <summary>
        ///     Constructs an instance setting all the properties.
        /// </summary>
        /// <param name="left">The resulting left position of the window.</param>
        /// <param name="top">The resulting top position of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public PositionTransition(int left, int top, int duration)
        {
            Left = left;
            Top = top;
            Duration = duration;
        }

        /// <summary>
        ///     Constructs an instance that only transitions the Window's left position.
        /// </summary>
        /// <param name="left">The resulting left position of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public static PositionTransition onlyLeft(int left, int duration)
        {
            PositionTransition transition = new PositionTransition();
            transition.Left = left;
            transition.Duration = duration;
            return transition;
        }

        /// <summary>
        ///     Constructs an instance that only transitions the Window's top position.
        /// </summary>
        /// <param name="top">The resulting top position of the window.</param>
        /// <param name="duration">
        ///     The total time in milliseconds for the transition to complete.
        /// </param>
        public static PositionTransition onlyTop(int top, int duration)
        {
            PositionTransition transition = new PositionTransition();
            transition.Top = top;
            transition.Duration = duration;
            return transition;
        }
    }

    /// <summary>
    ///     A class representing a collection of transitions for a Window animation.
    /// </summary>
    public class AnimationTransitions
    {
        private OpacityTransition opacity_;
        private SizeTransition size_;
        private PositionTransition position_;

        /// <summary>
        ///     Helper utility for determining if an underliying transition contains configured data.
        /// </summary>
        private bool isTransitionEmpty(IAnimationTransition transition)
        {
            return transition == null || transition.Raw == null || transition.Raw.Count == 0;
        }

        /// <summary>
        ///     Returns all the underliying transitions as one JObject.
        /// </summary>
        public JObject ToJObject()
        {
            JObject container = new JObject();

            if (!isTransitionEmpty(Opacity))
            {
                DesktopUtils.updateJSONValue(container, "opacity", Opacity.Raw); 
            }

            if (!isTransitionEmpty(Size))
            {
                DesktopUtils.updateJSONValue(container, "size", Size.Raw);
            }

            if (!isTransitionEmpty(Position))
            {
                DesktopUtils.updateJSONValue(container, "position", Position.Raw);
            }

            return container;
        }

        /// <summary>
        ///     The Opacity property represents a transition of the Window's opacity.
        /// </summary> 
        /// <value>
        ///     The Opacity property gets/sets the value of the internal OpacityTransition. 
        /// </value> 
        public OpacityTransition Opacity
        {
            get { return opacity_; }
            set { opacity_ = value; }
        }

        /// <summary>
        ///     The Size property represents a transition of the Window's dimensions.
        /// </summary> 
        /// <value>
        ///     The Size property gets/sets the value of the internal SizeTransition. 
        /// </value> 
        public SizeTransition Size
        {
            get { return size_; }
            set { size_ = value; }
        }

        /// <summary>
        ///     The Position property represents a transition of the Window's position.
        /// </summary> 
        /// <value>
        ///     The Position property gets/sets the value of the internal PositionTransition. 
        /// </value> 
        public PositionTransition Position
        {
            get { return position_; }
            set { position_ = value; }
        }
    }
}
