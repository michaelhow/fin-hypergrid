﻿/*
 * File DesktopConnection.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
#if SILVERLIGHT
using System.Runtime.InteropServices.Automation;
#else
#endif

using Newtonsoft.Json.Linq;
using SuperSocket.ClientEngine;
using WebSocket4Net;

namespace Openfin.Desktop
{
    using ExternalMessageHandlerSourcePair = CallbackSourcePair<ExternalMessageHandlerDelegate>;
    using ListenerSourcePair = CallbackSourcePair<AckCallback>;

    /// <summary>
    ///     Creates a pairing between CallbackType and an object on construction.
    /// </summary>
    /// <typeparam name="CallbackType">The object type to store on construction and retrieve with getCallback().</typeparam>
    internal struct CallbackSourcePair<CallbackType>
    {
        private CallbackType callback_;
        private Object source_;

        /// <summary>
        ///     Constructs a pairing between the callback and source
        /// </summary>
        /// <param name="callback">Object to return via getCallback()</param>
        /// <param name="source">Object to return via getSource()</param>
        public CallbackSourcePair(CallbackType callback, Object source)
        {
            callback_ = callback;
            source_ = source;
        }

        /// <summary>
        ///     Accessor for the stored source.
        /// </summary>
        public Object getSource()
        {
            return source_;
        }

        /// <summary>
        ///     Accessor for the stored callback.
        /// </summary>
        /// <returns></returns>
        public CallbackType getCallback()
        {
            return callback_;
        }
    }

    /// <summary>
    ///     C# API binding for the OpenFin App Desktop.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }

    /// <summary>
    ///     Delegate for receiving Ack's from AppDesktop
    /// </summary>
    public delegate void AckCallback(Ack ack);

    /// <summary>
    ///     An object for launching, connecting to, and controlling AppDesktop.
    /// </summary>
    public class DesktopConnection : DesktopStateListener, IDisposable
    {
        private Dictionary<long, ListenerSourcePair[]> callbacks;
        private WebSocket websocket;
        private JObject jsonMsg;
        private bool connected = false;     // connected to desktop with authorization response
        //private bool opened = false;		// websocket to desktop is open
        private bool disconnecting = false;
        private String uuid, host, desktopURL;
        private String path = "";
        private int port;   // desktop port number
        private int desktopConnectTimeout;   // in seconds
        private long messageId = 0;
        private DesktopStateListener listener;
        private InterApplicationBus busInstance;
        private String authorizationAction, authorizationToken, authorizationType;
        private Thread websocketThread, desktopCmdThread;
        private bool pingedBefore = false;
        private uint notificationCount_ = 1;
        private JObject notificationPayload_ = null;
        private ExternalWindow externalWindow_ = null;

        // A collection of ExternalMessageHandlerDelegates to process messages received via "process-external-message"
        private List<ExternalMessageHandlerSourcePair> externalMessageHandlers_ = new List<ExternalMessageHandlerSourcePair>();

        // Event listeners registered for a notification object.
        private Dictionary<uint, Dictionary<string, ListenerSourcePair>> notificationEventCallbackMap = new Dictionary<uint, Dictionary<string, ListenerSourcePair>>();

        // <Topic, <Event, <Subscriber UUID, Collection of Callbacks>>>
        private Dictionary<String, Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>> applicationEventCallbackMap = new Dictionary<String, Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>>();

        // <Topic, <Event, Collection of Callbacks>>
        private Dictionary<String, Dictionary<String, List<ListenerSourcePair>>> systemEventCallbackMap = new Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>();

        // <Topic, <Event, <Subscriber UUID, Window name, Collection of Callbacks>>>
        private Dictionary<String, Dictionary<String, Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>>> windowEventCallbackMap = new Dictionary<String, Dictionary<String, Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>>>();

        /// <summary>
        ///     The MessageTrace property controls additional console logging.
        /// </summary>
        public Boolean MessageTrace { set; get; }


        /// <summary>
        ///     Terminates the connection to the AppDesktop when disposed.
        /// </summary>
        public void Dispose()
        {
            disconnect();
        }

        /// <summary>
        ///     Creates a new connection to AppDesktop
        /// </summary>
        /// <param name="uuid">A unique ID for AppDesktop to refer to this DesktopConnection</param>
        /// <param name="host">The host that AppDesktop is running on.</param>
        /// <param name="port">The port that AppDesktop is listening on for connections.</param>
        /// <param name="externalWindow">Interface to carry out this connection's window interaction</param>
        public DesktopConnection(String uuid, String host, int port, ExternalWindow externalWindow = null)
        {
            this.uuid = uuid;
            this.host = host == null ? "127.0.0.1" : host;
            this.port = port;
            callbacks = new Dictionary<long, ListenerSourcePair[]>();
            jsonMsg = new JObject();
            MessageTrace = false;
            externalWindow_ = externalWindow;
        }

        /// <summary>
        ///     Gets the Inter-Application message dispatcher associated with 
        ///     this DesktopConnection.
        /// </summary>
        public InterApplicationBus getInterApplicationBus()
        {
            if (connected)
            {
                if (busInstance == null)
                {
                    busInstance = new InterApplicationBus(this);
                }
                return busInstance;
            }
            else
            {
                return null;
            }
        }

        private List<ListenerSourcePair> getCallbackList(JObject subscriptionObject)
        {
            String topic = DesktopUtils.getJSON<String>(subscriptionObject, "topic", "");
            String type = getFullEventType(topic, DesktopUtils.getJSON<String>(subscriptionObject, "type", ""));
            String uuid = DesktopUtils.getJSON<String>(subscriptionObject, "uuid", null);
            String name = DesktopUtils.getJSON<String>(subscriptionObject, "name", null);
            return getCallbackList(topic, type, uuid, name);
        }

        private List<ListenerSourcePair> getCallbackList(String topic, String type, String uuid = null, String name = null)
        {
            List<ListenerSourcePair> callbacks = null;

            if(topic != null && type != null)
            {
                switch (topic)
                {
                    case "application":
                        {
                            if (uuid != null)
                            {
                                Dictionary<String, Dictionary<String, List<ListenerSourcePair>>> matchedTopic = null;
                                applicationEventCallbackMap.TryGetValue(topic, out matchedTopic);
                                if (matchedTopic == null)
                                {
                                    matchedTopic = new Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>();
                                    applicationEventCallbackMap[topic] = matchedTopic;  
                                }

                                Dictionary<String, List<ListenerSourcePair>> matchedType = null;
                                matchedTopic.TryGetValue(type, out matchedType);
                                if (matchedType == null)
                                {
                                    matchedType = new Dictionary<String, List<ListenerSourcePair>>();
                                    matchedTopic[type] = matchedType; 
                                }

                                matchedType.TryGetValue(uuid, out callbacks);
                                if (callbacks == null)
                                {
                                    callbacks = new List<ListenerSourcePair>();
                                    matchedType[uuid] = callbacks;
                                }
                            }
                        }
                        break;

                    case "system":
                        {
                            Dictionary<String, List<ListenerSourcePair>> matchedTopic = null;
                            systemEventCallbackMap.TryGetValue(topic, out matchedTopic);
                            if(matchedTopic == null)
                            {
                                matchedTopic = new Dictionary<String, List<ListenerSourcePair>>();
                                systemEventCallbackMap[topic] = matchedTopic;
                            }

                            matchedTopic.TryGetValue(type, out callbacks);
                            if (callbacks == null)
                            {
                                callbacks = new List<ListenerSourcePair>();
                                matchedTopic[type] = callbacks;
                            }
                        }
                        break;

                    case "window":
                        if (uuid != null && name != null)
                        {
                            Dictionary<String, Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>> matchedTopic = null;
                            windowEventCallbackMap.TryGetValue(topic, out matchedTopic);
                            if(matchedTopic == null)
                            {
                                matchedTopic = new Dictionary<String, Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>>();
                                windowEventCallbackMap[topic] = matchedTopic;
                            }

                            Dictionary<String, Dictionary<String, List<ListenerSourcePair>>> matchedType = null;
                            matchedTopic.TryGetValue(type, out matchedType);
                            if(matchedType == null)
                            {
                                matchedType = new Dictionary<String, Dictionary<String, List<ListenerSourcePair>>>(); 
                                matchedTopic[type] = matchedType;
                            }

                            Dictionary<String, List<ListenerSourcePair>> matchedUuid = null;
                            matchedType.TryGetValue(uuid, out matchedUuid);
                            if(matchedUuid == null)
                            {
                                matchedUuid = new Dictionary<String, List<ListenerSourcePair>>();
                                matchedType[uuid] = matchedUuid;
                            }

                            matchedUuid.TryGetValue(name, out callbacks);
                            if (callbacks == null)
                            {
                                callbacks = new List<ListenerSourcePair>();
                                matchedUuid[name] = callbacks;
                            }
                        }
                        break;
                    default:
                        callbacks = null;
                        break;
                }
            }

            return callbacks;
        }

        /// <summary>
        ///     Removes a previously registered event listener from the specified event.
        ///     <para>
        ///         The listener is passed an event object containing information 
        ///         related to the event.
        ///     </para>
        /// </summary>
        /// <param name="subscriptionObject">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that was called whenever an event of the specified type occurs.
        ///     It is no longer called in response to an event of the passed type.
        /// </param>
        /// <param name="callback">
        ///     A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// <param name="source">
        ///     The object that originally registered the listener.
        /// </param>
        public void removeEventCallback(JObject subscriptionObject,
                                        AckCallback listener,
                                        AckCallback callback,
                                        AckCallback errorCallback,
                                        Object source)
        {
            List<ListenerSourcePair> callbacks = getCallbackList(subscriptionObject);
            if (callbacks != null)
            {
                int index = callbacks.FindIndex((ListenerSourcePair sp) => {
                    return Delegate.Equals(sp.getCallback(), listener) && Object.ReferenceEquals(sp.getSource(), source);
                            });

                if (index != -1)
                {
                    callbacks.RemoveAt(index);

                    // Notify core if no subscriptions remain
                    if (callbacks.Count == 0)
                    {
                        sendAction("unsubscribe-to-desktop-event", subscriptionObject, callback, errorCallback, source);
                    }
                }
            }
        }

        private String getFullEventType(String topic, String type)
        {
            String fullType;

            switch(topic) 
            {
                case "application":
                    fullType = (type.IndexOf("application-") == -1) ? ("application-" + type) : type;
                    break;
                case "system":
                    fullType = type;
                    break;
                case "window":
                    fullType = (type.IndexOf("window-") == -1) ? ("window-" + type) : type;
                    break;
                default:
                    fullType = type;
                    break;
            }

            return fullType;
        }

        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <param name="subscriptionObject">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// <param name="source">
        ///     The message source to pair with resulting instances of AckCallback.
        /// </param>
        public void addEventCallback(JObject subscriptionObject, 
                                     AckCallback listener,  
                                     AckCallback callback, 
                                     AckCallback errorCallback, 
                                     Object source)
        {
            List<ListenerSourcePair> callbacks = getCallbackList(subscriptionObject);
            if (callbacks != null)
            {
                // Notify core of first subscription
                if (callbacks.Count == 0)
                {
                    sendAction("subscribe-to-desktop-event", subscriptionObject, callback, errorCallback, source);    
                }

                callbacks.Add(new ListenerSourcePair(listener, source));
            }
        }

        /// <summary>
        ///     Sends a message to AppDesktop.
        /// </summary>
        /// <param name="action">The action of the message.</param>
        /// <param name="payload">The message object to send.</param>
        public void sendAction(String action, JObject payload)
        {
            DesktopUtils.updateJSONValue(jsonMsg, "action", action);
            DesktopUtils.updateJSONValue(jsonMsg, "messageId", messageId);
            if (payload != null) {
                DesktopUtils.updateJSONValue(jsonMsg, "payload", payload);
            }
            if (MessageTrace)
            {
                Console.WriteLine("Sending: {0}", jsonMsg.ToString());
            }
            String msg = jsonMsg.ToString();
            if (listener != null)
            {
                listener.onOutgoingMessage(msg);
            }
            websocket.Send(msg);
            messageId++;
        }

        /// <summary>
        ///     Sends a message to AppDesktop.
        /// </summary>
        /// <param name="action">The action of the message.</param>
        /// <param name="payload">The message object to send.</param>
        /// <param name="callback">
        ///     A function that is called if the method succeeds.
        /// </param>
        /// <param name="source">
        ///     The message source to pair with resulting instances of AckCallback.
        /// </param>
        public void sendAction(String action, JObject payload, AckCallback callback, Object source)
        {
            sendAction(action, payload, callback, null, source);
        }


        

        /// <summary>
        ///     Sends a message to AppDesktop.
        /// </summary>
        /// <param name="action">The action of the message.</param>
        /// <param name="payload">The message object to send.</param>
        /// <param name="callback">
        ///     A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// <param name="source">
        ///     The message source to pair with resulting instances of AckCallback.
        /// </param>
        /// 
        public void sendAction(String action, 
                               JObject payload, 
                               AckCallback callback, 
                               AckCallback errorCallback,
                               Object source)
        {
            if (callback != null)
            {
                ListenerSourcePair[] msgCallbackEntry = new ListenerSourcePair[2];
                msgCallbackEntry[0] = new ListenerSourcePair(callback, source);
                msgCallbackEntry[1] = new ListenerSourcePair(errorCallback, source);
                callbacks[messageId] = msgCallbackEntry;
            }
            sendAction(action, payload);
        }

        /// <summary>
        /// Starts the AppDesktop executable.
        /// </summary>
        /// <param name="desktopPath">The file path that the AppDesktop executable is located in.</param>
        /// <param name="commandLine">Command line arguments to start the AppDesktop with.</param>
        private static void runDesktop(String desktopPath, String commandLine) {
            try
            {
#if SILVERLIGHT
                dynamic cmd = AutomationFactory.CreateObject("WScript.Shell");
                cmd.Run("cmd /c cd " + desktopPath + " & desktop.exe  --no-login-screen " + commandLine, 1, true);
#else
                System.Diagnostics.ProcessStartInfo procStartInfo =
                    new System.Diagnostics.ProcessStartInfo(desktopPath, commandLine);
                //procStartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                procStartInfo.CreateNoWindow = true;
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
                Console.WriteLine(result);
#endif
            }
            catch (Exception e)
            {
                // Log the exception
                Console.WriteLine(e.StackTrace);
            }
        }

        /// <summary>
        ///     Launches AppDesktop and notifies the listener when connected.
        /// </summary>
        /// <param name="desktopPath">Absolute path to the AppDesktop executable
        /// </param>
        /// <param name="commandLineArguements">
        ///     Command line arguments to start the AppDesktop with.
        /// </param>
        /// <param name="listener">
        ///     Receives updates on startup and connection state.
        /// </param>
        /// <param name="timeout">
        ///     For connecting to Desktop after launch. If the connection to 
        ///     AppDesktop is not established by the timeout the listener 
        ///     will get an onError() call.
        /// </param>
        public void launchAndConnect(String desktopPath, 
                                     String commandLineArguements,
                                     DesktopStateListener listener, int timeout)
        {
            desktopConnectTimeout = timeout;
            desktopCmdThread = new Thread(() => runDesktop(desktopPath, commandLineArguements));
            desktopCmdThread.IsBackground = true;
            desktopCmdThread.Start();
            Thread.Sleep(3000);
            connect(listener);
        }

        /// <summary>
        ///     Connects to an AppDesktop process
        /// </summary>
        /// 
        /// <param name="listener">
        ///     Receives updates on startup and connection state.
        /// </param>
        /// 
        /// <param name="type">
        ///     Describes the type of connection to establish.
        /// </param>
        public void connect(DesktopStateListener listener, String type = "file-token") 
        {
            this.authorizationType = type;
            this.listener = (listener != null? listener : this);
            this.authorizationAction = "request-external-authorization";
            desktopURL = "ws://" + host + ":" + port + "/" + path;
            this.websocket = new WebSocket(desktopURL);
            Console.WriteLine("WebSocket4Net " + this.websocket.Version);
            this.websocket.EnableAutoSendPing = false;
            //this.websocket.NoDelay = true;
            websocket.Opened += new EventHandler(websocketOpened);
            websocket.Error += new EventHandler<SuperSocket.ClientEngine.ErrorEventArgs>(websocketError);
            websocket.Closed += new EventHandler(websocketClosed);
            websocket.MessageReceived += new EventHandler<MessageReceivedEventArgs>(websocketMessageReceived);
            websocketThread = new Thread(webSocketThreadMain);
            websocketThread.IsBackground = true;
            websocketThread.Start();
        }

        /// <summary>
        ///     [Deprecated] Connects to an AppDesktop process
        /// </summary>
        /// <param name="authorizationToken">
        ///     A token that is passed to Desktop on startup and then 
        ///     re-presented on connect to establish elevated permissions for 
        ///     this client.
        /// </param>
        /// <param name="type">
        ///     Describes the type of connection to establish.
        /// </param>
        /// <param name="listener">
        ///     Receives updates on startup and connection state.
        /// </param>
        private void connectToDesktop(String authorizationToken, String type, DesktopStateListener listener)
        {
            this.authorizationToken = authorizationToken;
            connect(listener, type);
        }

        /**
         * 
         * ThreadStart for Websocket thread
         * 
        **/
        private void webSocketThreadMain()
        {
            Console.WriteLine("WebsocketThreadMain starting...");

            DateTime startTime = System.DateTime.Now;
            double waitTime = 0;
            websocket.Open();
            while ((waitTime < desktopConnectTimeout))
            {
                if (websocket.State == WebSocketState.Connecting)
                {
                    Console.WriteLine("wating for desktop websocket connection " + waitTime);
                    Thread.Sleep(2000);
                }
                else if (websocket.State == WebSocketState.Open)
                {
                    if (!connected)
                    {
                        Console.WriteLine("wating for desktop auth response " + waitTime);
                        Thread.Sleep(2000);
                        Console.WriteLine("retrying websocketOpened ");
                        websocketOpened(null, null);  // keep trying auth request
                    }
                    else
                    {
                        break;  // got auth response
                    }
                }
                else
                {
                    Thread.Sleep(2000);
                    Console.WriteLine("retrying desktop websocket connection " + waitTime);
                    websocket.Open();
                }
                waitTime = System.DateTime.Now.Subtract(startTime).TotalSeconds;
            }                
            while (websocket.State == WebSocketState.Connecting ||
                websocket.State == WebSocketState.Open)
            {
                Thread.Sleep(5000);
            }
            Console.WriteLine("WebsocketThreadMain ending {0} ", websocket.State.ToString());
        }

        /// <summary>
        ///     Joins the thread that handles the Websocket communication.
        /// </summary>
        public void joinWebSocketThread()
        {
            if (this.websocketThread != null)
            {
                this.websocketThread.Join();
            }
        }

        /// <summary>
        ///     EventHandler for open event from websocket.
        /// </summary>
        private void websocketOpened(object sender, EventArgs args)
        {
            disconnecting = false;
            JObject json = new JObject();
            try
            {
                DesktopUtils.updateJSONValue(json, "action", authorizationAction);
                JObject payload = new JObject();
                DesktopUtils.updateJSONValue(payload, "uuid", uuid);
                DesktopUtils.updateJSONValue(payload, "type", authorizationType);
                DesktopUtils.updateJSONValue(payload, "authorizationToken", authorizationToken);
                DesktopUtils.updateJSONValue(json, "payload", payload);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
            try
            {
                String msg = json.ToString();
                if (MessageTrace)
                {
                    Console.WriteLine("Sending: " + msg);
                }
                if (listener != null)
                {
                    listener.onOutgoingMessage(msg);
                }
                websocket.Send(msg);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        /**
         * 
         * EventHandler for Error event from websocket
         * 
         **/
        private void websocketError(object sender, SuperSocket.ClientEngine.ErrorEventArgs e)
        {
            Console.WriteLine("websocketError ");
            this.listener.onError(e.ToString());
        }

        /**
         * 
         * EventHandler for Close event from websocket
         * 
         **/
        private void websocketClosed(object sender, EventArgs e)
        {
            Console.WriteLine("websocketClosed ");
            connected = false;
            if (!disconnecting) {
                listener.onError("Connection closed.");
            }
            disconnecting = false;
            listener.onClosed();
        }


        private void fireMessageCallback(long correlationId, JObject payload)
        {
            if (payload != null && DesktopUtils.getJSONBool(payload, "deprecated"))
            {
                Console.WriteLine("Warning, Subscribed to: " + DesktopUtils.getJSONString(payload, "deprecatedInfo.eventType", "unknown-type") +
                                   ": " + DesktopUtils.getJSONString(payload, "deprecatedInfo.reason", "unknown-reason"));
            }

            ListenerSourcePair[] callbackEntry;
            if (callbacks.TryGetValue(correlationId, out callbackEntry))
            {
                uint callbackIndex = 0;

                if(!DesktopUtils.getJSONBool(payload, "success")) 
                {
                    callbackIndex = 1;
                    Console.WriteLine("Error performing action: " +  DesktopUtils.getJSONString(payload, "reason", "unknown-reason"));
                    
                }

                if (callbackEntry.Length >= callbackIndex + 1)
                {
                    Object source = callbackEntry[callbackIndex].getSource();
                    //JObject payload = DesktopUtils.getJSONObject(json, "payload");
                    if (callbackEntry[callbackIndex].getCallback() != null)
                    {
                        callbackEntry[callbackIndex].getCallback()(new Ack(payload, source));
                    }
                }
                callbacks.Remove(correlationId);
            }
        }

        private void dispatchDesktopEvent(JObject payload)
        {
            List<ListenerSourcePair> callbacks = getCallbackList(payload);
            if (callbacks != null)
            {
                foreach (ListenerSourcePair lsp in callbacks)
                {
                    Object source = lsp.getSource();
                    lsp.getCallback()(new Ack(payload, source));
                }
            }
        }

        /// <summary>
        ///     Creates notifies AppDesktop to create a Notification.
        /// </summary>
        /// <param name="options">The options of the notification.</param>
        /// <param name="source">
        ///     The message source to pair with resulting instances of AckCallback.
        /// </param>
        public uint registerNotificationCallbacks(NotificationOptions options, Object source)
        {
            uint returnId = 0;

            if(options != null)
            {
                Dictionary<String, ListenerSourcePair> notificationCallbacks = new Dictionary<String, ListenerSourcePair>();
                notificationCallbacks.Add("click", new ListenerSourcePair(options.OnClick, source));
                notificationCallbacks.Add("close", new ListenerSourcePair(options.OnClose, source));
                notificationCallbacks.Add("dismiss", new ListenerSourcePair(options.OnDismiss, source));
                notificationCallbacks.Add("error", new ListenerSourcePair(options.OnError, source));
                notificationCallbacks.Add("message", new ListenerSourcePair(options.OnMessage, source));
                notificationCallbacks.Add("show", new ListenerSourcePair(options.OnShow, source));
                notificationEventCallbackMap.Add(notificationCount_, notificationCallbacks);
                returnId = notificationCount_++;
            }

            return returnId;
        }

        
        
        /// <summary>
        ///     Sends a message to an AppDesktop Notification.
        /// </summary>
        /// <param name="action">The action of the message.</param>
        /// <param name="payload">The message object to send.</param>
        /// <param name="callback">
        ///     A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// <param name="source">
        ///     The message source to pair with a resulting message instance of AckCallback.
        /// </param>
        public void sendActionToNotificationsCenter(String action, JObject payload, AckCallback callback, AckCallback errorCallback, Object source)
        {
            if(notificationPayload_ == null)
            {
                notificationPayload_ = new JObject();
            }
            DesktopUtils.updateJSONValue(notificationPayload_, "action", action);
            DesktopUtils.updateJSONValue(notificationPayload_, "payload", payload);
            sendAction("send-action-to-notifications-center", notificationPayload_, callback, errorCallback, this);
        }

        private void sendFinalAuthorizationRequest(String type)
        {
            disconnecting = false;
            JObject json = new JObject();
            try
            {
                DesktopUtils.updateJSONValue(json, "action", "request-authorization");
                JObject payload = new JObject();
                DesktopUtils.updateJSONValue(payload, "uuid", uuid);
                DesktopUtils.updateJSONValue(payload, "type", type);
                DesktopUtils.updateJSONValue(json, "payload", payload);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            try
            {
                String msg = json.ToString();
                if (MessageTrace)
                {
                    Console.WriteLine("Sending: " + msg);
                }
                if (listener != null)
                {
                    listener.onOutgoingMessage(msg);
                }
                websocket.Send(msg);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        /**
         * 
         * EventHandler for MessageReceived event from websocket
         * 
         **/
        private void websocketMessageReceived(object sender, MessageReceivedEventArgs e)
        {
            if (MessageTrace)
            {
                Console.WriteLine("Receiving: " + e.Message);
            }

            this.listener.onMessage(e.Message);

            try
            {
                JObject json = JObject.Parse(e.Message);
                String action = DesktopUtils.getJSONString(json, "action");
                long correlationId = DesktopUtils.getJSONLong(json, "correlationId");
                JObject payload = DesktopUtils.getJSONObject(json, "payload");

                if (action.Equals("ack"))
                {
                    fireMessageCallback(correlationId, payload);    
                }
                // Authentication required
                else if (action.Equals("external-authorization-response"))
                {
                    // file-token authorization requested. Must write token into file.
                    if (authorizationType.Equals("file-token"))
                    {
                        String token = DesktopUtils.getJSONString(payload, "token");
                        String file = DesktopUtils.getJSONString(payload, "file");
                        if (token != null && 
                            file != null && 
                            file.Length > 0 && 
                            token.Length > 0)
                        {
                            StreamWriter writer = new StreamWriter(file);
                            writer.Write(token);
                            writer.Close();
                        }
                    }

                    sendFinalAuthorizationRequest(authorizationType);
                }
                else if (action.Equals("authorization-response"))
                {
                    //JObject payload = DesktopUtils.getJSONObject(json, "payload");
                    bool success = DesktopUtils.getJSONBool(payload, "success");
                    if (success)
                    {
                        connected = true;
                        listener.onReady();
                    }
                    else
                    {
                        if (!disconnecting)
                        {
                            String reason = DesktopUtils.getJSONString(payload, "reason");
                            listener.onError(reason);
                        }
                    }
                }
                else if (action.Equals("process-message"))
                {
                    //JObject payload = DesktopUtils.getJSONObject(json, "payload");
                    String sourceUuid = DesktopUtils.getJSONString(payload, "sourceUuid");
                    String topic = DesktopUtils.getJSONString(payload, "topic");
                    busInstance.dispatchMessageToCallbacks(sourceUuid, topic, DesktopUtils.getObject(payload, "message"));
                }
                else if (action.Equals("process-notification-event"))
                {
                    processNotificationEvent(payload);
                }
                else if (action.Equals("process-desktop-event"))
                {
                    dispatchDesktopEvent(payload);
                }
                else if (action.Equals("subscriber-added"))
                {
                    busInstance.dispatchToSubscribeListeners(DesktopUtils.getJSONString(payload, "uuid"),
                                                             DesktopUtils.getJSONString(payload, "topic"));
                }
                else if (action.Equals("subscriber-removed"))
                {
                    busInstance.dispatchToUnsubscribeListeners(DesktopUtils.getJSONString(payload, "uuid"),
                                                               DesktopUtils.getJSONString(payload, "topic"));
                }
                else if (action.Equals("ping"))
                {
                    //JObject payload = DesktopUtils.getJSONObject(json, "payload");
                    long pingId = DesktopUtils.getJSONLong(payload, "pingId");
                    respondToPing(pingId);
                }
                else if (action.Equals("process-external-app-action"))
                {
                    processExternalAppAction(payload);
                }
                else if (action.Equals("process-external-message"))
                {
                    processExternalMessage(payload);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
        }

        private void processNotificationEvent(JObject payload)
        {
            if (payload != null)
            {
                uint notificationId = DesktopUtils.getJSON<uint>(payload, "payload.notificationId", 0);

                if (notificationId > 0)
                {
                    Dictionary<String, ListenerSourcePair> callbackMap = null;
                    if (notificationEventCallbackMap.TryGetValue(notificationId, out callbackMap))
                    {
                        String type = DesktopUtils.getJSONString(payload, "type", "");

                        if (callbackMap != null)
                        {    
                            ListenerSourcePair lsp;
                            if (callbackMap.TryGetValue(type, out lsp))
                            {
                                if (lsp.getCallback() != null)
                                {
                                    lsp.getCallback()(new Ack(payload, lsp.getSource()));   
                                }
                            }
                        }

                        // Remove if the notification is no longer being used by AppDesktop.
                        if (type == "close" || 
                            type == "error" || 
                            type == "dismiss")
                        {
                            notificationEventCallbackMap.Remove(notificationId);
                        }
                    }
                }
            }
        }

        /// <summary>
        ///     Delegates API control from the desktop to a derived instance of ExternalWindow
        /// </summary>
        /// <param name="payload">The data to process</param>
        private void processExternalAppAction(JObject payload) 
        {
            if (externalWindow_ != null && payload != null)
            {
                String action = DesktopUtils.getJSONString(payload, "action");
                JObject innerPayload = DesktopUtils.getJSONObject(payload, "payload");
                long correlationId = DesktopUtils.getJSONLong(payload, "messageId", -1);
                String destinationToken = DesktopUtils.getJSONString(payload, "destinationToken");

                ExternalWindowAckResult result = new ExternalWindowAckResult(this, correlationId, destinationToken);

                switch (action)
                {
                    case "blur-window":
                        externalWindow_.blur(result);
                        break;
                    
                    case "bring-window-to-front":
                        externalWindow_.bringToFront(result);
                        break;

                    case "close-window":
                        externalWindow_.close(result);
                        break;

                    case "focus-window":
                        externalWindow_.focus(result);
                        break;

                    case "hide-window":
                        externalWindow_.hide(result);
                        break;

                    case "maximize-window":
                        externalWindow_.maximize(result);
                        break;

                    case "minimize-window":
                        externalWindow_.minimize(result);
                        break;

                    case "move-window-by":
                        externalWindow_.moveBy(DesktopUtils.getJSONInt(innerPayload, "deltaLeft", 0),
                                               DesktopUtils.getJSONInt(innerPayload, "deltaTop", 0),
                                               result);
                        break;

                    case "move-window":
                        externalWindow_.moveTo(DesktopUtils.getJSONInt(innerPayload, "left", 0),
                                               DesktopUtils.getJSONInt(innerPayload, "top", 0),
                                               result);
                        break;

                    case "resize-window-by":
                        externalWindow_.resizeBy(DesktopUtils.getJSONInt(innerPayload, "deltaWidth", 0),
                                                 DesktopUtils.getJSONInt(innerPayload, "deltaHeight", 0),
                                                 DesktopUtils.getJSONString(innerPayload, "anchor", "top-left"),
                                                 result);
                        break;

                    case "resize-window":
                        externalWindow_.resizeTo(DesktopUtils.getJSONInt(innerPayload, "width", 0),
                                                 DesktopUtils.getJSONInt(innerPayload, "height", 0),
                                                 DesktopUtils.getJSONString(innerPayload, "anchor", "top-left"),
                                                 result);
                        break;

                    case "restore-window":
                        externalWindow_.restore(result);
                        break;

                    case "show-window":
                        externalWindow_.show(result);
                        break;

                    case "show-at-window":
                        externalWindow_.showAt(DesktopUtils.getJSONInt(innerPayload, "left", 0),
                                               DesktopUtils.getJSONInt(innerPayload, "top", 0),
                                               DesktopUtils.getJSONBool(innerPayload, "toggle", false),
                                               result);
                        break;

                    case "set-foreground-window":
                        externalWindow_.setAsForeground(result);
                        break;
                    default:
                        break;
                }

                // Automatically send result if not explicitly prevented
                if (!result.PreventAutomaticSend)
                {
                    result.send();
                }
            }
        }

        /// <summary>
        ///     Disconnects from AppDesktop
        /// </summary>
        public void disconnect()
        {
            disconnecting = true;
            try
            {
                websocket.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        /// <summary>
        ///     Notify AppDesktop to exit.
        /// </summary>
        public void exit()
        {
            sendAction("exit-desktop", new JObject());
        }


        /// <summary>
        ///     Gets conneted status.
        /// </summary>
        public bool isConnected()
        {
            return connected;
        }

        /**
        * Responds to ping message from Desktop
        *
        * @param pingId unique ID of ping message
        **/
        protected void respondToPing(long pingId)
        {
            JObject payload = new JObject();
            try
            {
                DesktopUtils.updateJSONValue(payload, "correlationId", pingId);
                DesktopUtils.updateJSONValue(payload, "pingedBefore", pingedBefore);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
            sendAction("pong", payload);
            pingedBefore = true;
        }

        /// <summary>
        ///     Callback when Desktop is successfully connected and ready to 
        ///     accept commands.
        /// </summary>
        public void onReady() { }

        /// <summary>
        ///     Callback when the connection with the Desktop has closed.
        /// </summary>
        public void onClosed() { }

        /// <summary>
        ///     Callback when client cannot start or connect to the Desktop.
        /// </summary>
        public void onError(String reason) { }

        /// <summary>
        ///     Callback when a message is sent to this client.
        /// </summary>
        public void onMessage(String message) { }

        /// <summary>
        ///     Callback when a message is sent from this client.
        /// </summary>
        public void onOutgoingMessage(String message) { }

        /// <summary>
        ///     Dispatches the a payload from "process-external-message" to all registered ExternalMessageHandlerDelegates
        ///     and sends the result after all result handlers have set a success/fail result.
        /// </summary>
        /// <param name="payload">The data to process.</param>
        private void processExternalMessage(JObject payload)
        {
            // Crate the factory promise object to coordinate all results for this message
            ExternalMessageResultHandlerFactory messageHandlerFactory = new ExternalMessageResultHandlerFactory(uuid, sendAction, payload);

            // Dispatch a new ExternalMessageResultHandler to each registered delegate
            externalMessageHandlers_.ForEach(delegate(ExternalMessageHandlerSourcePair handlerPair)
            {
                handlerPair.getCallback()(messageHandlerFactory.makeResultHandler(), payload);
            });

            // Tell the factory that no more result handlers will be created.
            // Sends immediately if all result handlers have already set their result status.
            messageHandlerFactory.allDispatched();
        }

        /// <summary>
        ///     Registers a listener to handle messages for this connection's UUID originating via HTTPS/HTTP.
        /// </summary>
        /// <param name="listener">
        ///     A function that is called to process a received HTTPS/HTTP message for this connection.
        /// </param>
        /// <param name="source">
        ///     The object that originally registered the listener.
        /// </param>
        public void addExternalMessageHandler(ExternalMessageHandlerDelegate listener, Object source)
        {
            externalMessageHandlers_.Add(new ExternalMessageHandlerSourcePair(listener, source));
        }

        /// <summary>
        ///     Sends a message to AppDesktop.
        /// </summary>
        /// <param name="action">The action of the message.</param>
        /// <param name="payload">The message object to send.</param>
        /// <param name="callback">
        ///     A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// <param name="source">
        ///     The message source to pair with resulting instances of AckCallback.
        /// </param>
        private delegate void SendMessageToDesktopDelegate(String action,
                                                           JObject payload,
                                                           AckCallback callback,
                                                           AckCallback errorCallback,
                                                           Object source);

        /// <summary>
        ///     Creates instances of ExternalMessageResultHandler and sends the total result to the AppDesktop.
        /// </summary>
        private class ExternalMessageResultHandlerFactory : IExternalMessageResultDispatcher
        {
            /// <summary>
            ///     Stores meta information for each ExternalMessageResultHandler
            /// </summary>
            private class ResultHandlerMetaInfo
            {
                public bool processed;  // True when the result handler has invoked send()
                public bool result;     // The success/fail state
                public String message;  // Message set on send()

                /// <summary>
                ///     Defaults values used by this meta class
                /// </summary>
                public ResultHandlerMetaInfo()
                {
                    processed = false;
                    result = true;
                    message = "";
                }
            }

            // A mapping between an ExternalMessageResultHandler's UUID and its related ResultHandlerMetaInfo 
            Dictionary<String, ResultHandlerMetaInfo> handlers_ = new Dictionary<String, ResultHandlerMetaInfo>();

            // Mutex for adding, updating and checking result handler meta information.
            private Object handlerLock_ = new Object();

            // Delegate for sending the success/fail result payload to the AppDesktop
            private SendMessageToDesktopDelegate sendMessageToDesktopDelegate_;

            private JObject request_;               // The payload from the AppDesktop
            private bool sentToDesktop_ = false;    // Has a result already been sent to the AppDesktop
            private uint nHandlers_ = 0;            // The total number of ExternalMessageResultHandlers created
            private uint nProcessed_ = 0;           // How many ExternalMessageResultHandler have set their success/fail result
            private bool allDispatched_ = false;    // True when no more ExternalMessageResultHandlers are expected to be created.
            private String uuid_;                   // The UUID of the DesktopConnection that owns this factory. Used for dispatching to the AppDesktop.

            /// <summary>
            /// 
            /// </summary>
            /// <param name="uuid">
            ///     The UUID of the DesktopConnection that owns this factory. Used for dispatching to the AppDesktop.
            /// </param>
            /// <param name="sendMessageToDesktop">
            ///     Delegate for sending the success/fail result payload to the AppDesktop.
            /// </param>
            /// <param name="request">
            ///     The payload from the AppDesktop.
            /// </param>
            public ExternalMessageResultHandlerFactory(String uuid, SendMessageToDesktopDelegate sendMessageToDesktop, JObject request)
            {
                request_ = request;
                sendMessageToDesktopDelegate_ = sendMessageToDesktop;
                uuid_ = uuid;
            }

            /// <summary>
            ///     Returns true when the result has been sent to the desktop
            /// </summary>
            private bool wasSent()
            {
                return sentToDesktop_;
            }

            /// <summary>
            ///     Sends the AND combination of all results and concatenated messages to the AppDesktop 
            ///     if allDispatched() has been called and all result handlers have completed.
            /// </summary>
            private void sendIfAllResultsDispatchedAndComplete()
            {
                if (allDispatched_ && nProcessed_ == nHandlers_)
                {
                    // Default to success with no data
                    bool totalResult = true;
                    String totalMessage = "";

                    // If no result handlers have been created for this factory
                    if (nHandlers_ == 0)
                    {
                        totalResult = false;
                        totalMessage = "No external message handler has been registered!";
                    }

                    // AND the result and concatenate messages from all result handlers.
                    foreach (KeyValuePair<String, ResultHandlerMetaInfo> entry in handlers_)
                    {
                        totalResult &= entry.Value.result;
                        totalMessage += entry.Value.message;
                    }

                    // Send totalResult and totalMessage to the AppDesktop
                    JObject payload = new JObject();
                    DesktopUtils.updateJSONValue(payload, "uuid", uuid_);
                    DesktopUtils.updateJSONValue(payload, "connectionId", DesktopUtils.getJSON<int>(request_, "connectionId", 0));
                    DesktopUtils.updateJSONValue(payload, "result", totalResult);
                    DesktopUtils.updateJSONValue(payload, "message", totalMessage);
                    String action = "external-message-result";
                    sendMessageToDesktopDelegate_(action, payload, null, null, this);

                    // Remember that the result has been sent to the desktop for this factory.
                    sentToDesktop_ = true;
                }
            }

            /// <summary>
            ///     Marks that no more result handlers will be created.
            ///     Sends result status to the AppDesktop immediately if all result handlers have already set their success/fail and messages.
            /// </summary>
            public void allDispatched()
            {
                lock (handlerLock_)
                {
                    allDispatched_ = true;
                    sendIfAllResultsDispatchedAndComplete();
                }
            }

            // Factory method to create and track a result handler
            /// <summary>
            ///     Factory method to create and track a result handler
            /// </summary>
            public ExternalMessageResultHandler makeResultHandler()
            {
                ExternalMessageResultHandler requestHandler = new ExternalMessageResultHandler(this);
                lock (handlerLock_)
                {
                    handlers_.Add(requestHandler.ID, new ResultHandlerMetaInfo());
                    ++nHandlers_;
                }
                return requestHandler;
            }

            /// <summary>
            ///     Updates the stored meta information and sends to the container if all results have been received.
            /// </summary>
            /// <param name="id">The UUID of the ExternalMessageResultHandler the result came from</param>
            /// <param name="result">true for success, false for failure.</param>
            /// <param name="message">A string response to be sent back over HTTP/HTTPS</param>
            public bool handleResult(String id, bool result, String message)
            {
                bool handled = false;

                lock(handlerLock_) 
                {
                    ResultHandlerMetaInfo handlerMetaInfo;
                    if (!wasSent() && 
                        handlers_.TryGetValue(id, out handlerMetaInfo) && 
                        !handlerMetaInfo.processed)
                    {
                        // Update the meta information
                        handlerMetaInfo.processed = true;
                        handlerMetaInfo.result = result;
                        handlerMetaInfo.message = message;

                        // Store the new meta info in the dictionary
                        handlers_[id] = handlerMetaInfo;

                        // Track that the updates happened in the factory
                        handled = true;
                        ++nProcessed_;
                        sendIfAllResultsDispatchedAndComplete();
                    }
                }
                return handled;
            }
        }
    }
}
