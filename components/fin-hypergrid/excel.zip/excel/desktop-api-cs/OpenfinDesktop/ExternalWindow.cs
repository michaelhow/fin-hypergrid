﻿/*
 * File ExternalWindow.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Encapsulates and sends the result of an ExternalWindow action to the desktop.
    ///     The result is sent after invocation of an ExternalWindow method.
    ///     
    ///     In cases where this behavior needs to be  prevented, such as when work done should be handled by another thread, 
    ///     Set PreventAutomaticSend to true and call send() when the result state is determined.
    ///     
    ///     send() will be called automatically by Dispose() if it has not been explicitly called prior.
    /// </summary>
    public class ExternalWindowAckResult : IDisposable
    {
        private readonly DesktopConnection connection_;
        private JObject ack_ = new JObject();
        private bool processed_ = false;
        private bool preventAutomaticSend_ = false;

        /// <summary>
        ///      Constructs an instance.
        /// </summary>
        /// <param name="connection"> The websocket connection that owns this ACK</param>
        /// <param name="correlationId">The message ID to map this result back to any pending callbacks in other apps.</param>
        /// <param name="destinationToken">Token which resolves to the app with the pending callback.</param>
        public ExternalWindowAckResult(DesktopConnection connection, long correlationId, String destinationToken)
        {
            connection_ = connection;

            if (correlationId != -1)
            {
                DesktopUtils.updateJSONValue(ack_, "correlationId", correlationId);
            }

            DesktopUtils.updateJSONValue(ack_, "destinationToken", destinationToken);
        }

        /// <summary>
        ///     Sends the result to the desktop triggering pending callbacks in other apps.
        /// </summary>
        /// <param name="succeeded">True when the operation was successful</param>
        /// <param name="reason">When succeeded is false, a reason is sent on error.</param>
        public void send(bool succeeded = true, String reason = null)
        {
            if (!processed_)
            {
                DesktopUtils.updateJSONValue(ack_, "success", succeeded);

                // Ensure there is a reason for failure even if not specified
                if (!succeeded)
                {
                    DesktopUtils.updateJSONValue(ack_, "reason", (reason != null ? reason : "An unspecified error occurred in the ExternalWindow"));
                }

                // Only send over the connection if it's available and not sent before 
                if (connection_ != null)
                {
                    connection_.sendAction("external-ack", ack_);
                }

            }

            processed_ = true;
        }

        /// <summary>
        ///     Will call send() if not done so already.
        /// </summary>
        public void Dispose()
        {
            send();
        }

        /// <summary>
        ///     Prevents send() from being called directly after invocation of an ExternalWindow method. 
        ///     If prevented send() must be called explicitly otherwise it will be called on Dispose().
        /// </summary>
        public bool PreventAutomaticSend
        {
            get { return preventAutomaticSend_; }
            set { preventAutomaticSend_ = value; }
        }
    }

    /// <summary>
    ///    Responds to API window messages to control a window outside of the desktop.
    /// </summary>
    public interface ExternalWindow
    {
        /// <summary>
        ///     Removes focus from the window.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void blur(ExternalWindowAckResult result);

        /// <summary>
        ///     Brings the window to the front of the window stack.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void bringToFront(ExternalWindowAckResult result);

        /// <summary>
        ///     Closes the window.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void close(ExternalWindowAckResult result);

        /// <summary>
        ///     Gives focus to the window.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void focus(ExternalWindowAckResult result);

        /// <summary>
        ///     Hides the window.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void hide(ExternalWindowAckResult result);

        /// <summary>
        ///     Maximizes the window.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void maximize(ExternalWindowAckResult result);

        /// <summary>
        ///     Minimizes the window.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void minimize(ExternalWindowAckResult result);

        /// <summary>
        ///     Moves the window by a specified amount.
        /// </summary>
        /// <param name="deltaLeft">The change in the left position of the window.</param>
        /// <param name="deltaTop">The change in the top position of the window.</param>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void moveBy(int deltaLeft,
                    int deltaTop,
                    ExternalWindowAckResult result);

        /// <summary>
        ///     Moves the window to a specified location.
        /// </summary>
        /// <param name="left">The left position of the window.</param>
        /// <param name="top">The top position of the window.</param>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void moveTo(int left,
                    int top,
                    ExternalWindowAckResult result);

        /// <summary>
        ///     Resizes the window by the specified amount.
        /// </summary>
        /// <param name="deltaWidth">The change in the width of the window.</param>
        /// <param name="deltaHeight">The change in the height of the window.</param>
        /// <param name="anchor">
        ///     Specifies a corner to remain fixed during the resize.
        ///     Can take the values: 
        ///         "top-left"
        ///         "top-right"
        ///         "bottom-left"
        ///         "bottom-right" 
        ///     If undefined, the default is "top-left".
        /// </param>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void resizeBy(int deltaWidth,
                      int deltaHeight,
                      String anchor,
                      ExternalWindowAckResult result);

        /// <summary>
        ///     Resizes the window to the specified dimensions.
        /// </summary>
        /// <param name="width">The width of the window.</param>
        /// <param name="height">The height of the window.</param>
        /// <param name="anchor">
        ///     Specifies a corner to remain fixed during the resize.
        ///     Can take the values: 
        ///         "top-left"
        ///         "top-right"
        ///         "bottom-left"
        ///         "bottom-right" 
        ///     If undefined, the default is "top-left".
        /// </param>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void resizeTo(int width,
                      int height,
                      String anchor,
                      ExternalWindowAckResult result);

        /// <summary>
        ///     Restores the window to its normal state (i.e., unminimized, unmaximized).
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void restore(ExternalWindowAckResult result);

        /// <summary>
        ///     Shows the window if it is hidden.
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void show(ExternalWindowAckResult result);

        /// <summary>
        ///     Shows the window if it is hidden at the specified location.
        ///     <para>
        ///         If the toggle parameter is set to true, the window will
        ///         alternate between showing and hiding.
        ///     </para>
        /// </summary>
        /// <param name="left">The left position of the window.</param>
        /// <param name="top">The right position of the window.</param>
        /// <param name="toggle">
        ///     If true, the window will alternate between showing and hiding in subsequent calls.
        /// </param>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void showAt(int left,
                    int top,
                    bool toggle,
                    ExternalWindowAckResult result);

        /// <summary>
        ///     Set's the window as the foreground window. 
        ///     <para>
        ///         The window is activated(focused) and brought to front.
        ///     </para>
        /// </summary>
        /// <param name="result">Notifies the desktop of success/failure of this action</param>
        void setAsForeground(ExternalWindowAckResult result);
    }
}
