﻿/*
 * File AnimationOptions.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A class representing the options for a Window animation.
    /// </summary>
    public class AnimationOptions
    {
        private JObject options_ = new JObject();

        /// <summary>
        ///     Constructs an instance with the passed value for property Interrupt
        /// </summary>
        public AnimationOptions(bool interrupt)
        {
            Interrupt = interrupt;
        }

        /// <summary>
        ///     The Raw property represents the name for the window which 
        ///     must be unique within the context of the invoking Application.
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The Raw property gets the value of the underlying JObject.
        /// </value> 
        public JObject Raw
        {
            get { return options_; }
        }

        /// <summary>
        ///     The Interrupt property represents a flag which determines if a call to Window.animate 
        ///     will interrupt all pending transitions, or add itself to the queue.
        ///     <para>Default: true</para>
        /// </summary> 
        /// <value>
        ///     The Interrupt property gets/sets the value of the underlying 
        ///     JObject field, "interrupt".
        /// </value> 
        public bool Interrupt
        {
            get { return DesktopUtils.getJSONBool(options_, "interrupt", true); }
            set { DesktopUtils.updateJSONValue(options_, "interrupt", value); }
        }
    }
}
