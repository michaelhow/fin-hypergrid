﻿/*
 * File ApplicationOptions.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;
using Openfin.Desktop;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Helper object that provides getters/setters for the 
    ///     various options needed for creating an Application.
    /// </summary>
    public class ApplicationOptions
    {
        private JObject options;
        private WindowOptions mainWindowOptions;


        /// <summary>
        ///     Constructs an instance with the passed options.
        /// </summary>
        /// <param name="options">a JObject containing application settings.</param>
        public ApplicationOptions(JObject options)
        {
            this.options = options;
            mainWindowOptions = new WindowOptions(DesktopUtils.getJSON<JObject>(options, "mainWindowOptions", new JObject()));
            //mainWindowOptions.Name = UUID;
        }

        /// <summary>
        ///     Constructs an instance configuring a new underlying JObject 
        ///     with the passed values.
        /// </summary>
        /// <param name="name">The name of the application.</param>
        /// <param name="uuid">The UUID of the application</param>
        /// <param name="url">The url for the application to load.</param>
        public ApplicationOptions(String name, String uuid, String url)
        {
            options = new JObject(); 
            DesktopUtils.updateJSONValue(options,"name", name);
            DesktopUtils.updateJSONValue(options,"uuid", uuid);
            mainWindowOptions = new WindowOptions(DesktopUtils.getJSON<JObject>(options, "mainWindowOptions", new JObject()));
            //MainWindowOptions.Name = UUID;
            MainWindowOptions.URL = url;
        }

        /// <summary>
        ///     Gets all settings in JObject format.
        /// </summary>
        public JObject getJsonCopy()
        {
            DesktopUtils.updateJSONValue(options, "mainWindowOptions", MainWindowOptions.getJsonCopy());
            DesktopUtils.updateJSONValue(options, "url", MainWindowOptions.URL);
            return JObject.Parse(options.ToString());
        }

        /// <summary>
        ///     Gets the underliying JObject containing the options.
        /// </summary>
        private JObject Raw
        {
            get {
                DesktopUtils.updateJSONValue(options, "mainWindowOptions", MainWindowOptions.getJsonCopy());
                DesktopUtils.updateJSONValue(options, "url", MainWindowOptions.URL);
                return this.options; 
            }
        }

        // ====================================================================
        // Required
        // ====================================================================

        /// <summary>
        ///     The ApplicationIcon property represents the icon to display for the 
        ///     Application's main window.
        ///     <para>
        ///         Support formats: 
        ///             Portable Network Graphic (PNG); Size: 256 x 256 
        ///     </para>
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The ApplicationIcon property gets/sets the value of the underlying 
        ///     JObject field, "applicationIcon".
        /// </value> 
        public String ApplicationIcon
        {
            get { return DesktopUtils.getJSON<String>(options, "applicationIcon", ""); }
            set { DesktopUtils.updateJSONValue(options, "applicationIcon", value); }
        }

        /// <summary>
        ///     The Name property represents the the name for the Application's
        ///     main window window which must be unique within the context of 
        ///     the invoking Application.
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The Name property gets the value of the underlying 
        ///     JObject field, "name".
        /// </value> 
        public String Name
        {
            get { return DesktopUtils.getJSON<String>(options, "name", ""); }
        }

        /// <summary>
        ///     The UUID property represents the UUID of the application 
        ///     as known by the AppDesktop.
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The UUID property gets the value of the underlying 
        ///     JObject field, "uuid".
        /// </value> 
        public String UUID
        {
            get { return DesktopUtils.getJSON<String>(options, "uuid", ""); }
        }


        // ====================================================================
        // Optional
        // ====================================================================

        /// <summary>
        ///     The IsAdmin property represents if the application has 
        ///     administrator privileges. (e.g., the ability to create 
        ///     and run applications). 
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The IsAdmin property gets/sets the value of the underlying 
        ///     JObject field, "isAdmin".
        /// </value> 
        public bool IsAdmin
        {
            get { return DesktopUtils.getJSON<bool>(options, "isAdmin", false); }
            set { DesktopUtils.updateJSONValue(options, "isAdmin", value); }
        }

        /// <summary>
        ///     The IsAdmin property represents the options 
        ///     of the main window of the application.
        /// </summary> 
        public WindowOptions MainWindowOptions
        {
            get { return mainWindowOptions; }
            set { mainWindowOptions = value; }
        }

        /// <summary>
        ///     The Version property represents the version 
        ///     of the application.
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The Version property gets/sets the value of the underlying 
        ///     JObject field, "version".
        /// </value> 
        public String Version
        {
            get { return DesktopUtils.getJSON<String>(options, "version", ""); }
            set { DesktopUtils.updateJSONValue(options, "version", value); }
        }
    }
}
