﻿/*
 * File Application.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A delegate to handle the resulting windows from 
    ///     Application.getChildWindow().
    /// </summary>
    /// <param name="children"></param>
    public delegate void childWindowHandler(List<Window> children);

    /// <summary>
    ///     A delegate to handle the returned groups and 
    ///     their respective windows from Application.getGroups().
    /// </summary>
    /// <param name="groups">A list of groups and their member windows.</param>
    public delegate void applicationGroupsHandler(List<List<Window>> groups);

    /// <summary>
    ///     An object representing the Application.
    ///     <para>
    ///         Allows the developer to execute, show and close an application, 
    ///         as well as show and hide an icon on Desktop. Also provides access 
    ///         to the Window object for the main application window to control 
    ///         window state such as the ability to minimize, maximize, restore, etc.
    ///     </para>
    /// </summary>
    public class Application
    {
        private DesktopConnection desktopConnection;
        private ApplicationOptions options;

        //message objects for various types of actions
        private JObject closePayload_ = null;
        private JObject deregisterExternalWindowPayload_ = null;
        private JObject eventListenerPayload_ = null;
        private JObject noParamPayload = null;
        private JObject pingChildPayload_ = null;
        private JObject registerExternalWindowPayload_ = null;

        private Window window;  // Application main window
        private String uuid;    // application UUOD

        //private AckCallback trayIconClickedCallback = null;


        /// <summary>
        ///     Application Constructor.
        /// </summary>
        /// <param name="options">Settings of the application.<see cref="ApplicationOptions"/></param>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public Application(ApplicationOptions options, 
                           DesktopConnection desktopConnection, 
                           AckCallback callback = null, 
                           AckCallback errorCallback = null)
        {
            this.options = options;
            this.desktopConnection = desktopConnection;
            uuid = this.options.UUID;

            initialize();

            desktopConnection.sendAction("create-application", this.options.getJsonCopy() , callback, errorCallback, this);  // send request to Desktop
        }

        /// <summary>
        ///     Attaches an Application object to an application that already exists.
        ///     <seealso cref="Application.wrap"/>
        /// </summary>
        /// <param name="uuid"> The UUID of the Application to wrap.</param>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        public Application(String uuid, DesktopConnection desktopConnection)
        {
            this.uuid = uuid;
            this.desktopConnection = desktopConnection;
            initialize();
        }

        /// <summary>
        ///     Attaches an Application object to an application that already exists.
        /// </summary>
        /// <param name="uuid"> The UUID of the Application to wrap.</param>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        public static Application wrap(String uuid, DesktopConnection desktopConnection)
        {
            return new Application(uuid, desktopConnection);
        }

        /// <summary>
        ///     Allocates and prepares internal JObjects and wraps the Applications main window.
        /// </summary>
        private void initialize()
        {
            noParamPayload = new JObject();
            DesktopUtils.updateJSONValue(noParamPayload, "uuid", uuid);
            window = new Window(this);  // create application main window
        }

        /// <returns>
        ///     The ApplicationOptions object for the application
        ///     <see cref="ApplicationOptions"/>
        /// </returns>
        public ApplicationOptions getOptions()
        {
            return this.options;
        }

        /// <returns>
        ///     The applications registered UUID with the AppDesktop.
        /// </returns>
        public String getUuid()
        {
            return uuid;
        }

        /// <returns>
        ///     The applications connection object with the AppDesktop.
        ///     <see cref="DesktopConnection"/>
        /// </returns>
        public DesktopConnection DesktopConnection
        {
            get { return desktopConnection; }
        }


        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///        closed
        ///        crashed
        ///        error
        ///        not-responding
        ///        out-of-memory
        ///        responding
        ///        started
        /// </remarks>
        /// <param name="subscriptionObject">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        private void addEventListener(JObject subscriptionObject,
                                      AckCallback listener,
                                      AckCallback callback = null,
                                      AckCallback errorCallback = null)
        {
            this.desktopConnection.addEventCallback(subscriptionObject,
                                                    listener,
                                                    callback,
                                                    errorCallback,
                                                    this);
        }

        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///        closed
        ///        crashed
        ///        error
        ///        not-responding
        ///        out-of-memory
        ///        responding
        ///        started
        /// </remarks>
        /// <param name="type">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void addEventListener(String type,
                                     AckCallback listener,
                                     AckCallback callback = null,
                                     AckCallback errorCallback = null)
        {
            if (eventListenerPayload_ == null)
            {
                eventListenerPayload_ = new JObject();
                DesktopUtils.updateJSONValue(eventListenerPayload_, "topic", "application");
                DesktopUtils.updateJSONValue(eventListenerPayload_, "uuid", getUuid());
            }

            DesktopUtils.updateJSONValue(eventListenerPayload_, "type", type);
            addEventListener(eventListenerPayload_, listener, callback, errorCallback);
        }

        /// <summary>
        ///     Closes the application
        /// </summary>
        /// <param name="force">
        ///     When true the close can not be prevented through the window event 'close-requested'
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void close(bool force = false, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (closePayload_ == null)
            {
                closePayload_ = new JObject();
                DesktopUtils.updateJSONValue(closePayload_, "uuid", getUuid());
            }

            DesktopUtils.updateJSONValue(closePayload_, "force", force);
            desktopConnection.sendAction("close-application", closePayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Passes a list of wrapped child windows for the current application to childHandler.
        /// </summary>
        /// <remarks>
        ///     The Application's main window IS NOT a child window.
        ///     The list is empty if the application has no child windows.
        /// </remarks>
        /// <param name="childHandler">
        ///     A delegate that receives a list wrapped child windows for the current application.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getChildWindows(childWindowHandler childHandler, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("get-child-windows", noParamPayload, (childWindowInfo) => {
                List<Window> children = new List<Window>();
                if(childWindowInfo != null) {
                    JObject cWindows = childWindowInfo.getJsonObject();
                    if (cWindows != null)
                    {
                        IList<String> cObjects = cWindows.SelectToken("data").Select(s => (String)s).ToList();
                        foreach (String name in cObjects)
                        {
                            children.Add(Window.wrap(getUuid(), name, desktopConnection));
                        }
                    }
                }

                if (childHandler != null) { childHandler(children); }

            }, errorCallback, this);
        }

        /// <summary>
        ///     Passes a list of groups and their wrapped child windows 
        ///     for the current application to groupHandler.
        /// </summary>
        /// <param name="groupHandler">
        ///      A delegate that receives a list of groups for the current application. 
        ///      Each group is represented as a list of wrapped child windows.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getGroups(applicationGroupsHandler groupHandler, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("get-application-groups", noParamPayload, (groupInfo) =>
            {
                // All the wrapped window groups
                List<List<Window>> groups = new List<List<Window>>();
                if (groupInfo != null)
                {
                    JObject cGroups = groupInfo.getJsonObject();
                    if (cGroups != null)
                    {
                        // For each group
                        JArray allGroups = (JArray)cGroups.SelectToken("data");
                        foreach (IList<JToken> windowGroup in allGroups)
                        {
                            // For each window in a group, wrap and add to sublist.
                            List<Window> wrappedGroup = new List<Window>();
                            foreach (JToken window in windowGroup)
                            {
                                wrappedGroup.Add(Window.wrap(getUuid(), window.ToString(), desktopConnection));
                            }
                            groups.Add(wrappedGroup);
                        }
                        
                    }
                }

                if (groupHandler != null) { groupHandler(groups); }
            }, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves the JSON manifest that was used to create the application.
        ///     Invokes the error callback if the application was not created from a manifest.
        /// </summary>
        /// <param name="callback">
        ///     A function that is called and passed an Ack containing the JObject manifest 
        ///     that was used to create the application.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getManifest(AckCallback callback, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("get-application-manifest", noParamPayload, callback, errorCallback, this);
        }

        /// <returns>
        ///     The main Window object of the application.
        ///     <see cref="Window"/>
        /// </returns>
        public Window getWindow()
        {
            return window;
        }

        /// <summary>
        ///     Determines if the application is currently running/active.
        /// </summary>
        /// <param name="callback">
        ///     A function that is called if the method succeeds and 
        ///     passed an object containg the running/active state of the window.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void isRunning(AckCallback callback, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("is-application-running", noParamPayload, callback, errorCallback, this);
        }

        /// <param name="name">The name of the window to ping.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void pingChildWindow(String name, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (pingChildPayload_ == null)
            {
                pingChildPayload_ = new JObject();
                DesktopUtils.updateJSONValue(pingChildPayload_, "uuid", getUuid());
            }

            DesktopUtils.updateJSONValue(pingChildPayload_, "name", name);
            desktopConnection.sendAction("ping-child-window", pingChildPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes the application.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void remove(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("remove-application", noParamPayload, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes a previously registered event listener from the specified event.
        ///     <para>
        ///         The listener is passed an event object containing information 
        ///         related to the event.
        ///     </para>
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///        closed
        ///        crashed
        ///        error
        ///        not-responding
        ///        out-of-memory
        ///        responding
        ///        started
        /// </remarks>
        /// <param name="type">The type of the event.</param>
        /// <param name="listener">
        ///     A function that was called whenever an event of the specified type occurs.
        ///     It is no longer called in response to an event of the passed type.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void removeEventListener(String type,
                                        AckCallback listener,
                                        AckCallback callback = null,
                                        AckCallback errorCallback = null)
        {
            if (eventListenerPayload_ == null)
            {
                eventListenerPayload_ = new JObject();
                DesktopUtils.updateJSONValue(eventListenerPayload_, "topic", "application");
                DesktopUtils.updateJSONValue(eventListenerPayload_, "uuid", getUuid());
            }
            DesktopUtils.updateJSONValue(eventListenerPayload_, "type", type);
            this.desktopConnection.removeEventCallback(eventListenerPayload_, 
                                                       listener,
                                                       callback,
                                                       errorCallback,
                                                       this);
        }

        /*public void removeTrayicon(AckCallback callback = null, AckCallback errorCallback = null)
        {
            // Remove a prior listener if present.
            if (trayIconClickedCallback != null)
            {
                removeEventListener("tray-icon-clicked", trayIconClickedCallback);
                trayIconClickedCallback = null;
            }

            desktopConnection.sendAction("remove-tray-icon", noParamPayload, callback, errorCallback, this);
        }*/

        /// <summary>
        ///     Restart the application.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void restart(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("restart-application", noParamPayload, callback, errorCallback, this);
        }

        /// <summary>
        ///     Runs the application on the AppDesktop.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void run(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("run-application", noParamPayload, callback, errorCallback, this);
        }

        /*public void setTrayicon(String iconUrl, 
                                AckCallback listener = null, 
                                AckCallback callback = null, 
                                AckCallback errorCallback = null)
        {
            // Clean up old callback event listener
            if (trayIconClickedCallback != null)
            {
                removeEventListener("tray-icon-clicked", trayIconClickedCallback);
            }

            // Store the listener for future removal
            trayIconClickedCallback = listener;
            addEventListener("tray-icon-clicked", listener);

            String icon = (iconUrl != null && iconUrl.Length > 0 ? iconUrl : getOptions().ApplicationIcon);
            JObject msg = new JObject();
            DesktopUtils.updateJSONValue(msg, "enabledIcon", icon);
            DesktopUtils.updateJSONValue(msg, "disabledIcon", icon);
            DesktopUtils.updateJSONValue(msg, "hoverIcon", icon);
            DesktopUtils.updateJSONValue(msg, "uuid", getUuid());
            desktopConnection.sendAction("set-tray-icon", msg, callback, errorCallback, this);
        }*/

        /// <summary>
        ///     Terminates the application.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void terminate(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("terminate-application", noParamPayload, callback, errorCallback, this);
        }

        /// <summary>
        ///     Wait for the application if it is unresponsive.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void waitFor(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("wait-for-hung-application", noParamPayload, callback, errorCallback, this);
        }
    }
}
