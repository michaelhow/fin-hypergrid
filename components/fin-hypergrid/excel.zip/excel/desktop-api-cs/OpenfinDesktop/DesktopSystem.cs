﻿/*
 * File DesktopSystem.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Encapsulates the result from a call to DesktopSystem.launchExternalProcess()
    /// </summary>
    public class LaunchExternalProcessResult
    {
        private readonly String processUuid_;

        public LaunchExternalProcessResult()
        {
            processUuid_ = "";
        }

        public LaunchExternalProcessResult(String processUuid)
        {
            processUuid_ = processUuid;
        }

        /// <summary>
        ///     The UUID property represents the mapped UUID for a process launched by DesktopSystem.launchExternalProcess()
        ///     <para>Default: An empty string</para>
        /// </summary> 
        public String UUID
        {
            get
            {
                return processUuid_;
            }
        }
    }

    /// <summary>
    ///     A delegate which receives a mapped process UUID from DesktopSystem.launchExternalProcess()
    /// </summary>
    /// <param name="result">Contains the resulting mapped UUID.</param>
    public delegate void launchExternalProcessHandler(LaunchExternalProcessResult result);

    /// <summary>
    ///     Encapsulates the result from a call to DesktopSystem.terminateExternalProcess().
    ///     The result of the close/terminate can be retrieved by the getter named "Result".
    /// </summary>
    public class TerminateExternalProcessResult
    {
        private readonly String processUuid_;
        private readonly String result_;

        public TerminateExternalProcessResult()
        {
            processUuid_ = "";
            result_ = "failed";
        }

        public TerminateExternalProcessResult(String processUuid, String result)
        {
            processUuid_ = processUuid;
            result_ = result;
        }

        /// <summary>
        ///     The UUID property represents the mapped UUID for a process launched by DesktopSystem.launchExternalProcess()
        ///     <para>Default: An empty string</para>
        /// </summary> 
        public String UUID
        {
            get
            {
                return processUuid_;
            }
        }

        /// <summary>
        ///     The Result property represents how a process termination was handleded.
        ///     
        ///     <para>"clean": The process was closed.</para>
        ///     
        ///     <para>"terminated": The was terminated.</para>
        ///     
        ///     <para>"failed": The close/terminate operation was unable to complete.</para>
        /// 
        /// 
        /// 
        ///     <para>Default: "failed"</para>
        /// </summary> 
        public String Result
        {
            get
            {
                return result_;
            }
        }
    }

    /// <summary>
    ///     A delegate which is passed the resulting status of a process after DesktopSystem.terminateExternalProcess() has completed.
    /// </summary>
    /// <param name="result">Contains the status of the prorcess after the operation has completed.</param>
    public delegate void terminateExternalProcessHandler(TerminateExternalProcessResult result);

    /// <summary>
    ///     An object representing the core of the OpenFin Desktop. Allows the developer to 
    ///     perform system-level actions, such as accessing logs, viewing processes, clearing 
    ///     the cache and exiting the Desktop.
    ///     <para>
    ///         In order to use the System object, an application must have admin-level privileges 
    ///         (e.g., isAdmin must be set to true when in the options when the application is created). 
    ///     </para>
    /// </summary>
    public class DesktopSystem
    {
        private JObject clearCachePayload_ = null;
        private JObject clipboardPayload_ = null;
        private JObject configPayload_ = null;
        private DesktopConnection desktopConnection;
        private JObject developerToolsPayload_ = null;
        private JObject emptyPayload_ = new JObject();
        private JObject eventListenerPayload_ = null;
        private JObject installIconPayload_ = null;
        private JObject launchExternalProcessPayload_ = null;
        private JObject logMessagePayload_ = null;
        private JObject logPayload_ = null;
        private JObject openUrlPayload_ = null;
        private JObject releaseExternalProcessPayload_ = null;
        private JObject terminateExternalProcessPayload_ = null;
        private JObject updateProxyPayload_ = null;

        /// <summary>
        ///     DesktopSystem Constructor.
        /// </summary>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        public DesktopSystem(DesktopConnection desktopConnection)
        {
            this.desktopConnection = desktopConnection;
        }


        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///         deskband-icon-clicked
        ///         desktop-icon-clicked
        ///         monitor-info-changed
        /// </remarks>
        /// <param name="subscriptionObject">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        private void addEventListener(JObject subscriptionObject,
                                      AckCallback listener,
                                      AckCallback callback = null,
                                      AckCallback errorCallback = null)
        {
            this.desktopConnection.addEventCallback(subscriptionObject, 
                                                    listener,  
                                                    callback, 
                                                    errorCallback,
                                                    this);  
        }

        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///         deskband-icon-clicked
        ///         desktop-icon-clicked
        ///         monitor-info-changed
        /// </remarks>
        /// <param name="type">The type of the event.</param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void addEventListener(String type,
                                     AckCallback listener,
                                     AckCallback callback =  null,
                                     AckCallback errorCallback = null)
        {
            if (eventListenerPayload_ == null)
            {
                eventListenerPayload_ = new JObject();
                DesktopUtils.updateJSONValue(eventListenerPayload_, "topic", "system");
            }

            DesktopUtils.updateJSONValue(eventListenerPayload_, "type", type);
            addEventListener(eventListenerPayload_, listener, callback, errorCallback);
        }

        /// <summary>
        ///     Clears cached data containing window state/positions, 
        ///     application resource files (images, HTML, JavaScript files)
        ///     cookies, and items stored in the Local Storage. 
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="cache">If true, clears chrome caches</param>
        /// <param name="cookies">If true, deletes all cookies.</param>
        /// <param name="appcache">If true, clear application caches.</param>
        /// <param name="localStorage">If true, clears local storage.</param>
        /// <param name="userData">If true, clears user data.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void clearCache(bool cache, 
                               bool cookies, 
                               bool localStorage, 
                               bool appcache, 
                               bool userData,
                               AckCallback callback = null,
                               AckCallback errorCallback = null)
        {
            if (clearCachePayload_ == null)
            {
                clearCachePayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(clearCachePayload_, "cache", cache);
            DesktopUtils.updateJSONValue(clearCachePayload_, "cookies", cookies);
            DesktopUtils.updateJSONValue(clearCachePayload_, "localStorage", localStorage);
            DesktopUtils.updateJSONValue(clearCachePayload_, "appcache", appcache);
            DesktopUtils.updateJSONValue(clearCachePayload_, "userData", userData);
            this.desktopConnection.sendAction("clear-cache", clearCachePayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Clears all cached data when App Desktop is restarted. 
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void deleteCacheOnRestart(AckCallback callback = null, 
                                         AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("delete-cache-request", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Exits App Desktop.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void exit(AckCallback callback = null,
                         AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("exit-desktop", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves an array of data (uuid, running/active state) for all application windows. 
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <remarks>
        ///     The object passed to callback takes the form:
        ///     [
        ///         {
        ///             uuid: (string) uuid of the application,
        ///             isRunning: (bool) true when the application is running/active
        ///         },
        ///         ...
        ///     ]
        /// </remarks>
        /// <param name="callback">
        ///     A function that is called and passed an array containing the application UUIDs and running state.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getAllApplications(AckCallback callback,
                                       AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-all-applications", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves an array of data (name, ids, bounds) for all application windows. 
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <remarks>
        ///     The object passed to callback takes the form:
        ///     [
        ///         {
        ///             uuid: (string) uuid of the application,
        ///             mainWindow: {
        ///                 name: (string) name of the main window,
        ///                 top: (integer) top-most coordinate of the main window,
        ///                 right: (integer) right-most coordinate of the main window,
        ///                 bottom: (integer) bottom-most coordinate of the main window,
        ///                 left: (integer) left-most coordinate of the main window
        ///             },
        ///             childWindows: [{
        ///                     name: (string) name of the child window,
        ///                     top: (integer) top-most coordinate of the child window,
        ///                     right: (integer) right-most coordinate of the child window,
        ///                     bottom: (integer) bottom-most coordinate of the child window,
        ///                     left: (integer) left-most coordinate of the child window
        ///                 },
        ///                 ...
        ///             ]
        ///         },
        ///         ...
        ///     ]
        /// </remarks>
        /// <param name="callback">
        ///     A function that is called and passed an array containing the window information.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getAllWindows(AckCallback callback,
                                  AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-all-windows", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves the command line argument string that started App Desktop.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called and passed the command 
        ///     line arguments used to start App Desktop.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getCommandLineArguments(AckCallback callback,
                                            AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-command-line-arguments", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves the App Desktop's configuration.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="section">Which section to return from the configuration.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getConfig(String section, 
                              AckCallback callback, 
                              AckCallback errorCallback = null)
        {
            if (configPayload_ == null)
            {
                configPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(configPayload_, "section", section);
            this.desktopConnection.sendAction("get-config", configPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Gets the UUID of the computer on which App Desktop is installed.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///      A function that is called and passed a unique identifier of the device.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getDeviceId(AckCallback callback,
                                AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-device-id", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves the contents of the log with the specified filename.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="fileName">The filename of the log.</param>
        /// <param name="callback">
        ///      A function that is called and passed the contents of the log.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getLog(String fileName, 
                           AckCallback callback, 
                           AckCallback errorCallback = null)
        {
            if (logPayload_ == null)
            {
                logPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(logPayload_, "name", fileName);
            this.desktopConnection.sendAction("view-log", logPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves an array of data objects for all available logs.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <remarks>
        ///     Each object in the returned array takes the form:
        ///      {
        ///          name: (string) the filename of the log,
        ///          size: (integer) the size of the log in bytes,
        ///          date: (integer) the unix time at which the log was created
        ///      }
        /// </remarks>
        /// <param name="callback">
        ///      A function that is called and passed an array of data objects for all available logs.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getLogList(AckCallback callback,
                               AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("list-logs", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves an object that contains data about the about the 
        ///     monitor setup of the computer that App Desktop is running on.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <remarks>
        ///     The returned object takes the form:
        ///     {
        ///         nonPrimaryMonitors: [{
        ///             availableRect: {
        ///                 bottom: (integer) bottom-most available monitor coordinate,
        ///                 left: (integer) left-most available monitor coordinate,
        ///                 right: (integer) right-most available monitor coordinate,
        ///                 top: (integer) top-most available monitor coordinate
        ///             },
        ///             deviceId: (string) device id of the display,
        ///             displayDeviceActive: (boolean) true if the display is active,
        ///             monitorRect: {
        ///                 bottom: (integer) bottom-most monitor coordinate,
        ///                 left: (integer) left-most monitor coordinate,
        ///                 right: (integer) right-most monitor coordinate,
        ///                 top: (integer) top-most monitor coordinate
        ///             },
        ///             name: (string) name of the display
        ///         },
        ///         ...
        ///         ],
        ///         primaryMonitor: {
        ///             availableRect: {
        ///                 bottom: (integer) bottom-most available monitor coordinate,
        ///                 left: (integer) left-most available monitor coordinate,
        ///                 right: (integer) right-most available monitor coordinate,
        ///                 top: (integer) top-most available monitor coordinate
        ///             },
        ///             deviceId: (string) device id of the display,
        ///             displayDeviceActive: (boolean) true if the display is active,
        ///             monitorRect: {
        ///                 bottom: (integer) bottom-most monitor coordinate,
        ///                 left: (integer) left-most monitor coordinate,
        ///                 right: (integer) right-most monitor coordinate,
        ///                 top: (integer) top-most monitor coordinate
        ///             },
        ///             name: (string) name of the display
        ///         },
        ///         reason: (string) always "api-query",
        ///         taskbar: {
        ///             edge: {string} which edge of a monitor the taskbar is on,
        ///             rect: {
        ///                 bottom: ({integer} bottom-most coordinate of the taskbar),
        ///                 left: ({integer} left-most coordinate of the taskbar),
        ///                 right: ({integer} right-most coordinate of the taskbar),
        ///                 top: ({integer} top-most coordinate of the taskbar)
        ///             }
        ///         },
        ///         virtualScreen: {
        ///             bottom: (integer) bottom-most coordinate of the virtual screen,
        ///             left: (integer) left-most coordinate of the virtual screen,
        ///             right: (integer) right-most coordinate of the virtual screen,
        ///             top: (integer) top-most coordinate of the virtual screen
        ///         }
        ///     }
        /// </remarks>
        /// <param name="callback">
        ///     A function that is called and passed an object containing monitor information
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getMonitorInfo(AckCallback callback,
                                   AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-monitor-info", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Returns the mouse in virtual screen coordinates (left, top).
        /// </summary>
        /// <remarks>
        ///     The returned object takes the form:
        ///     {
        ///         top: (integer) the top position of the mouse in virtual screen
        ///                        coordinates,
        ///         left: (integer) the left position of the mouse in virtual screen
        ///                         coordinates
        ///     }
        /// </remarks>
        /// <param name="callback">
        ///     A function that is called and passed an object containing the position of the mouse.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getMousePosition(AckCallback callback,
                                     AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-mouse-position", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves an array of all App Desktop processes that are currently running.
        ///     <para>
        ///         Each element in the array is an object containing the uuid 
        ///         and the name of the application to which the process belongs. 
        ///     </para>
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <remarks>
        ///     The returned object takes the form:
        ///     [
        ///         {
        ///             cpuUsage: (decimal) the percentage of total CPU usage,
        ///             name: (string) the application name,
        ///             nonPagedPoolUsage: (integer) the current nonpaged pool usage in bytes,
        ///             pageFaultCount: (integer) the number of page faults,
        ///             pagedPoolUsage: (integer) the current paged pool usage in bytes,
        ///             pagefileUsage: (integer) the total amount of memory in bytes that the
        ///                                      memory manager has committed,
        ///             peakNonPagedPoolUsage: (integer) the peak nonpaged pool usage in bytes,
        ///             peakPagedPoolUsage: (integer) the peak paged pool usage in bytes,
        ///             peakPagefileUsage: (integer) the peak value in bytes of pagefileUsage
        ///                                          during the lifetime of this process,
        ///             peakWorkingSetSize: (integer) the peak working set size in bytes,
        ///             processId: (integer) the native process identifier,
        ///             uuid: (string) the application UUID,
        ///             workingSetSize: (integer) the current working set size
        ///                                       (both shared and private data) in bytes
        ///         },
        ///         ...
        ///     ]
        /// </remarks>
        /// <param name="callback">
        ///     A function that is called and passed the process list.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getProcessList(AckCallback callback,
                                   AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("process-snapshot", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Retrieves the proxy settings object.
        /// </summary>
        /// <remarks>
        ///     The proxy object the callback receives takes the following form:
        ///     {
        ///         type: (string) "system" or "named",
        ///         proxyAddress: (string) the address of the proxy server,
        ///         proxyPort: (integer) the port of proxy server
        ///     }
        /// </remarks>
        /// <param name="callback">
        ///     A function that is called and passed the proxy settings object.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getProxySettings(AckCallback callback,
                                     AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-proxy-settings", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Returns the version of App Desktop.
        ///     <para>
        ///         The version contains the major, minor, build and revision numbers (e.g., "2.0.3.0").
        ///     </para>
        /// </summary>
        /// <param name="callback">
        ///     A function that is called and passed the App Desktop version.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getVersion(AckCallback callback,
                               AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("get-version", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Hides the start menu window.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void hideStartWindow(AckCallback callback = null,
                                    AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("hide-start-window", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Installs a start icon in the Windows Deskband.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="enabledIcon">URL of icon when app is enabled.</param>
        /// <param name="disabledIcon">URL of icon when app is disabled.</param>
        /// <param name="hoverIcon">URL of icon for hover over.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void installDeskbandIcon(String enabledIcon,
                                        String disabledIcon,
                                        String hoverIcon,
                                        AckCallback callback = null,
                                        AckCallback errorCallback = null)
        {
            if (installIconPayload_ == null)
            {
                installIconPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(installIconPayload_, "enabledIcon", enabledIcon);
            DesktopUtils.updateJSONValue(installIconPayload_, "disabledIcon", disabledIcon);
            DesktopUtils.updateJSONValue(installIconPayload_, "hoverIcon", hoverIcon);
            this.desktopConnection.sendAction("install-deskband-icon", installIconPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Installs a start icon in the notification tray.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="enabledIcon">URL of icon when app is enabled.</param>
        /// <param name="disabledIcon">URL of icon when app is disabled.</param>
        /// <param name="hoverIcon">URL of icon for hover over.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void installStartIcon(String enabledIcon, 
                                     String disabledIcon, 
                                     String hoverIcon,
                                     AckCallback callback = null,
                                     AckCallback errorCallback = null)
        {
            if (installIconPayload_ == null)
            {
                installIconPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(installIconPayload_, "enabledIcon", enabledIcon);
            DesktopUtils.updateJSONValue(installIconPayload_, "disabledIcon", disabledIcon);
            DesktopUtils.updateJSONValue(installIconPayload_, "hoverIcon", hoverIcon);
            this.desktopConnection.sendAction("install-start-icon", installIconPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Runs an executable or batch file.
        /// </summary>
        /// <param name="path">The path of the file to launch via the command line.</param>
        /// <param name="commandLine">The command line arguments to pass.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds. 
        ///     Receives a LaunchExternalProcessResult containing the UUID mapping to the launched process.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void launchExternalProcess(String path,
                                          String commandLine,
                                          launchExternalProcessHandler callback = null,
                                          AckCallback errorCallback = null)
        {
            if (launchExternalProcessPayload_ == null)
            {
                launchExternalProcessPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(launchExternalProcessPayload_, "path", path);
            DesktopUtils.updateJSONValue(launchExternalProcessPayload_, "commandLine", commandLine);

            AckCallback mainCallback = null;
            if (callback != null)
            {
                mainCallback = (launchResult) =>
                {
                    // Retrieve the UUID from the result, create the  LaunchExternalProcessResult and pass to the delegate
                    callback(new LaunchExternalProcessResult(DesktopUtils.getJSONString(launchResult.getData(), "uuid", "")));
                };
            }

            this.desktopConnection.sendAction("launch-external-process", launchExternalProcessPayload_, mainCallback, errorCallback, this);
        }

        /// <summary>
        ///     Writes a message to the log.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="level">
        ///     The log level for the entry. Can be either "info", "warning" or "error".
        /// </param>
        /// <param name="message">
        ///     The log message text.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void log(String level, 
                        String message, 
                        AckCallback callback = null,
                        AckCallback errorCallback = null)
        {
            if (logMessagePayload_ == null)
            {
                logMessagePayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(logMessagePayload_, "level", level);
            DesktopUtils.updateJSONValue(logMessagePayload_, "message", message);
            this.desktopConnection.sendAction("write-to-log", logMessagePayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Opens the passed URL
        /// </summary>
        /// <param name="url">The URL of the page to open.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void openUrlWithBrowser(String url, 
                                       AckCallback callback = null,
                                       AckCallback errorCallback = null)
        {
            if (openUrlPayload_ == null)
            {
                openUrlPayload_ = new JObject();
            }
            DesktopUtils.updateJSONValue(openUrlPayload_, "url", url);
            this.desktopConnection.sendAction("open-url-with-browser", openUrlPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes the process entry for the passed UUID obtained 
        ///     from a previous call to DesktopSystem.launchExternalProcess().
        /// </summary>
        /// <param name="processUuid">The UUID for a process launched by DesktopSystem.launchExternalProcess()</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void releaseExternalProcess(String processUuid, 
                                           AckCallback callback = null,
                                           AckCallback errorCallback = null)
        {
            if (releaseExternalProcessPayload_ == null)
            {
                releaseExternalProcessPayload_ = new JObject();
            }
            DesktopUtils.updateJSONValue(releaseExternalProcessPayload_, "uuid", processUuid);
            this.desktopConnection.sendAction("release-external-process", releaseExternalProcessPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes a start icon from the Windows Deskband.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void removeDeskbandIcon(AckCallback callback = null,
                                       AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("remove-deskband-icon", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes a previously registered event listener from the specified event.
        ///     <para>
        ///         The listener is passed an event object containing information 
        ///         related to the event.
        ///     </para>
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///          deskband-icon-clicked
        ///          desktop-icon-clicked
        ///          monitor-info-changed
        /// </remarks>
        /// <param name="type">The type of the event.</param>
        /// <param name="listener">
        ///     A function that was called whenever an event of the specified type occurs.
        ///     It is no longer called in response to an event of the passed type.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void removeEventListener(String type,
                                        AckCallback listener,
                                        AckCallback callback = null,
                                        AckCallback errorCallback = null)
        {
            if (eventListenerPayload_ == null)
            {
                eventListenerPayload_ = new JObject();
                DesktopUtils.updateJSONValue(eventListenerPayload_, "topic", "system");
            }
            DesktopUtils.updateJSONValue(eventListenerPayload_, "type", type);
            this.desktopConnection.removeEventCallback(eventListenerPayload_, 
                                                       listener, 
                                                       callback, 
                                                       errorCallback,
                                                       this);
        }

        /// <summary>
        ///     Removes a start icon from the notification tray.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void removeStartIcon(AckCallback callback = null,
                                    AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("remove-start-icon", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Copies text to the clipboard
        /// </summary>
        /// <param name="text">The text to copy</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void setClipboard(String text,
                                 AckCallback callback = null,
                                 AckCallback errorCallback = null)
        {
            if (clipboardPayload_ == null)
            {
                clipboardPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(clipboardPayload_, "data", text);
            this.desktopConnection.sendAction("set-clipboard", clipboardPayload_, callback, errorCallback, this);
        }


        /// <summary>
        ///     Shows Developer tool
        /// </summary>
        /// <param name="applicationUUID">The application ID</param>
        /// <param name="windowName">The name of dev tool window</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void showDeveloperTools(String applicationUUID, 
                                       String windowName, 
                                       AckCallback callback = null,
                                       AckCallback errorCallback = null)
        {
            if (developerToolsPayload_ == null)
            {
                developerToolsPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(developerToolsPayload_, "uuid", applicationUUID);
            DesktopUtils.updateJSONValue(developerToolsPayload_, "name", windowName);
            this.desktopConnection.sendAction("show-developer-tools", developerToolsPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Shows Shows the start menu window.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void showStartWindow(AckCallback callback = null,
                                    AckCallback errorCallback = null)
        {
            this.desktopConnection.sendAction("show-start-window", emptyPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Attempts to cleanly close an external process and terminates it 
        ///     if the close has not occured after the elapsed timeout in milliseconds.
        /// </summary>
        /// <param name="processUuid">The UUID for a process launched by DesktopSystem.launchExternalProcess()</param>
        /// <param name="timeout">The time in milliseconds to wait for a close to occur before terminating.</param>
        /// <param name="killTree">Explicitly terminates all child processes when true.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds. 
        ///     The result of the operation is returned as a TerminateExternalProcessResult
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void terminateExternalProcess(String processUuid, 
                                             uint timeout,
                                             bool killTree,
                                             terminateExternalProcessHandler callback = null,
                                             AckCallback errorCallback = null)
        {
            if (terminateExternalProcessPayload_ == null)
            {
                terminateExternalProcessPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(terminateExternalProcessPayload_, "uuid", processUuid);
            DesktopUtils.updateJSONValue(terminateExternalProcessPayload_, "timeout", timeout);
            DesktopUtils.updateJSONValue(terminateExternalProcessPayload_, "child", timeout);

            AckCallback mainCallback = null;
            if (callback != null)
            {
                mainCallback = (launchResult) =>
                {
                    // Retrieve the UUID from the result, create the  LaunchExternalProcessResult and pass to the delegate
                    callback(new TerminateExternalProcessResult(processUuid, 
                                                                DesktopUtils.getJSONString(launchResult.getData(), "result", "failed")));
                };
            }

            this.desktopConnection.sendAction("terminate-external-process", terminateExternalProcessPayload_, mainCallback, errorCallback, this);
        }

        /// <summary>
        ///     Updates the proxy settings.
        ///     <para>Requires administrator privileges.</para>
        /// </summary>
        /// <remarks>
        ///     the passed type can be either "system" or "named". 
        ///     Use "system" to use the default system proxy settings. 
        ///     Otherwise use "named" to specify the address and port 
        ///     of the proxy server.
        /// </remarks>
        /// <param name="type">The type of proxy. </param>
        /// <param name="proxyAddress">
        ///     The address of the proxy. Example: "example.yourproxyserver.com".
        /// </param>
        /// <param name="proxyPort">The port of the proxy server.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void updateProxySettings(String type, 
                                        String proxyAddress, 
                                        int proxyPort, 
                                        AckCallback callback = null,
                                        AckCallback errorCallback = null)
        {
            if (updateProxyPayload_ == null)
            {
                updateProxyPayload_ = new JObject();
            }

            DesktopUtils.updateJSONValue(updateProxyPayload_, "type", type);
            DesktopUtils.updateJSONValue(updateProxyPayload_, "proxyAddress", proxyAddress);
            DesktopUtils.updateJSONValue(updateProxyPayload_, "proxyPort", proxyPort);
            this.desktopConnection.sendAction("update-proxy", updateProxyPayload_, callback, errorCallback, this);
        }
    }
}