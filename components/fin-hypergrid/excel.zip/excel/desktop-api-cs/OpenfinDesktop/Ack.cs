﻿/*
 * File Ack.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A message that is delivered to an AckListener when an action has 
    ///     been processed by AppDesktop
    /// </summary>
    public class Ack : EventArgs
    {
        private JObject message;
        private object source;

        /// <summary>
        ///     class Ack constructor.
        /// </summary>
        /// <param name="message">The message being delivered to the AckListener.</param>
        /// <param name="source">The message source.</param>
        public Ack(JObject message, object source)
        {
            this.message = message;
            this.source = source;
        }

        /// <summary>
        ///     Returns true if message contains "success":"true".
        /// </summary>
        public bool isSuccessful()
        {
            bool success = false;
            success = DesktopUtils.getJSONBool(message, "success");
            return success;
        }

        /// <summary>
        ///     Returns the message as a JObject.
        /// </summary>
        public JObject getJsonObject()
        {
            return message;
        }

        /// <summary>
        ///     Returns the value of "data" from message as JObject.
        /// </summary>
        public JObject getData()
        {
            return DesktopUtils.getJSONObject(message, "data", new JObject());
        }

        /// <summary>
        ///     Returns the message source.
        /// </summary>
        public object getSource()
        {
            return this.source;
        }
    }
}
