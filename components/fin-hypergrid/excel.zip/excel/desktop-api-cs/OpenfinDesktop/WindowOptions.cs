﻿/*
 * File WindowOptions.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A class representing the options for a Window.
    /// </summary>
    public class WindowOptions
    {
        private JObject options;

        /// <summary>
        ///     Constructs an instance with a new underliying JObject.
        /// </summary>
        public WindowOptions() { options = new JObject(); }

        /// <summary>
        ///     Constructs an instance with the passed options.
        /// </summary>
        /// <param name="options">a JObject containing window settings.</param>
        public WindowOptions(JObject options)
        {
            this.options = options;
        }

        /// <summary>
        ///     Constructs an instance with a new underliying JObject.
        /// </summary>
        /// <param name="name">The windows name</param>
        public WindowOptions(String name)
        {
            options = new JObject();
            Name = name;
        }

        /// <summary>
        ///     Gets all settings in JObject format.
        /// </summary>
        public JObject getJsonCopy()
        {
            return JObject.Parse(options.ToString());
        }

        /// <summary>
        ///     Gets the underliying JObject containing the options.
        /// </summary>
        private JObject Raw
        {
            get { return this.options; }
        }

        // ====================================================================
        // Required
        // ====================================================================

        /// <summary>
        ///     The Name property represents the name for the window which 
        ///     must be unique within the context of the invoking Application.
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The Name property gets/sets the value of the underlying 
        ///     JObject field, "name".
        /// </value> 
        public String Name
        {
            get { return DesktopUtils.getJSON<String>(options, "name", ""); }
            set { DesktopUtils.updateJSONValue(options, "name", value); }
        }

        // ====================================================================
        // Optional
        // ====================================================================

        /// <summary>
        ///     The AlwaysOnBottom property represents a flag to always position 
        ///     the window at the bottom of the window stack.
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The AlwaysOnBottom property gets/sets the value of the 
        ///     underlying JObject field, "alwaysOnBottom".
        /// </value> 
        public bool AlwaysOnBottom
        {
            get { return DesktopUtils.getJSON<bool>(options, "alwaysOnBottom", false); }
            set { DesktopUtils.updateJSONValue(options, "alwaysOnBottom", value); }
        }

        /// <summary>
        ///     The AlwaysOnTop property represents a flag to always position 
        ///     the window at the top of the window stack.  
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The AlwaysOnTop property gets/sets the value of the 
        ///     underlying JObject field, "alwaysOnTop".
        /// </value>
        public bool AlwaysOnTop
        {
            get { return DesktopUtils.getJSON<bool>(options, "alwaysOnTop", false); }
            set { DesktopUtils.updateJSONValue(options, "alwaysOnTop", value); }
        }

        /// <summary>
        ///     The AutoShow property represents a flag to automatically 
        ///     show the Window when it is created.
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The AutoShow property gets/sets the value of the 
        ///     underlying JObject field, "autoShow".
        /// </value>
        public bool AutoShow
        {
            get { return DesktopUtils.getJSON<bool>(options, "autoShow", false); }
            set { DesktopUtils.updateJSONValue(options, "autoShow", value); }
        }

        /// <summary>
        ///     The ContextMenu property represents a flag to show the 
        ///     context menu when right-clicking on a window.
        ///     <para>Gives access to the Developer Console for the Window.</para>
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The ContextMenu property gets/sets the value of the 
        ///     underlying JObject field, "contextMenu".
        /// </value>
        public bool ContextMenu
        {
            get { return DesktopUtils.getJSON<bool>(options, "contextMenu", false); }
            set { DesktopUtils.updateJSONValue(options, "contextMenu", value); }
        }

        /// <summary>
        ///     The CornerRoundingHeight property represents the rounded 
        ///     corners height to apply.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The CornerRoundingHeight property gets/sets the value of the 
        ///     underlying JObject field, "cornerRounding.height".
        /// </value>
        public int CornerRoundingHeight
        {
            get { return DesktopUtils.getJSON<int>(options, "cornerRounding.height", 0); }
            set { DesktopUtils.updateJSONValue(options, "cornerRounding.height", value); }
        }

        /// <summary>
        ///     The CornerRoundingWidth property represents the rounded 
        ///     corners width to apply.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The CornerRoundingWidth property gets/sets the value of the 
        ///     underlying JObject field, "cornerRounding.width".
        /// </value>
        public int CornerRoundingWidth
        {
            get { return DesktopUtils.getJSON<int>(options, "cornerRounding.width", 0); }
            set { DesktopUtils.updateJSONValue(options, "cornerRounding.width", value); }
        }

        /// <summary>
        ///     The DefaultCentered property specifies that the window will be positioned in the 
        ///     center of the primary monitor when loaded for the first time on a machine. 
        ///
        ///     <para>Default: false</para>
        /// </summary> 
        /// <remarks>
        ///     When the window corresponding to that id is loaded again, the position 
        ///     from before the window was closed is used.
        /// </remarks>
        /// <value>
        ///     The DefaultCentered property gets/sets the value of the 
        ///     underlying JObject field, "defaultCentered".
        /// </value>
        public bool DefaultCentered
        {
            get { return DesktopUtils.getJSON<bool>(options, "defaultCentered", false); }
            set { DesktopUtils.updateJSONValue(options, "defaultCentered", value); }
        }

        /// <summary>
        ///     The DefaultHeight property represents the window's 
        ///     default height in pixels.
        ///     <para>Default: 500</para>
        /// </summary> 
        /// <remarks>
        ///     Specifies the height of the window when loaded for the first 
        ///     time on a machine. When a window with the same name and 
        ///     parent application UUID is loaded again, the height is taken to be the 
        ///     last height of the window before it was closed.
        /// </remarks>
        /// <value>
        ///     The DefaultHeight property gets/sets the value of the 
        ///     underlying JObject field, "defaultHeight".
        /// </value>
        public int DefaultHeight
        {
            get { return DesktopUtils.getJSON<int>(options, "defaultHeight", 500); }
            set { DesktopUtils.updateJSONValue(options, "defaultHeight", value); }
        }

        /// <summary>
        ///     The DefaultLeft property represents the window's 
        ///     default left position.
        ///     <para>Default: 100</para>
        /// </summary> 
        /// <remarks>
        ///     Specifies the left position of the window when loaded for the first 
        ///     time on a machine. When a window with the same name and 
        ///     parent application UUID is loaded again, the value of left is 
        ///     taken to be the last value before the window was closed.
        /// </remarks>
        /// <value>
        ///     The DefaultLeft property gets/sets the value of the 
        ///     underlying JObject field, "defaultLeft".
        /// </value>
        public int DefaultLeft
        {
            get { return DesktopUtils.getJSON<int>(options, "defaultLeft", 100); }
            set { DesktopUtils.updateJSONValue(options, "defaultLeft", value); }
        }

        /// <summary>
        ///     The DefaultTop property represents the window's 
        ///     default top position.
        ///     <para>Default: 100</para>
        /// </summary> 
        /// <remarks>
        ///     Specifies the top position of the window when loaded for the first 
        ///     time on a machine. When a window with the same name and 
        ///     parent application UUID is loaded again, the value of top is 
        ///     taken to be the last value before the window was closed.
        /// </remarks>
        /// <value>
        ///     The DefaultTop property gets/sets the value of the 
        ///     underlying JObject field, "defaultTop".
        /// </value>
        public int DefaultTop
        {
            get { return DesktopUtils.getJSON<int>(options, "defaultTop", 100); }
            set { DesktopUtils.updateJSONValue(options, "defaultTop", value); }
        }


        /// <summary>
        ///     The DefaultWidth property represents the window's 
        ///     default width in pixels.
        ///     <para>Default: 800</para>
        /// </summary> 
        /// <remarks>
        ///     Specifies the width of the window when loaded for the first 
        ///     time on a machine. When a window with the same name and 
        ///     parent application UUID is loaded again, the height is taken to be the 
        ///     last width of the window before it was closed.
        /// </remarks>
        /// <value>
        ///     The DefaultWidth property gets/sets the value of the 
        ///     underlying JObject field, "defaultWidth".
        /// </value>
        public int DefaultWidth
        {
            get { return DesktopUtils.getJSON<int>(options, "defaultWidth", 800); }
            set { DesktopUtils.updateJSONValue(options, "defaultWidth", value); }
        }

        /// <summary>
        ///     The Draggable property represents a flag to allow 
        ///     the user to drag the window by its client area. 
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The Draggable property gets/sets the value of the 
        ///     underlying JObject field, "draggable".
        /// </value>
        public bool Draggable
        {
            get { return DesktopUtils.getJSON<bool>(options, "draggable", false); }
            set { DesktopUtils.updateJSONValue(options, "draggable", value); }
        }

        /// <summary>
        ///     The Frame property represents a flag to show the frame. 
        ///     <para>Default: true</para>
        /// </summary> 
        /// <value>
        ///     The Frame property gets/sets the value of the 
        ///     underlying JObject field, "frame".
        /// </value>
        public bool Frame
        {
            get { return DesktopUtils.getJSON<bool>(options, "frame", true); }
            set { DesktopUtils.updateJSONValue(options, "frame", value); }
        }

        /// <summary>
        ///     The HideOnClose property represents a flag to allow a window 
        ///     to be hidden when the close button is clicked.
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The HideOnClose property gets/sets the value of the 
        ///     underlying JObject field, "hideOnClose".
        /// </value>
        public bool HideOnClose
        {
            get { return DesktopUtils.getJSON<bool>(options, "hideOnClose", false); }
            set { DesktopUtils.updateJSONValue(options, "hideOnClose", value); }
        }

        /// <summary>
        ///     The MaxHeight property represents the maximum height of a window.
        ///     <para>Will default to the OS defined value if set to -1.</para>
        ///     <para>Default: -1</para>
        /// </summary> 
        /// <value>
        ///     The MaxHeight property gets/sets the value of the 
        ///     underlying JObject field, "maxHeight".
        /// </value>
        public int MaxHeight
        {
            get { return DesktopUtils.getJSON<int>(options, "maxHeight", -1); }
            set { DesktopUtils.updateJSONValue(options, "maxHeight", value); }
        }

        /// <summary>
        ///     The Maximizable property represents a flag that lets the window be maximized.
        ///     <para>Default: true</para>
        /// </summary> 
        /// <value>
        ///     The Maximizable property gets/sets the value of the 
        ///     underlying JObject field, "maximizable".
        /// </value>
        public bool Maximizable
        {
            get { return DesktopUtils.getJSON<bool>(options, "maximizable", true); }
            set { DesktopUtils.updateJSONValue(options, "maximizable", value); }
        }

        /// <summary>
        ///     The MaxWidth property represents the maximum width  of a window.
        ///     <para>Will default to the OS defined value if set to -1.</para>
        ///     <para>Default: -1</para>
        /// </summary> 
        /// <value>
        ///     The MaxWidth property gets/sets the value of the 
        ///     underlying JObject field, "maxWidth".
        /// </value>
        public int MaxWidth
        {
            get { return DesktopUtils.getJSON<int>(options, "maxWidth", -1); }
            set { DesktopUtils.updateJSONValue(options, "maxWidth", value); }
        }

        /// <summary>
        ///     The MinHeight property represents the minimum height of a window.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The MinHeight property gets/sets the value of the 
        ///     underlying JObject field, "minHeight".
        /// </value>
        public int MinHeight
        {
            get { return DesktopUtils.getJSON<int>(options, "minHeight", 0); }
            set { DesktopUtils.updateJSONValue(options, "minHeight", value); }
        }

        /// <summary>
        ///     The Minimizable property represents a flag that lets the window be minimized.
        ///     <para>Default: true</para>
        /// </summary> 
        /// <value>
        ///     The Minimizable property gets/sets the value of the 
        ///     underlying JObject field, "minimizable".
        /// </value>
        public bool Minimizable
        {
            get { return DesktopUtils.getJSON<bool>(options, "minimizable", true); }
            set { DesktopUtils.updateJSONValue(options, "minimizable", value); }
        }

        /// <summary>
        ///     The MinWidth property represents the minimum width of a window.
        ///     <para>Default: 0</para>
        /// </summary> 
        /// <value>
        ///     The MinWidth property gets/sets the value of the 
        ///     underlying JObject field, "minWidth".
        /// </value>
        public int MinWidth
        {
            get { return DesktopUtils.getJSON<int>(options, "minWidth", 0); }
            set { DesktopUtils.updateJSONValue(options, "minWidth", value); }
        }

        /// <summary>
        ///     The Opacity property represents a flag that specifies 
        ///     how transparent the window will be.
        ///     <para>Default: 1.0</para>
        /// </summary> 
        /// <value>
        ///     The Opacity property gets/sets the value of the 
        ///     underlying JObject field, "opacity".
        /// </value>
        public double Opacity
        {
            get { return DesktopUtils.getJSON<double>(options, "opacity", 1.0); }
            set { DesktopUtils.updateJSONValue(options, "opacity", Math.Max(0.0, Math.Min(1.0, value))); }
        }

        /// <summary>
        ///     The Resizable property represents a flag which allows 
        ///     the user to resize the window.
        ///     <para>This property will be deprecated in a future release.</para>
        ///     <para>Default: true</para>
        /// </summary> 
        /// <value>
        ///     The Resizable property gets/sets the value of the 
        ///     underlying JObject field, "resizable".
        /// </value>
        public bool Resizable
        {
            get { return DesktopUtils.getJSON<bool>(options, "resizable", true); }
            set { DesktopUtils.updateJSONValue(options, "resizable", value); }
        }

        /// <summary>
        ///     The ResizeRegionBottomRightCorner property defines an additional square 
        ///     region located at the bottom right corner of a frameless window.
        ///     <para>Default: 4</para>
        /// </summary> 
        /// <value>
        ///     The ResizeRegionBottomRightCorner property gets/sets the value of the 
        ///     underlying JObject field, "resizeRegion.bottomRightCorner".
        /// </value>
        public int ResizeRegionBottomRightCorner
        {
            get { return DesktopUtils.getJSON<int>(options, "resizeRegion.bottomRightCorner", 4); }
            set { DesktopUtils.updateJSONValue(options, "resizeRegion.bottomRightCorner", value); }
        }

        /// <summary>
        ///     The ResizeRegionSize property defines a region 
        ///     in pixels that will respond to user mouse interaction for resizing a frameless window
        ///     <para>Default: 2</para>
        /// </summary> 
        /// <value>
        ///     The ResizeRegionSize property gets/sets the value of the 
        ///     underlying JObject field, "resizeRegion.size".
        /// </value>
        public int ResizeRegionSize
        {
            get { return DesktopUtils.getJSON<int>(options, "resizeRegion.size", 2); }
            set { DesktopUtils.updateJSONValue(options, "resizeRegion.size", value); }
        }

        /// <summary>
        ///     The ShowTaskbarIcon property represents a flag to show 
        ///     the Window's icon in the taskbar.
        ///     <para>Default: false</para>
        /// </summary> 
        /// <value>
        ///     The ShowTaskbarIcon property gets/sets the value of the 
        ///     underlying JObject field, "showTaskbarIcon".
        /// </value>
        public bool ShowTaskbarIcon
        {
            get { return DesktopUtils.getJSON<bool>(options, "showTaskbarIcon", false); }
            set { DesktopUtils.updateJSONValue(options, "showTaskbarIcon", value); }
        }

        /// <summary>
        ///     The TaskbarIcon property represents the URL of 
        ///     an icon to be shown on the desktop.
        ///     <para>
        ///         Support formats: 
        ///             Portable Network Graphic (PNG); Size: 256 x 256 
        ///     </para>
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The TaskbarIcon property gets/sets the value of the 
        ///     underlying JObject field, "taskbarIcon".
        /// </value>
        public String TaskbarIcon
        {
            get { return DesktopUtils.getJSON<String>(options, "taskbarIcon", ""); }
            set { DesktopUtils.updateJSONValue(options, "taskbarIcon", value); }
        }

        /// <summary>
        ///     The State property represents a string that sets the 
        ///     window to be "minimized", "maximized", or "normal" on creation. 
        ///     <para>Default: "normal"</para>
        /// </summary> 
        /// <value>
        ///     The State property gets/sets the value of the 
        ///     underlying JObject field, "state".
        /// </value>
        public String State
        {
            get { return DesktopUtils.getJSON<String>(options, "state", "normal"); }
            set { DesktopUtils.updateJSONValue(options, "state", value); }
        }

        /// <summary>
        ///     The URL property represents the URL of the window. 
        ///     <para>Default: "about:blank"</para>
        /// </summary> 
        /// <value>
        ///     The URL property gets/sets the value of the 
        ///     underlying JObject field, "url".
        /// </value>
        public String URL
        {
            get { return DesktopUtils.getJSON<String>(options, "url", "about:blank"); }
            set { DesktopUtils.updateJSONValue(options, "url", value); }
        }
    }
}
