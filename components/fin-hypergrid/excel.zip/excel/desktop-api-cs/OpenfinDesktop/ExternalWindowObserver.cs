﻿/*
 * File ExternalWindowObserver.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Collections.Concurrent;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Integrates a window outside of the desktop for interaction and control with the API.
    /// </summary>
    /// <remarks>
    ///     An integrated window is controlled in the same way as an HTML window running in the desktop. 
    ///     It can be controlled and queried by the API,
    ///     generate events that are subscribed to by addEventListener, 
    ///     and join/merge groups with other windows for docking.
    /// </remarks>
    public class ExternalWindowObserver : IDisposable, DesktopStateListener
    {
        private readonly String appUuid_;                   // The Application's UUID to create and add this window as a child of.
        private readonly DesktopConnection connection_;     // Ensure each window has a unique connection with the container. Each HTML window would have a unique connection so this simuemulates that guarantee.
        private readonly IntPtr hWnd_;                      // The HWND of the window to control/observe
        private readonly String name_;                      // The unique name for this window as a child window.
        private readonly uint subscribedSystemEvents_;      // An OR'ed combination of SC_ events to process for WM_SYSCOMMAND.

        // (No threadsafe checks for callback) 
        private bool frameDisabled_ = false; // True on "window-frame-disabled". False on "window-frame-enabled".
        private bool registered_ = false;                   // True when this window has been successfully registered with the container. 
       
        // Used in UI event loop
        private bool handlinguserDisabledFrame = false;
        private bool ignoreNextChange_ = false;

        // Payloads for event propagation to the container
        private JObject blurPayload_;
        private JObject captureChangedPayload_;
        private JObject destroyedPayload_;
        private JObject enterSizeMovePayload_;
        private JObject exitSizeMovePayload_;
        private JObject focusPayload_;
        private JObject movePayload_;
        private JObject movingPayload_;
        private JObject ncDoubleClickPayload_;
        private JObject posChangedPayload_;
        private JObject posChangingPayload_;
        private JObject sizingPayload_;
        private JObject sysCommandPayload_;

        // End payloads

        /// <summary>
        ///     The UUID property represents the UUID of 
        ///     the application this window is a child of.
        /// </summary> 
        public String UUID
        {
            get { return appUuid_; }
        }

        /// <summary>
        ///     The Name property represents the name for the window which 
        ///     must be unique within the context of the invoking Application.
        /// </summary> 
        public String Name
        {
            get { return name_; }
        }

        /// <summary>
        ///     Establishes a connection and registers 
        ///     the window identified by hWnd with the desktop.
        /// </summary>
        /// <param name="host">The host that the desktop is running on.</param>
        /// <param name="port">The port that the desktop is listening on for connections.</param>
        /// <param name="parentAppUuid">The UUID of the application to create register this window as a child of.</param>
        /// <param name="name">The unique name for this window as a child window.</param>
        /// <param name="hWnd">The HWND of the window to control/observe.</param>
        public ExternalWindowObserver(String host, int port, String parentAppUuid, String name, IntPtr hWnd)
        {
            connection_ = new DesktopConnection(System.Guid.NewGuid().ToString(), host, port);

            // Only send the desktop the following events
            subscribedSystemEvents_ = (Win32.SC_CLOSE | Win32.SC_MAXIMIZE | Win32.SC_MINIMIZE | Win32.SC_RESTORE);

            hWnd_ = hWnd;
            appUuid_ = parentAppUuid;
            name_ = name;
            connection_.connect(this);
        }

        /// <summary>
        ///     Resets the normal WndProc.
        /// </summary>
        private void restoreWndProc()
        {
            WindowHookHelper.UnhookWndProc(hWnd_);
        }

        /// <summary>
        ///     deregisters the window with the desktop.
        /// </summary>
        private void cleanup()
        {
            // Notify the desktop to remove this external window
            deregisterExternalWindow();

            // Reset the normal WndProc
            restoreWndProc();

            // Ensure the deregister gets sent.
            connection_.disconnect();
            connection_.joinWebSocketThread();
        }

        /// <summary>
        ///     Ensures this window is deregistered on disposal.
        /// </summary>
        public void Dispose()
        {
            cleanup();
        }

        /// <summary>
        ///     Triggered when a "frame-enabled" event is triggered for the registered external window.
        /// </summary>
        /// <param name="ack">Contains additional information provided by the AppDesktop</param>
        private void onWindowFrameEnabled(Ack ack)
        {
            frameDisabled_ = false;
        }

        /// <summary>
        ///     Triggered when a "frame-disabled" event is triggered for the registered external window.
        /// </summary>
        /// <param name="ack">Contains additional information provided by the AppDesktop</param>
        private void onWindowFrameDisabled(Ack ack)
        {
            frameDisabled_ = true;
        }

        /// <summary>
        ///     Notifies the desktop to track, control and observe events for this window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        private void registerExternalWindow(AckCallback callback = null,
                                            AckCallback errorCallback = null)
        {
            JObject registerExternalWindowPayload = new JObject();
            DesktopUtils.updateJSONValue(registerExternalWindowPayload, "topic", "application");
            DesktopUtils.updateJSONValue(registerExternalWindowPayload, "uuid", appUuid_);
            DesktopUtils.updateJSONValue(registerExternalWindowPayload, "hwnd", hWnd_.ToString("X8"));
            DesktopUtils.updateJSONValue(registerExternalWindowPayload, "name", name_);

            AckCallback subscribeToFrameSateChange = (ack) =>
            {
                // Subscribe to frame state change events
                Window wnd = Window.wrap(appUuid_, name_, connection_);
                wnd.addEventListener("frame-disabled", onWindowFrameDisabled);
                wnd.addEventListener("frame-enabled", onWindowFrameEnabled);

                if (callback != null)
                {
                    callback(ack);
                }
            };

            connection_.sendAction("register-external-window", registerExternalWindowPayload, subscribeToFrameSateChange, errorCallback, this);
        }

        /// <summary>
        ///     Notifies the desktop to stop all integration with this window, and remove it from the app.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        private void deregisterExternalWindow(AckCallback callback = null,
                                              AckCallback errorCallback = null)
        {
            if (registered_)
            {
                registered_ = false;
                JObject deregisterExternalWindowPayload = new JObject();
                DesktopUtils.updateJSONValue(deregisterExternalWindowPayload, "topic", "application");
                DesktopUtils.updateJSONValue(deregisterExternalWindowPayload, "uuid", appUuid_);
                DesktopUtils.updateJSONValue(deregisterExternalWindowPayload, "hwnd", hWnd_.ToString("X8"));
                DesktopUtils.updateJSONValue(deregisterExternalWindowPayload, "name", name_);

                AckCallback deSubscribeToFrameSateChange = (ack) =>
                {
                    // Subscribe to frame state change events
                    Window wnd = Window.wrap(appUuid_, name_, connection_);
                    wnd.removeEventListener("frame-disabled", onWindowFrameDisabled);
                    wnd.removeEventListener("frame-enabled", onWindowFrameEnabled);

                    if (callback != null)
                    {
                        callback(ack);
                    }
                };

                connection_.sendAction("deregister-external-window", deregisterExternalWindowPayload, deSubscribeToFrameSateChange, errorCallback, this);
            }
        }

        /// <summary>
        ///     Sends a serialized WM message as JSON to the desktop.
        /// </summary>
        /// <param name="payload">The serialized WM message</param>
        private void sendExternalWindowEvent(JObject payload)
        {
            if (registered_)
            {
                connection_.sendAction("external-window-action", payload, null, null, this);
            }
        }

        private JObject installMessageHandler(WindowHookHelper.WndProcCallback callback,
                                              uint msg,
                                              bool intercept = true)
        {
            JObject payload = new JObject();
            DesktopUtils.updateJSONValue(payload, "uuid", appUuid_);
            DesktopUtils.updateJSONValue(payload, "name", name_);
            DesktopUtils.updateJSONValue(payload, "type", msg);
            WindowHookHelper.HookWndProc(hWnd_, callback, msg, intercept);
            return payload;
        }

        /// <summary>
        ///     Install delegates to send WM events to the desktop 
        /// </summary>
        private void installMessageHandlers() 
        {
            // WM_CAPTURECHANGED
            captureChangedPayload_ = installMessageHandler(onCaptureChanged, Win32.WM_CAPTURECHANGED);

            // WM_DESTROY
            destroyedPayload_ = installMessageHandler(onDestroyed, Win32.WM_DESTROY);

            // WM_ENTERSIZEMOVE
            enterSizeMovePayload_ = installMessageHandler(onEnterSizeMove, Win32.WM_ENTERSIZEMOVE);

            // WM_EXITSIZEMOVE
            exitSizeMovePayload_ = installMessageHandler(onExitSizeMove, Win32.WM_EXITSIZEMOVE);

            // WM_KILLFOCUS
            blurPayload_ = installMessageHandler(onKillFocus, Win32.WM_KILLFOCUS);

            // WM_MOVE
            movePayload_ = installMessageHandler(onMove, Win32.WM_MOVE);

            // WM_MOVING
            movingPayload_ = installMessageHandler(onMoving, Win32.WM_MOVING);

            // WM_NCLBUTTONDBLCLK
            ncDoubleClickPayload_ = installMessageHandler(onNcDoubleClick, Win32.WM_NCLBUTTONDBLCLK, false);

            // WM_SETFOCUS
            focusPayload_ = installMessageHandler(onSetFocus, Win32.WM_SETFOCUS);

            // WM_SYSCOMMAND (for SC_CLOSE, SC_MAXIMIZE, SC_MINIMIZE and SC_RESTORE)
            sysCommandPayload_ = installMessageHandler(onSysCommand, Win32.WM_SYSCOMMAND, false);

            // WM_WINDOWPOSCHANGED
            posChangedPayload_ = installMessageHandler(onWindowPosChanged, Win32.WM_WINDOWPOSCHANGED);

            // WM_WINDOWPOSCHANGING
            posChangingPayload_ = installMessageHandler(onWindowPosChanging, Win32.WM_WINDOWPOSCHANGING);

            // WM_SIZING
            sizingPayload_ = installMessageHandler(onSizing, Win32.WM_SIZING);
        }

        /// <summary>
        ///     Called in response to WM_CAPTURECHANGED .
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_CAPTURECHANGED</param>
        /// <param name="wParam">
        ///     This parameter is not used.
        /// </param>
        /// <param name="lParam">
        ///     A handle to the window gaining the mouse capture.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onCaptureChanged(IntPtr hwnd,
                                uint msg,
                                uint wParam,
                                int lParam,
                                ref bool handled)
        {
            DesktopUtils.updateJSONValue(captureChangedPayload_, "lParam", lParam);
            sendExternalWindowEvent(captureChangedPayload_);

            if (handlinguserDisabledFrame && hwnd.ToInt32() != lParam)
            {
                ignoreNextChange_ = true;
            }

            return 1;
        }

        /// <summary>
        ///     Called in response to WM_DESTROY.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_DESTROY</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">This parameter is not used.</param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onDestroyed(IntPtr hwnd,
                                uint msg,
                                uint wParam,
                                int lParam,
                                ref bool handled)
        {
            sendExternalWindowEvent(destroyedPayload_);
            cleanup();
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_ENTERSIZEMOVE.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_ENTERSIZEMOVE</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">This parameter is not used.</param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onEnterSizeMove(IntPtr hwnd,
                                   uint msg,
                                   uint wParam,
                                   int lParam,
                                   ref bool handled)
        {
            if (!handlinguserDisabledFrame && frameDisabled_)
            {
                handlinguserDisabledFrame = true;
            }

            Win32.POINT mouse = new Win32.POINT();
            Win32.GetCursorPos(out mouse);
            DesktopUtils.updateJSONValue(enterSizeMovePayload_, "mouseX", mouse.X);
            DesktopUtils.updateJSONValue(enterSizeMovePayload_, "mouseY", mouse.Y);

            sendExternalWindowEvent(enterSizeMovePayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_EXITSIZEMOVE.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_EXITSIZEMOVE</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">This parameter is not used.</param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onExitSizeMove(IntPtr hwnd,
                                   uint msg,
                                   uint wParam,
                                   int lParam,
                                   ref bool handled)
        {
            if (handlinguserDisabledFrame)
            {
                handlinguserDisabledFrame = false;
            }

            Win32.POINT mouse = new Win32.POINT();
            Win32.GetCursorPos(out mouse);
            DesktopUtils.updateJSONValue(exitSizeMovePayload_, "mouseX", mouse.X);
            DesktopUtils.updateJSONValue(exitSizeMovePayload_, "mouseY", mouse.Y);

            sendExternalWindowEvent(exitSizeMovePayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_KILLFOCUS.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_KILLFOCUS</param>
        /// <param name="wParam">A handle to the window that receives the keyboard focus. This parameter can be NULL.</param>
        /// <param name="lParam">This parameter is not used.</param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onKillFocus(IntPtr hwnd,
                                uint msg,
                                uint wParam,
                                int lParam,
                                ref bool handled)
        {
            sendExternalWindowEvent(blurPayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_MOVE.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_MOVE</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">
        ///     The x and y coordinates of the upper-left corner 
        ///     of the client area of the window. The low-order word 
        ///     contains the x-coordinate while the high-order 
        ///     word contains the y coordinate.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onMove(IntPtr hwnd,
                           uint msg,
                           uint wParam,
                           int lParam,
                           ref bool handled)
        {
            Win32.POINT p = Win32.LParamToPoint(lParam);
            DesktopUtils.updateJSONValue(movePayload_, "x", p.X);
            DesktopUtils.updateJSONValue(movePayload_, "y", p.Y);
            sendExternalWindowEvent(movePayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_MOVING.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_MOVING</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">
        ///     A pointer to a RECT structure with the current 
        ///     position of the window, in screen coordinates. 
        ///     To change the position of the drag rectangle, 
        ///     an application must change the members of 
        ///     this structure.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onMoving(IntPtr hwnd,
                             uint msg,
                             uint wParam,
                             int lParam,
                             ref bool handled)
        {
            Win32.RECT bounds = (Win32.RECT)Marshal.PtrToStructure(new IntPtr(lParam), typeof(Win32.RECT));
            DesktopUtils.updateJSONValue(movingPayload_, "left", bounds.Left);
            DesktopUtils.updateJSONValue(movingPayload_, "top", bounds.Top);
            DesktopUtils.updateJSONValue(movingPayload_, "right", bounds.Right);
            DesktopUtils.updateJSONValue(movingPayload_, "bottom", bounds.Bottom);

            Win32.POINT mouse = new Win32.POINT();
            Win32.GetCursorPos(out mouse);
            DesktopUtils.updateJSONValue(movingPayload_, "mouseX", mouse.X);
            DesktopUtils.updateJSONValue(movingPayload_, "mouseY", mouse.Y);

            if (handlinguserDisabledFrame)
            {
                //Retrieve the current bounds
                Win32.RECT currentBounds = new Win32.RECT();
                Win32.GetWindowRect(hwnd, out currentBounds);

                // Copy the current bounds struct to lParam unmanaged memory.
                // Prevents changes
                Marshal.StructureToPtr(currentBounds, new IntPtr(lParam), false);
         
                handled = true;
            }

            sendExternalWindowEvent(movingPayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_NCLBUTTONDBLCLK.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_NCLBUTTONDBLCLK</param>
        /// <param name="wParam">
        ///     The hit-test value returned by the DefWindowProc function 
        ///     as a result of processing the WM_NCHITTEST message.
        /// </param>
        /// <param name="lParam">
        ///     A POINTS structure that contains the x- and y-coordinates 
        ///     of the cursor. The coordinates are relative to the upper-left 
        ///     corner of the screen.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onNcDoubleClick(IntPtr hwnd,
                                    uint msg,
                                    uint wParam,
                                    int lParam,
                                    ref bool handled)
        {
            DesktopUtils.updateJSONValue(ncDoubleClickPayload_, "wParam", wParam);
            Win32.POINT p = Win32.LParamToPoint(lParam);
            DesktopUtils.updateJSONValue(ncDoubleClickPayload_, "x", p.X);
            DesktopUtils.updateJSONValue(ncDoubleClickPayload_, "y", p.Y);
            sendExternalWindowEvent(ncDoubleClickPayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_SETFOCUS.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_SETFOCUS</param>
        /// <param name="wParam">
        ///     A handle to the window that has lost the keyboard focus. 
        ///     This parameter can be NULL.
        /// </param>
        /// <param name="lParam">This parameter is not used.</param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onSetFocus(IntPtr hwnd,
                               uint msg,
                               uint wParam,
                               int lParam,
                               ref bool handled)
        {
            sendExternalWindowEvent(focusPayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_SIZING.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_SIZING</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">This parameter is not used.</param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onSizing(IntPtr hwnd,
                             uint msg,
                             uint wParam,
                             int lParam,
                             ref bool handled)
        {
            DesktopUtils.updateJSONValue(sizingPayload_, "wParam", wParam);

            Win32.RECT bounds = (Win32.RECT)Marshal.PtrToStructure(new IntPtr(lParam), typeof(Win32.RECT));
            DesktopUtils.updateJSONValue(sizingPayload_, "left", bounds.Left);
            DesktopUtils.updateJSONValue(sizingPayload_, "top", bounds.Top);
            DesktopUtils.updateJSONValue(sizingPayload_, "right", bounds.Right);
            DesktopUtils.updateJSONValue(sizingPayload_, "bottom", bounds.Bottom);

            Win32.POINT mouse = new Win32.POINT();
            Win32.GetCursorPos(out mouse);
            DesktopUtils.updateJSONValue(sizingPayload_, "mouseX", mouse.X);
            DesktopUtils.updateJSONValue(sizingPayload_, "mouseY", mouse.Y);

            if (handlinguserDisabledFrame)
            {
                //Retrieve the current bounds
                Win32.RECT currentBounds = new Win32.RECT();
                Win32.GetWindowRect(hwnd, out currentBounds);

                // Copy the current bounds struct to lParam unmanaged memory.
                // Prevents changes
                Marshal.StructureToPtr(currentBounds, new IntPtr(lParam), false);

                handled = true;
            }


            sendExternalWindowEvent(sizingPayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_SYSCOMMAND.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_SYSCOMMAND</param>
        /// <param name="wParam">The type of system command requested.</param>
        /// <param name="lParam">
        /// 
        ///     The low-order word specifies the horizontal position of the cursor, 
        ///     in screen coordinates, if a window menu command is chosen with the mouse. 
        ///     Otherwise, this parameter is not used.
        ///     
        ///     The high-order word specifies the vertical position of the cursor, in s
        ///     creen coordinates, if a window menu command is chosen with the mouse. 
        ///     This parameter is –1 if the command is chosen using a 
        ///     system accelerator, or zero if using a mnemonic.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onSysCommand(IntPtr hwnd,
                                 uint msg,
                                 uint wParam,
                                 int lParam,
                                 ref bool handled)
        {
            // Only send events we are interested in
            if ((wParam & subscribedSystemEvents_) > 0)
            {
                DesktopUtils.updateJSONValue(sysCommandPayload_, "wParam", wParam);
                sendExternalWindowEvent(sysCommandPayload_);
            }
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_WINDOWPOSCHANGED.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_WINDOWPOSCHANGED</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">
        ///     A pointer to a WINDOWPOS structure that contains 
        ///     information about the window's new size and position.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onWindowPosChanged(IntPtr hwnd,
                                       uint msg,
                                       uint wParam,
                                       int lParam,
                                       ref bool handled)
        {
            Win32.WINDOWPOS changeInfo = (Win32.WINDOWPOS)Marshal.PtrToStructure(new IntPtr(lParam), typeof(Win32.WINDOWPOS));
            DesktopUtils.updateJSONValue(posChangedPayload_, "hwnd", changeInfo.hwnd.ToString("X8"));
            DesktopUtils.updateJSONValue(posChangedPayload_, "hwndInsertAfter", changeInfo.hwndInsertAfter.ToString("X8"));
            DesktopUtils.updateJSONValue(posChangedPayload_, "x", changeInfo.x);
            DesktopUtils.updateJSONValue(posChangedPayload_, "y", changeInfo.y);
            DesktopUtils.updateJSONValue(posChangedPayload_, "cx", changeInfo.cx);
            DesktopUtils.updateJSONValue(posChangedPayload_, "cy", changeInfo.cy);
            DesktopUtils.updateJSONValue(posChangedPayload_, "flags", changeInfo.flags);
            sendExternalWindowEvent(posChangedPayload_);
            return 1;
        }

        /// <summary>
        ///     Called in response to WM_WINDOWPOSCHANGING.
        /// </summary>
        /// <param name="hwnd">A handle to the window.</param>
        /// <param name="msg">WM_WINDOWPOSCHANGING</param>
        /// <param name="wParam">This parameter is not used.</param>
        /// <param name="lParam">
        ///     A pointer to a WINDOWPOS structure that contains 
        ///     information about the window's new size and position.
        /// </param>
        /// <param name="handled">Will bypass the default WndProc when set to true.</param>
        private int onWindowPosChanging(IntPtr hwnd,
                                        uint msg,
                                        uint wParam,
                                        int lParam,
                                        ref bool handled)
        {
            Win32.WINDOWPOS changeInfo = (Win32.WINDOWPOS)Marshal.PtrToStructure(new IntPtr(lParam), typeof(Win32.WINDOWPOS));
            DesktopUtils.updateJSONValue(posChangingPayload_, "hwnd", changeInfo.hwnd.ToString("X8"));
            DesktopUtils.updateJSONValue(posChangingPayload_, "hwndInsertAfter", changeInfo.hwndInsertAfter.ToString("X8"));
            DesktopUtils.updateJSONValue(posChangingPayload_, "x", changeInfo.x);
            DesktopUtils.updateJSONValue(posChangingPayload_, "y", changeInfo.y);
            DesktopUtils.updateJSONValue(posChangingPayload_, "cx", changeInfo.cx);
            DesktopUtils.updateJSONValue(posChangingPayload_, "cy", changeInfo.cy);
            DesktopUtils.updateJSONValue(posChangingPayload_, "flags", changeInfo.flags);

            // Moving allowed
            bool isMoving = (changeInfo.flags & Win32.SWP_NOMOVE) == 0;

            // Sizing allowed
            bool isSizing = (changeInfo.flags & Win32.SWP_NOSIZE) == 0;

            // Delegate to desktop if this is a move/size and handling a disabled user frame
            if ((isMoving || isSizing))
            {
                if (handlinguserDisabledFrame && ignoreNextChange_)
                {
                    changeInfo.flags |= (Win32.SWP_NOMOVE | Win32.SWP_NOSIZE);

                    // Copy the flag change to lParam unmanaged memory.
                    // Prevents changes
                    Marshal.StructureToPtr(changeInfo, new IntPtr(lParam), false);
                }

                ignoreNextChange_ = false;
            }

            sendExternalWindowEvent(posChangingPayload_);
            return 1;
        }

        /// <summary>
        ///     Callback when Desktop is successfully connected and ready to 
        ///     accept commands.
        /// </summary>
        public void onReady() {
            // Notify the desktop to install this new external window
            registerExternalWindow((ack) => {
                registered_ = true;
            });

            // Begin intercepting window messages
            installMessageHandlers();
        }

        /// <summary>
        ///     Callback when the connection with the Desktop has closed.
        /// </summary>
        public void onClosed()
        {
            // Reset the normal WndProc
            restoreWndProc();
        }

        /// <summary>
        ///     Callback when client cannot start or connect to the Desktop.
        /// </summary>
        public void onError(String reason) { }

        /// <summary>
        ///     Callback when a message is sent to this client.
        /// </summary>
        public void onMessage(String message) { }

        /// <summary>
        ///     Callback when a message is sent from this client.
        /// </summary>
        public void onOutgoingMessage(String message) { }

        private class WindowHookHelper
        {
            // The WndProcCallback method is used when a hooked 
            // window's message map contains the hooked message. 
            // Parameters: 
            // hwnd - The handle to the window for which the message 
            // was received. 
            // wParam - The message's parameters (part 1). 
            // lParam - The message's parameters (part 2). 
            // handled - The invoked function sets this to true if it 
            // handled the message. If the value is false when the callback 
            // returns, the next window procedure in the wndproc chain is 
            // called. 
            // 
            // Returns a value specified for the given message. 
            public delegate int WndProcCallback(IntPtr hwnd, 
                                                uint msg, 
                                                uint wParam, 
                                                int lParam, 
                                                ref bool handled);

            // This is the global list of all the window procedures we have 
            // hooked. The key is an hwnd. The value is a HookedProcInformation 
            // object which contains a pointer to the old wndproc and a map of 
            // message's callbacks for the window specified. Controls whose handles 
            // have been created go into this dictionary. 
            private static ConcurrentDictionary<IntPtr, HookedProcInformation> hwndDict =
                new ConcurrentDictionary<IntPtr, HookedProcInformation>();

            // Makes a connection between a message on a specified window handle 
            // and the callback to be called when that message is received. If the 
            // window was not previously hooked it is added to the global list of 
            // all the window procedures hooked. 
            // Parameters: 
            // hwnd - The control whose wndproc we are hooking. 
            // callback - The method to call when the specified. 
            // message is received for the specified window. 
            // msg - The message being hooked. 
            public static void HookWndProc(IntPtr hwnd, 
                                           WndProcCallback callback, 
                                           uint msg,
                                           bool intercept = true)
            {
                HookedProcInformation hpi = null;
                hwndDict.TryGetValue(hwnd, out hpi);
                if (hpi == null)
                {
                    // If new control, create a new 
                    // HookedProcInformation for it.
                    hpi = new HookedProcInformation(hwnd,
                        new Win32.WndProc(WindowHookHelper.WindowProc));
                    /*ctl.HandleCreated += new EventHandler(ctl_HandleCreated);
                    ctl.HandleDestroyed += new EventHandler(ctl_HandleDestroyed);
                    ctl.Disposed += new EventHandler(ctl_Disposed);*/

                    // If the handle has already been created set the hook. If it 
                    // hasn't been created yet, the hook will get set in the 
                    // ctl_HandleCreated event handler. 
                    if (hwnd != IntPtr.Zero)
                    {
                        hpi.SetHook();
                        hwndDict.TryAdd(hwnd, hpi);
                    }
                }

                // Add the message/callback into the message map.
                hpi.messageMap.TryAdd(msg, Tuple.Create(callback, intercept));
            }

            // This is a generic wndproc. It is the callback for all hooked 
            // windows. If we get into this function, we look up the hwnd in the 
            // global list of all hooked windows to get its message map. If the 
            // message received is present in the message map, its callback is 
            // invoked with the parameters listed here. 
            // Parameters: 
            // hwnd - The handle to the window that received the 
            // message 
            // msg - The message 
            // wParam - The message's parameters (part 1) 
            // lParam - The messages's parameters (part 2) 
            // Returns the callback handled the message, the callback's return 
            // value is returned form this function. If the callback didn't handle 
            // the message, the message is forwarded on to the previous wndproc. 
            private static int WindowProc(IntPtr hwnd, 
                                          uint msg, 
                                          uint wParam, 
                                          int lParam)
            {
                HookedProcInformation hpi = null;
                if (hwndDict.TryGetValue(hwnd, out hpi))
                {
                    Tuple<WndProcCallback, bool> mapValue = null;
                    if (hpi.messageMap.TryGetValue(msg, out mapValue))
                    {
                        bool handled = false;
                        // If intercepting
                        if (mapValue.Item2)
                        {
                            int retval = mapValue.Item1(hwnd, msg, wParam, lParam, ref handled);
                            if (handled)
                                return retval;
                        }
                        else
                        {
                            int result = hpi.CallOldWindowProc(hwnd, msg, wParam, lParam);
                            mapValue.Item1(hwnd, msg, wParam, lParam, ref handled);
                            return result;
                        }
                    }

                    // If the callback didn't set the handled property to true, 
                    // call the original window procedure. 
                    return hpi.CallOldWindowProc(hwnd, msg, wParam, lParam);
                }
                System.Diagnostics.Debug.Assert(
                    false, "WindowProc called for hwnd we don't know about");
                return Win32.DefWindowProc(hwnd, msg, wParam, lParam);
            }

            // This method removes the specified message from the message map for 
            // the specified hwnd. 
            public static void UnhookWndProc(IntPtr hwnd, uint msg)
            {
                HookedProcInformation hpi = null;
                if (!hwndDict.TryGetValue(hwnd, out hpi))
                {
                    //throw new ArgumentException("No hook exists for this control");
                    return;
                }

                // look for the message we are removing in the messageMap
                Tuple<WndProcCallback, bool> mapValue = null;
                if (!hpi.messageMap.TryRemove(msg, out mapValue))
                {
                        // if we couldn't find the message, throw 
                        /*throw new ArgumentException(
                            string.Format(
                            "No hook exists for message ({0}) on this control",
                            msg));*/
                }
            }

            // Restores the previous wndproc for the specified window. 
            // Parameters: 
            // hwnd - The control whose wndproc we no longer want to hook. 
            public static void UnhookWndProc(IntPtr hwnd)
            {
                HookedProcInformation hpi = null;
                if (!hwndDict.TryRemove(hwnd, out hpi))
                {
                    //throw new ArgumentException("No hook exists for this control");
                    return;
                }

                if (hpi != null)
                {
                    hpi.Unhook();
                }
            }

            // This class remembers the old window procedure for the specified 
            // window handle and also provides the message map for the messages 
            // hooked on that window. 
            class HookedProcInformation : IDisposable
            {

                // The message map for the window. 
                public ConcurrentDictionary<uint, Tuple<WndProcCallback, bool>> messageMap;

                // The old window procedure for the window. 
                private IntPtr oldWndProc;

                // The delegate that gets called in place of this window's 
                // wndproc. 
                private Win32.WndProc newWndProc;

                // Control whose wndproc is being hooked. 
                private IntPtr handle_;

                private bool hooked_ = false;

                // Constructs a new HookedProcInformation object 
                // Parameters: 
                // hwnd - The handle to the window being hooked 
                // wndproc - The window procedure to replace the 
                // original one for the control. 
                public HookedProcInformation(IntPtr hwnd, Win32.WndProc wndproc)
                {
                    handle_ = hwnd;
                    newWndProc = wndproc;
                    messageMap = new ConcurrentDictionary<uint, Tuple<WndProcCallback, bool>>();
                }

                // Replaces the windows procedure for control with the 
                // one specified in the constructor. 
                public void SetHook()
                {
                    IntPtr hwnd = handle_;
                    if (hwnd == IntPtr.Zero)
                    {
                        /*throw new InvalidOperationException(
                            "Handle for control has not been created");*/
                        return;
                    }

                    hooked_ = true;
                    oldWndProc = Win32.SetWindowLong(hwnd, Win32.GWL_WNDPROC,
                        Marshal.GetFunctionPointerForDelegate(newWndProc));
                }

                // Restores the original window procedure for the control. 
                public void Unhook()
                {
                    if(hooked_) {
                        IntPtr hwnd = handle_;
                        if (hwnd == IntPtr.Zero) 
                        {
                            /*throw new InvalidOperationException(
                                "Handle for control has not been created");*/
                            return;
                        }

                        hooked_ = false;
                        Win32.SetWindowLong(hwnd, Win32.GWL_WNDPROC, oldWndProc);
                    }
                }

                // Calls the original window procedure of the control with the 
                // arguments provided. 
                // Parameters: 
                // hwnd - The handle of the window that received the 
                // message 
                // msg - The message 
                // wParam - The message's arguments (part 1) 
                // lParam - The message's arguments (part 2) 
                // Returns the value returned by the control's original wndproc. 
                public int CallOldWindowProc(IntPtr hwnd, 
                                             uint msg, 
                                             uint wParam, 
                                             int lParam)
                {
                    return Win32.CallWindowProc(
                        oldWndProc, hwnd, msg, wParam, lParam);
                }

                public void Dispose()
                {
                    Unhook();
                }
            }
        }
 
        // Helper class containing WIN32 message constants and structs
        private sealed class Win32
        {
            // Native representation of a point. 
            public struct POINT
            {
                public int X;
                public int Y;
            }

            // A callback to a Win32 window procedure (wndproc): 
            // Parameters: 
            //   hwnd - The handle of the window receiving a message. 
            //   msg - The message 
            //   wParam - The message's parameters (part 1). 
            //   lParam - The message's parameters (part 2). 
            //  Returns an integer as described for the given message in MSDN. 
            public delegate int WndProc(IntPtr hwnd, uint msg, uint wParam, int lParam);

            [DllImport("user32.dll")]
            public extern static IntPtr SetWindowLong(
                IntPtr hwnd, int nIndex, IntPtr dwNewLong);
            public const int GWL_WNDPROC = -4;

            [DllImport("user32.dll")]
            public extern static int CallWindowProc(
                IntPtr lpPrevWndFunc, IntPtr hwnd, uint msg, uint wParam, int lParam);

            [DllImport("user32.dll")]
            public extern static int DefWindowProc(
                IntPtr hwnd, uint msg, uint wParam, int lParam);

            /*[DllImport("user32.dll")]
            public extern static uint GetMessagePos();*/
     
            // Helper function to convert a Windows lParam into a Point. 
            //   lParam - The parameter to convert. 
            // Returns a Point where X is the low 16 bits and Y is the 
            // high 16 bits of the value passed in. 
            public static POINT LParamToPoint(int lParam)
            {
                uint ulParam = (uint)lParam;
                POINT p = new POINT();
                p.X = (int)(ulParam & 0x0000ffff);
                p.Y = (int)((ulParam & 0xffff0000) >> 16);
                return p;
            }

            [DllImport("user32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool GetCursorPos(out POINT lpPoint);

            [DllImport("user32.dll", SetLastError = true)]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

            [StructLayout(LayoutKind.Sequential)]
            public struct RECT
            {
                public int Left;        // x position of upper-left corner
                public int Top;         // y posi.tion of upper-left corner
                public int Right;       // x position of lower-right corner
                public int Bottom;      // y position of lower-right corner
            }

            [StructLayout(LayoutKind.Sequential)]
            public struct WINDOWPOS
            {
                public IntPtr hwnd;
                public IntPtr hwndInsertAfter;
                public int x;
                public int y;
                public int cx;
                public int cy;
                public uint flags;
            }

            // Windows messages 
            public const uint WM_CAPTURECHANGED = 0x0215;
            public const uint WM_DESTROY = 0x0002;
            public const uint WM_ENTERSIZEMOVE = 0x0231;
            public const uint WM_ERASEBKGND = 0x0014;
            public const uint WM_EXITSIZEMOVE = 0x0232;
            public const uint WM_KEYDOWN = 0x0100;
            public const uint WM_KEYUP = 0x0101;
            public const uint WM_KILLFOCUS = 0x0008;
            public const uint WM_LBUTTONDOWN = 0x0201;
            public const uint WM_LBUTTONUP = 0x0202;
            public const uint WM_MOUSEMOVE = 0x0200;
            public const uint WM_MOVE = 0x0003;
            public const uint WM_MOVING = 0x0216;
            public const uint WM_NCLBUTTONDBLCLK = 0x00A3;
            public const uint WM_NCLBUTTONUP = 0x00A2;
            public const uint WM_NOTIFY = 0x4E;
            public const uint WM_SETFOCUS = 0x0007;
            public const uint WM_SIZING = 0x0214;
            public const uint WM_SYSCOMMAND = 0x0112;
            public const uint WM_WINDOWPOSCHANGED = 0x0047;
            public const uint WM_WINDOWPOSCHANGING = 0x0046;
            public const uint WM_PAINT = 0x000F;

            // SetWindowPosition
            public const uint SWP_HIDEWINDOW = 0x0080;
            public const uint SWP_NOMOVE = 0x0002;
            public const uint SWP_NOSIZE = 0x0001;
            public const uint SWP_SHOWWINDOW = 0x0040;

            // System command messages
            public const uint SC_CLOSE = 0xF060;
            public const uint SC_MAXIMIZE = 0xF030;
            public const uint SC_MINIMIZE = 0xF020;
            public const uint SC_RESTORE = 0xF120;


            // Key 
            public const uint VK_RETURN = 0x0D;
            public const uint VK_SPACE = 0x20;
        }
    }
}
