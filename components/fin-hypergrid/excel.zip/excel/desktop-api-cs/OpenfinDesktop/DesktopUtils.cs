﻿/*
 * File DesktopUtils.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Static helper class for getting/setting values from a JObject.
    /// </summary>
    public static class DesktopUtils
    {
        /// <summary>
        ///     Generic function to retrieve a value identified by "key" from 
        ///     "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static T getJSON<T>(JObject jsonObject, String key, T defaultValue)
        {
            T result = defaultValue;
            JToken jk = jsonObject.SelectToken(key);
            if (jk != null)
            {
                result = jk.Value<T>();
            }
            return result;
        }

        /// <summary>
        ///     Returns a JArray identified by "key" from 
        ///     "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve the JArray from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static JArray getJSONArray(JObject jsonObject, String key, JArray defaultValue = null)
        {
            JArray result = defaultValue;
            JToken jk = jsonObject.SelectToken(key);
            if (jk != null && jk.Type == JTokenType.Array)
            {
                result = (JArray)jk; 
            }
            return result;
        }

        /// <summary>
        ///     Returns a string identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static String getJSONString(JObject jsonObject, String key, String defaultValue = null)      { return getJSON<String>(jsonObject, key, defaultValue); }

        /// <summary>
        ///     Returns a bool identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static bool getJSONBool(JObject jsonObject, String key, bool defaultValue = false)           { return getJSON<bool>(jsonObject, key, defaultValue); }

        /// <summary>
        ///     Returns an int identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static int getJSONInt(JObject jsonObject, String key, int defaultValue = 0)                  { return getJSON<int>(jsonObject, key, defaultValue); }

        /// <summary>
        ///     Returns a long identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static long getJSONLong(JObject jsonObject, String key, long defaultValue = 0)               { return getJSON<long>(jsonObject, key, defaultValue); }

        /// <summary>
        ///     Returns a double identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static double getJSONDouble(JObject jsonObject, String key, double defaultValue = 0.0)       { return getJSON<double>(jsonObject, key, defaultValue); }

        /// <summary>
        ///     Returns a JObject identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static JObject getJSONObject(JObject jsonObject, String key, JObject defaultValue = null)    { return getJSON<JObject>(jsonObject, key, defaultValue); }

        /// <summary>
        ///     Returns an Object identified by "key" from "jsonObject".
        ///     <para>
        ///         "defaultValue" is returned if no match is found.
        ///     </para>
        ///     <param name="jsonObject">The JSON object to retrieve a value from.</param>
        ///     <param name="key">The key to search for.</param>
        ///     <param name="defaultValue">The value to return if no key match is found.</param>
        /// </summary>
        public static Object getObject(JObject jsonObject, String key, Object defaultValue = null)          { return getJSON<Object>(jsonObject, key, defaultValue); }


        /// <summary>
        ///     Sets a key/value pair for the passed JObject.
        /// </summary>
        /// <param name="jsonObject">The JSON object to insert the pair into.</param>
        /// <param name="key">The key to identify the value.</param>
        /// <param name="value">The value stored and identified by key.</param>
        public static void updateJSONValue(JObject jsonObject, String key, JToken value)
        {
            JToken existing = jsonObject.SelectToken(key);
            if (existing != null)
            {
                existing.Replace(value);
            }
            else
            {
                jsonObject.Add(new JProperty(key, value));
            }
        }
    }
}
