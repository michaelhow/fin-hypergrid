﻿/*
 * File Window.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A delegate to handle the resulting options from 
    ///     Window.getOptions().
    /// </summary>
    /// <param name="options">The options as returned by the desktop</param>
    public delegate void windowOptionsHandler(WindowOptions options);

    /// <summary>
    ///     A delegate to handle the returned grouped windows, if any, from Window.getGroup()
    /// </summary>
    /// 
    /// <remarks>
    ///     An empty list is returned if the window is not in a group. 
    ///     The calling window is included in the resulting List.
    /// </remarks>
    /// <param name="group">A list of all the wrapped windows in the same group.</param>
    public delegate void windowGroupHandler(List<Window> group);

    /// <summary>
    ///     A window that can be controlled by the AppDesktop API. 
    ///     <para>
    ///         Window objects are available through application.getWindow(). 
    ///         This class can not be instantiated directly. 
    ///     </para>
    /// </summary>
    public class Window
    {
        /// <summary>
        ///     Helper struct representing the payload returned by the window event 'group-changed'
        /// </summary>
        public struct GroupChangedPayload
        {
            /// <summary>
            ///     Which group array the window that the event listener was 
            ///     registered on is included in.
            /// </summary> 
            /// <remarks>
            ///     'source'  The window is included in sourceGroup
            ///     'target'  The window is included in targetGroup
            ///     'nothing' The window is not included in sourceGroup nor targetGroup,
            /// </remarks>
            public String memberOf;

            /// <summary>
            ///     The name of the window
            /// </summary>
            public String name;

            /// <summary>
            ///     The reason this event was triggered.
            /// </summary>
            /// <remarks>
            ///     'leave'   A window has left the group due to a leave or merge with group.
            ///     'join'    A window has joined the group.
            ///     'merge'   Two groups have been merged together.
            ///     'disband' There are no other windows in the group
            /// </remarks>
            public String reason;

            /// <summary>
            ///     All the windows in the group the sourceWindow originated from
            /// </summary>
            public List<Window> sourceGroup;

            /// <summary>
            ///     The UUID of the application the sourceWindow belongs to. 
            ///     The source window is the window in which (merge/join/leave)group(s) was called.
            /// </summary>
            public String sourceWindowAppUuid;

            /// <summary>
            ///     the name of the sourcewindow. The source window is 
            ///     the window in which (merge/join/leave)group(s) was called.
            /// </summary>
            public String sourceWindowName;

            /// <summary>
            ///     All the windows in the group the targetWindow orginated from.
            /// </summary>
            public List<Window> targetGroup;

            /// <summary>
            ///     The UUID of the application the targetWindow belongs to. 
            ///     The target window is the window that was passed into (merge/join)group(s).
            /// </summary>
            public String targetWindowAppUuid;

            /// <summary>
            ///     The name of the targetWindow. 
            ///     The target window is the window that was passed into (merge/join)group(s)
            /// </summary>
            public String targetWindowName;

            /// <summary>
            ///     The UUID of the application the window belongs to
            /// </summary>
            public String uuid;

            private DesktopConnection desktopConnection;

            /// <summary>
            ///     Populates values from the ACK of a window 'group-changed' payload
            /// </summary>
            /// <param name="payload">The payload of a 'group-changed' event handler<see cref="Ack"/></param>
            /// <param name="connection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
            public GroupChangedPayload(Ack payload, DesktopConnection connection)
            {
                desktopConnection = connection;
                JObject data = (payload != null && payload.getJsonObject() != null ? payload.getJsonObject() : new JObject());

                memberOf = DesktopUtils.getJSONString(data, "memberOf", "nothing");
                name = DesktopUtils.getJSONString(data, "name", "");
                reason = DesktopUtils.getJSONString(data, "reason", "");
                sourceWindowAppUuid = DesktopUtils.getJSONString(data, "sourceWindowAppUuid", "");
                sourceWindowName = DesktopUtils.getJSONString(data, "sourceWindowName", "");
                targetWindowAppUuid = DesktopUtils.getJSONString(data, "targetWindowAppUuid", "");
                targetWindowName = DesktopUtils.getJSONString(data, "targetWindowName", "");
                uuid = DesktopUtils.getJSONString(data, "uuid", "");

                sourceGroup = new List<Window>();

                // If the JSON array is present
                JArray sourceGroupWindows = DesktopUtils.getJSONArray(data, "sourceGroup", null);
                if (sourceGroupWindows != null)
                {
                    foreach (JObject entry in sourceGroupWindows)
                    {
                        sourceGroup.Add(Openfin.Desktop.Window.wrap(DesktopUtils.getJSONString(entry, "appUuid", ""),
                                                                    DesktopUtils.getJSONString(entry, "windowName", ""), 
                                                                    desktopConnection));
                    }
                }
               
                targetGroup = new List<Window>();

                // If the JSON array is present
                JArray targetGroupWindows = DesktopUtils.getJSONArray(data, "targetGroup", null);
                if (targetGroupWindows != null)
                {
                    foreach (JObject entry in targetGroupWindows)
                    {
                        targetGroup.Add(Openfin.Desktop.Window.wrap(DesktopUtils.getJSONString(entry, "appUuid", ""),
                                                                    DesktopUtils.getJSONString(entry, "windowName", ""),
                                                                    desktopConnection));
                    }
                }
            }
        }

        private DesktopConnection desktopConnection;
        private String uuid, name;
        private JObject closePayload_ = null;
        private JObject noParamPayload_ = null;
        private JObject showAtPayload_ = null;
        private JObject resizeToPayload_ = null;
        private JObject moveByPayload_ = null;
        private JObject eventListenerPayload_ = null;
        private JObject windowGroupingPayload_ = null;
        private JObject moveToPayload_ = null;
        private JObject resizeByPayload_  = null;
        private JObject updateOptionsPayload_ = null;
        private JObject animationPayload_ = null;
        private JObject ExternalWindowDockPayload_ = null;
        private JObject ExternalWindowUnDockPayload_ = null;
        private JObject setBoundsPayload_ = null;

        /// <summary>
        ///     Window Constructor.
        /// </summary>
        /// <param name="application">the parent Application<see cref="Application"/></param>
        public Window(Application application)
        {
            this.desktopConnection = application.DesktopConnection;
            uuid = application.getUuid();
            name = application.getUuid();
            initialize();
        }

        /// <summary>
        ///     Attaches a Window object to an application Window that already exists.
        ///     <seealso cref="Application.wrap"/>
        /// </summary>
        /// <param name="applicationUUID">The UUID of the parent Application.</param>
        /// <param name="name">The name of the Window</param>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        public Window(String applicationUUID, String name, DesktopConnection desktopConnection)
	    {
            this.desktopConnection = desktopConnection;
            this.uuid = applicationUUID;
            this.name = name;
            initialize();
	    }


        /// <summary>
        ///     Attaches a Window object to an application Window that already exists.
        /// </summary>
        /// <param name="applicationUUID">The UUID of the parent Application.</param>
        /// <param name="windowName">The name of the Window</param>
        /// <param name="desktopConnection">Connection object to the AppDesktop.<see cref="DesktopConnection"/></param>
        public static Window wrap(String applicationUUID, String windowName, DesktopConnection desktopConnection)
        {
            return new Window(applicationUUID, windowName, desktopConnection);
        }

        /// <summary>
        ///     Returns the parent Application's UUID.
        /// </summary>
        public String getUuid()
        {
            return uuid;
        }

        /// <summary>
        ///     Returns the name of the window As registered with the AppDesktop.
        /// </summary>
        public String getName()
        {
            return name;
        }

        /// <summary>
        ///     Allocates and prepares internal JObjects.
        /// </summary>
        private void initialize() 
        {
            noParamPayload_ = new JObject();
            DesktopUtils.updateJSONValue(noParamPayload_, "uuid", uuid);
            DesktopUtils.updateJSONValue(noParamPayload_, "name", name); 
        }


        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///         blurred
        ///         bounds-changed
        ///         bounds-changing
        ///         closed
        ///         close-requested
        ///         disabled-frame-bounds-changed
        ///         disabled-frame-bounds-changing
        ///         focused
        ///         frame-disabled
        ///         frame-enabled
        ///         group-changed
        ///         hidden
        ///         maximized
        ///         minimized
        ///         restored
        ///         shown
        /// </remarks>
        /// <param name="subscriptionObject">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        private void addEventListener(JObject subscriptionObject,
                                     AckCallback listener,
                                     AckCallback callback = null,
                                     AckCallback errorCallback = null)
        {
            this.desktopConnection.addEventCallback(subscriptionObject,
                                                    listener,
                                                    callback,
                                                    errorCallback,
                                                    this);
        }

        /// <summary>
        ///     Registers an event listener on the specified event. 
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///         blurred
        ///         bounds-changed
        ///         bounds-changing
        ///         closed
        ///         focused
        ///         maximized
        ///         minimized
        ///         restored
        /// </remarks>
        /// <param name="type">
        ///     A JSON object containing subscription information such as the topic and type.
        /// </param>
        /// <param name="listener">
        ///     A function that is called whenever an event of the specified type occurs.
        ///     It is passed an event object containing information related to the event.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void addEventListener(String type,
                                     AckCallback listener,
                                     AckCallback callback = null,
                                     AckCallback errorCallback = null)
        {
            if (eventListenerPayload_ == null)
            {
                eventListenerPayload_ = new JObject();
                DesktopUtils.updateJSONValue(eventListenerPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(eventListenerPayload_, "name", getName());
                DesktopUtils.updateJSONValue(eventListenerPayload_, "topic", "window");
            }

            DesktopUtils.updateJSONValue(eventListenerPayload_, "type", type);
            addEventListener(eventListenerPayload_, listener, callback, errorCallback);
        }

        /// <summary>
        ///     Reparents the passed HWND with the current AppDesktop window.
        /// </summary>
        /// <param name="hwnd">The window handle to reparent.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void adoptWindow(String hwnd,
                                AckCallback callback = null,
                                AckCallback errorCallback = null)
        {
            if (ExternalWindowDockPayload_ == null)
            {
                ExternalWindowDockPayload_ = new JObject();
                DesktopUtils.updateJSONValue(ExternalWindowDockPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(ExternalWindowDockPayload_, "name", getName());
            }
            DesktopUtils.updateJSONValue(ExternalWindowDockPayload_, "hwnd", hwnd);
            desktopConnection.sendAction("dock-window", ExternalWindowDockPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Performs the specified window transitions.
        /// </summary>
        /// <param name="transitions">
        ///     Describes the animations to preform.
        ///     <see cref="AnimationTransitions"/>
        /// </param>
        /// <param name="options">
        ///     Options for the animation.
        /// <see cref="AnimationOptions"/>
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called once all transitions have been completed or interrupted.
        ///     The result state is passed as an object.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        /// 
        public void animate(AnimationTransitions transitions, 
                            AnimationOptions options = null, 
                            AckCallback callback = null, 
                            AckCallback errorCallback = null)
        {
            if (animationPayload_ == null)
            {
                animationPayload_ = new JObject();
                DesktopUtils.updateJSONValue(animationPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(animationPayload_, "name", getName());
            }

            if (transitions != null)
            {
                DesktopUtils.updateJSONValue(animationPayload_, "transitions", transitions.ToJObject());
            }

            if (options != null)
            {
                DesktopUtils.updateJSONValue(animationPayload_, "options", options.Raw);
            }

            desktopConnection.sendAction("animate-window", animationPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes focus from the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void blur(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("blur-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Brings the window to the front of the window stack.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void bringToFront(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("bring-window-to-front", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Closes the window.
        /// </summary>
        /// <param name="force">
        ///     When true the close can not be prevented through the window event 'close-requested'
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void close(bool force = false, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (closePayload_ == null)
            {
                closePayload_ = new JObject();
                DesktopUtils.updateJSONValue(closePayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(closePayload_, "name", name);
            }
            DesktopUtils.updateJSONValue(closePayload_, "force", force);

            desktopConnection.sendAction("close-window", closePayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Prevents a user from changing a window's size/position when using the window's frame.
        ///     
        /// <remarks>
        ///     'disabled-frame-bounds-changing' is generated at the start of and during a user move/size operation. 
        ///     'disabled-frame-bounds-changed' is generated after a user move/size operation.
        ///     The events provide the bounds that would have been applied if the frame was enabled.
        ///  
        ///     'frame-enabled' is generated when a disabled frame has becomes enabled.
        /// </remarks>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void disableFrame(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("disable-window-frame", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Re-enables user changes to a window's size/position when using the window's frame.
        ///     
        /// <remarks>
        ///     'disabled-frame-bounds-changing' is generated at the start of and during a user move/size operation. 
        ///     'disabled-frame-bounds-changed' is generated after a user move/size operation.
        ///      The events provide the bounds that would have been applied if the frame was enabled.
        ///      
        ///     'frame-enabled' is generated when a disabled frame has becomes enabled.
        /// </remarks>
        /// 
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void enableFrame(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("enable-window-frame", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Draws attention to the window by flashing the taskbar and window caption.
        ///     <para>This effect continues until the window receives focus.</para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void flash(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("flash-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Gives focus to the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void focus(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("focus-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Gets the current bounds (top, left, width, height) of the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getBounds(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("get-window-bounds", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Passes a list of wrapped windows in the same group.
        /// </summary>
        /// <remarks>
        ///     An empty list is returned if the window is not in a group. 
        ///     The calling window is included in the resulting List.
        /// </remarks>
        /// <param name="groupHandler">
        ///     A delegate that receives a list of wrapped windows in the same group.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getGroup(windowGroupHandler groupHandler, AckCallback errorCallback = null)
        {
            AckCallback mainCallback = null;
            if (groupHandler != null)
            {
                mainCallback = (jsonGroup) =>
                {
                    List<Window> group = new List<Window>();

                    // If the JSON array is present
                    JObject cWindows = jsonGroup.getJsonObject();
                    if (cWindows != null)
                    {
                        // Convert to list and wrap every element.
                        IList<String> cObjects = cWindows.SelectToken("data").Select(s => (String)s).ToList();
                        foreach (String name in cObjects)
                        {
                            group.Add(Window.wrap(getUuid(), name, desktopConnection));
                        }
                    }

                    groupHandler(group);
                };
            }

            desktopConnection.sendAction("get-window-group", noParamPayload_, mainCallback, errorCallback, this);
        }

        /// <summary>
        ///     Returns the current options as stored in the desktop.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getOptions(windowOptionsHandler callback = null, AckCallback errorCallback = null)
        {
            AckCallback mainCallback = null;
            if(callback != null) {
                mainCallback = (data) => {
                    JObject json_options = (data!= null? data.getData() : null);
                    WindowOptions options = new WindowOptions((json_options != null?
                                                                json_options 
                                                                    : 
                                                                new JObject()));
                    callback(options);
                };
            }

            desktopConnection.sendAction("get-window-options", noParamPayload_, mainCallback, errorCallback, this);
        }

        /// <summary>
        ///     Returns the wrapped application that this window belongs to.
        /// </summary>
        public Application getParentApplication()
        {
            return Application.wrap(getUuid(), desktopConnection);
        }

        /// <summary>
        ///     Returns the wrapped main window of the application that this window belongs to.
        /// </summary>
        public Window getParentWindow()
        {
            return getParentApplication().getWindow();
        }

        /// <summary>
        ///     Gets a base64 encoded PNG snapshot of the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getSnapshot(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("get-window-snapshot", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Gets the current state ("minimized", "maximized", or "restored") of the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void getState(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("get-window-state", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Hides the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void hide(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("hide-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Determines if the window is currently showing.
        /// </summary>
        /// <param name="callback">
        ///     A function that is called if the method succeeds and 
        ///     passed an object containg the visiblity of the window.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void isShowing(AckCallback callback, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("is-window-showing", noParamPayload_, callback, errorCallback, this);
        }


        /// <summary>
        ///     Joins the same window group as the specified window. 
        /// </summary>
        /// <remarks>
        ///     When windows are joined, if the user moves one of the windows, 
        ///     all other windows in the same group move too. This function is 
        ///     to be used when docking to other windows. If the window is 
        ///     already within a group, it will leave that group to join the 
        ///     new one. Windows must be owned by the same application in order 
        ///     to be joined.
        /// </remarks>
        /// <param name="target">The window whose group is to be joined.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void joinGroup(Window target, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (windowGroupingPayload_ == null)
            {
                windowGroupingPayload_ = new JObject();
                DesktopUtils.updateJSONValue(windowGroupingPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(windowGroupingPayload_, "name", getName());
            }

            DesktopUtils.updateJSONValue(windowGroupingPayload_, "groupingWindowName", target.getName());
            desktopConnection.sendAction("join-window-group", windowGroupingPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Leaves the current window group so that the window 
        ///     can be move independently of those in the group.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void leaveGroup(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("leave-window-group", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Maximizes the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void maximize(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("maximize-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Merges the instance's window group with the same window group as the specified window.
        /// </summary>
        /// <remarks>
        ///    When windows are joined, if the user moves one of the windows, 
        ///    all other windows in the same group move too. This function is 
        ///    to be used when docking to other windows. If the window is 
        ///    already within a group, The two groups are joined to create a 
        ///    new one. Windows must be owned by the same application in order 
        ///    to be joined.
        /// </remarks>
        /// <param name="target">The window whose group is to be merged.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void mergeGroups(Window target, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (windowGroupingPayload_ == null)
            {
                windowGroupingPayload_ = new JObject();
                DesktopUtils.updateJSONValue(windowGroupingPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(windowGroupingPayload_, "name", getName());
            }

            DesktopUtils.updateJSONValue(windowGroupingPayload_, "groupingWindowName", target.getName());
            desktopConnection.sendAction("merge-window-groups", windowGroupingPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Minimizes the window.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void minimize(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("minimize-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Moves the window by a specified amount.
        /// </summary>
        /// <param name="deltaLeft">The change in the left position of the window.</param>
        /// <param name="deltaTop">The change in the top position of the window.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void moveBy(int deltaLeft, 
                           int deltaTop,
                           AckCallback callback = null,
                           AckCallback errorCallback = null)
        {
            if(moveByPayload_ == null)
            {
                moveByPayload_ = new JObject();
                DesktopUtils.updateJSONValue(moveByPayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(moveByPayload_, "name", name);
            }
            DesktopUtils.updateJSONValue(moveByPayload_, "deltaLeft", deltaLeft);
            DesktopUtils.updateJSONValue(moveByPayload_, "deltaTop", deltaTop);
            desktopConnection.sendAction("move-window-by", moveByPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Moves the window to a specified location.
        /// </summary>
        /// <param name="left">The left position of the window.</param>
        /// <param name="top">The top position of the window.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void moveTo(int left, 
                           int top, 
                           AckCallback callback = null,
                           AckCallback errorCallback = null)
        {
            if (moveToPayload_ == null)
            {
                moveToPayload_ = new JObject();
                DesktopUtils.updateJSONValue(moveToPayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(moveToPayload_, "name", name);
            }
            DesktopUtils.updateJSONValue(moveToPayload_, "left", left);
            DesktopUtils.updateJSONValue(moveToPayload_, "top", top);
            desktopConnection.sendAction("move-window", moveToPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Unparents the window identified by HWND and moves it to left, top.
        /// </summary>
        /// <param name="hwnd">The child window handle to orphan and move.</param>
        /// <param name="left">The new left position of the window.</param>
        /// <param name="top">The new top position of the window.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void orphanWindow(String hwnd,
                                 int left,
                                 int top,
                                 AckCallback callback = null,
                                 AckCallback errorCallback = null)
        {
            if (ExternalWindowUnDockPayload_ == null)
            {
                ExternalWindowUnDockPayload_ = new JObject();
                DesktopUtils.updateJSONValue(ExternalWindowUnDockPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(ExternalWindowUnDockPayload_, "name", getName());
            }
            DesktopUtils.updateJSONValue(ExternalWindowUnDockPayload_, "hwnd", hwnd);
            DesktopUtils.updateJSONValue(ExternalWindowUnDockPayload_, "x", left);
            DesktopUtils.updateJSONValue(ExternalWindowUnDockPayload_, "y", top);
            desktopConnection.sendAction("undock-window", ExternalWindowUnDockPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Removes a previously registered event listener from the specified event.
        ///     <para>
        ///         The listener is passed an event object containing information 
        ///         related to the event.
        ///     </para>
        /// </summary>
        /// <remarks>
        ///     Supported system event types are:
        ///         blurred
        ///         bounds-changed
        ///         bounds-changing
        ///         closed
        ///         close-requested
        ///         disabled-frame-bounds-changed
        ///         disabled-frame-bounds-changing
        ///         focused
        ///         frame-disabled
        ///         frame-enabled
        ///         group-changed
        ///         hidden
        ///         maximized
        ///         minimized
        ///         restored
        ///         shown
        /// </remarks>
        /// <param name="type">The type of the event.</param>
        /// <param name="listener">
        ///     A function that was called whenever an event of the specified type occurs.
        ///     It is no longer called in response to an event of the passed type.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void removeEventListener(String type,
                                        AckCallback listener,
                                        AckCallback callback = null,
                                        AckCallback errorCallback = null)
        {
            if (eventListenerPayload_ == null)
            {
                eventListenerPayload_ = new JObject();
                DesktopUtils.updateJSONValue(eventListenerPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(eventListenerPayload_, "name", getName());
                DesktopUtils.updateJSONValue(eventListenerPayload_, "topic", "window");
            }

            DesktopUtils.updateJSONValue(eventListenerPayload_, "type", type);
            this.desktopConnection.removeEventCallback(eventListenerPayload_,
                                                       listener,
                                                       callback,
                                                       errorCallback,
                                                       this);
        }


        /// <summary>
        ///     Resizes the window by the specified amount.
        /// </summary>
        /// <param name="deltaWidth">The change in the width of the window.</param>
        /// <param name="deltaHeight">The change in the height of the window.</param>
        /// <param name="anchor">
        ///     Specifies a corner to remain fixed during the resize.
        ///     Can take the values: 
        ///         "top-left"
        ///         "top-right"
        ///         "bottom-left"
        ///         "bottom-right" 
        ///     If undefined, the default is "top-left".
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void resizeBy(int deltaWidth, 
                             int deltaHeight, 
                             String anchor, 
                             AckCallback callback = null, 
                             AckCallback errorCallback = null)
        {
            if (resizeByPayload_ == null)
            {
                resizeByPayload_ = new JObject();
                DesktopUtils.updateJSONValue(resizeByPayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(resizeByPayload_, "name", name);
            }

            DesktopUtils.updateJSONValue(resizeByPayload_, "deltaWidth", deltaWidth);
            DesktopUtils.updateJSONValue(resizeByPayload_, "deltaHeight", deltaHeight);
            DesktopUtils.updateJSONValue(resizeByPayload_, "anchor", anchor);
            desktopConnection.sendAction("resize-window-by", resizeByPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Resizes the window by the specified amount with a "top-left" anchor
        /// </summary>
        /// <param name="deltaWidth">The change in the width of the window.</param>
        /// <param name="deltaHeight">The change in the height of the window.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void resizeBy(int deltaWidth, 
                             int deltaHeight, 
                             AckCallback callback = null, 
                             AckCallback errorCallback = null)
        {
            resizeBy(deltaWidth, deltaHeight, "top-left", callback, errorCallback);
        }

        /// <summary>
        ///     Resizes the window to the specified dimensions.
        /// </summary>
        /// <param name="width">The width of the window.</param>
        /// <param name="height">The height of the window.</param>
        /// <param name="anchor">
        ///     Specifies a corner to remain fixed during the resize.
        ///     Can take the values: 
        ///         "top-left"
        ///         "top-right"
        ///         "bottom-left"
        ///         "bottom-right" 
        ///     If undefined, the default is "top-left".
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void resizeTo(int width, 
                             int height, 
                             String anchor, 
                             AckCallback callback = null,
                             AckCallback errorCallback = null)
        {
            if (resizeToPayload_ == null)
            {
                resizeToPayload_ = new JObject();
                DesktopUtils.updateJSONValue(resizeToPayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(resizeToPayload_, "name", name);
            }

            DesktopUtils.updateJSONValue(resizeToPayload_, "height", height);
            DesktopUtils.updateJSONValue(resizeToPayload_, "width", width);
            DesktopUtils.updateJSONValue(resizeToPayload_, "anchor", anchor);
            desktopConnection.sendAction("resize-window", resizeToPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Resizes the window to the specified dimensions with a "top-left" anchor.
        /// </summary>
        /// <param name="width">The width of the window.</param>
        /// <param name="height">The height of the window.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void resizeTo(int width, 
                             int height, 
                             AckCallback callback = null,
                             AckCallback errorCallback = null)
        {
            resizeTo(width, height, "top-left", callback, errorCallback);
        }

        /// <summary>
        ///     Restores the window to its normal state (i.e., unminimized, unmaximized).
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void restore(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("restore-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Shows the window if it is hidden.
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void show(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("show-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Shows the window if it is hidden at the specified location.
        ///     <para>
        ///         If the toggle parameter is set to true, the window will
        ///         alternate between showing and hiding.
        ///     </para>
        /// </summary>
        /// <param name="left">The left position of the window.</param>
        /// <param name="top">The right position of the window.</param>
        /// <param name="toggle">
        ///     If true, the window will alternate between showing and hiding in subsequent calls.
        /// </param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void showAt(int left, 
                           int top, 
                           bool toggle, 
                           AckCallback callback = null, 
                           AckCallback errorCallback = null)
        {
            if (showAtPayload_ == null)
            {
                showAtPayload_ = new JObject();
                DesktopUtils.updateJSONValue(showAtPayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(showAtPayload_, "name", name);
            }

            DesktopUtils.updateJSONValue(showAtPayload_, "top", top);
            DesktopUtils.updateJSONValue(showAtPayload_, "left", left);
            DesktopUtils.updateJSONValue(showAtPayload_, "toggle", toggle);
            desktopConnection.sendAction("show-at-window", showAtPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Set's the window as the foreground window. 
        ///     <para>
        ///         The window is activated(focused) and brought to front.
        ///     </para>
        /// </summary>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void setAsForeground(AckCallback callback = null, AckCallback errorCallback = null)
        {
            desktopConnection.sendAction("set-foreground-window", noParamPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Set's the bounds (top, left, width, height) of the window. 
        /// </summary>
        /// <param name="left">The left position of the window.</param>
        /// <param name="top">The top position of the window.</param>
        /// <param name="width">The width of the window.</param>
        /// <param name="height">The height of the window.</param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void setBounds(int left, 
                              int top, 
                              int width, 
                              int height,
                              AckCallback callback = null, 
                              AckCallback errorCallback = null)
        {
            if (setBoundsPayload_ == null)
            {
                setBoundsPayload_ = new JObject();
                DesktopUtils.updateJSONValue(setBoundsPayload_, "uuid", uuid);
                DesktopUtils.updateJSONValue(setBoundsPayload_, "name", name);
            }

            DesktopUtils.updateJSONValue(setBoundsPayload_, "top", top);
            DesktopUtils.updateJSONValue(setBoundsPayload_, "left", left);
            DesktopUtils.updateJSONValue(setBoundsPayload_, "width", width);
            DesktopUtils.updateJSONValue(setBoundsPayload_, "height", height);

            desktopConnection.sendAction("set-window-bounds", setBoundsPayload_, callback, errorCallback, this);
        }

        /// <summary>
        ///     Changes a window's options that were defined upon creation.
        /// </summary>
        /// <param name="options">The window options to change<seealso cref="WindowOptions"/></param>
        /// <param name="callback">
        ///     (Optional) A function that is called if the method succeeds.
        /// </param>
        /// <param name="errorCallback">
        ///     (Optional) A function that is called if the method fails.
        ///     The reason for failure is passed as an argument.
        /// </param>
        public void updateOptions(WindowOptions options, AckCallback callback = null, AckCallback errorCallback = null)
        {
            if (updateOptionsPayload_ == null)
            {
                updateOptionsPayload_ = new JObject();
                DesktopUtils.updateJSONValue(updateOptionsPayload_, "uuid", getUuid());
                DesktopUtils.updateJSONValue(updateOptionsPayload_, "name", getName());
            }

            DesktopUtils.updateJSONValue(updateOptionsPayload_, "options", options.getJsonCopy());
            desktopConnection.sendAction("update-window-options", updateOptionsPayload_, callback, errorCallback, this);
        }
    }
}
