﻿/*
 * File DesktopStateListener.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Openfin.Desktop
{
    /// <summary>
    ///     A listener interface for receiving status updates from Desktop.
    /// </summary>
    public interface DesktopStateListener
    {
        /// <summary>
        ///     Callback when Desktop is successfully connected and ready to 
        ///     accept commands.
        /// </summary>
        void onReady();

        /// <summary>
        ///     Callback when the connection with the Desktop has closed.
        /// </summary>
        void onClosed();

        /// <summary>
        ///     Callback when client cannot start or connect to the Desktop.
        /// </summary>
        void onError(String reason);

        /// <summary>
        ///     Callback when a message is sent to this client.
        /// </summary>
        void onMessage(String message);

        /// <summary>
        ///     Callback when a message is sent from this client.
        /// </summary>
        void onOutgoingMessage(String message);
    }
}
