﻿/*
 * File NotificationOptions.cs part of the AppDesktop C# API - http://www.openfin.co
 *
 * Copyright (C) 2014 OpenFin
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Openfin.Desktop
{
    /// <summary>
    ///     Helper object that provides getters/setters for the 
    ///     various options needed for creating a Notification.
    /// </summary>
    public class NotificationOptions
    {
        private JObject options_;
        private AckCallback onClick_ = null;
        private AckCallback onClose_ = null;
        private AckCallback onDismiss_ = null;
        private AckCallback onError_ = null;
        private AckCallback onMessage_ = null;
        private AckCallback onShow_ = null;

        /// <summary>
        ///     Constructs an instance with URL set.
        /// </summary>
        /// <param name="url">The url to set in the underlying JObject.</param>
        public NotificationOptions(String url) 
        {
            options_ = new JObject();
            URL = url;
        }

        // ====================================================================
        // Required
        // ====================================================================

        /// <summary>
        ///     The URL property represents the The URL of the notification.
        ///     <para>Default: An empty string</para>
        /// </summary> 
        /// <value>
        ///     The URL property gets the value of the underlying 
        ///     JObject field, "url".
        /// </value> 
        public String URL
        {
            get { return DesktopUtils.getJSON<String>(options_, "url", ""); }
            set { DesktopUtils.updateJSONValue(options_, "url", value); }
        }

        // ====================================================================
        // Optional
        // ====================================================================

        /// <summary>
        ///     The Message property represents a message to be passed to the 
        ///     Notification upon creation.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The Message property gets the value of the underlying 
        ///     JObject field, "message".
        /// </value> 
        public JObject Message
        {
            get { return DesktopUtils.getJSONObject(options_, "message", null); }
            set { DesktopUtils.updateJSONValue(options_, "message", value); }
        }

        /// <summary>
        ///     The OnClick property represents a function that is called when
        ///     a Notification is clicked.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The OnClick property gets the sored AckCallback.
        /// </value> 
        public AckCallback OnClick
        {
            get { return onClick_; }
            set { onClick_ = value; }
        }

        /// <summary>
        ///     The OnClose property represents a function that is called when
        ///     a Notification is closed.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The OnClose property gets the sored AckCallback.
        /// </value> 
        public AckCallback OnClose
        {
            get { return onClose_; }
            set { onClose_ = value; }
        }

        /// <summary>
        ///     The OnDismiss property represents a function that is called when 
        ///     a Notification is dismissed by swiping to the right.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The OnDismiss property gets the sored AckCallback.
        /// </value> 
        public AckCallback OnDismiss
        {
            get { return onDismiss_; }
            set { onDismiss_ = value; }
        }

        /// <summary>
        ///     The OnError property represents a function that is called when 
        ///     an error occurs. The reason for the error is passed as an 
        ///     argument.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The OnError property gets the sored AckCallback.
        /// </value> 
        public AckCallback OnError
        {
            get { return onError_; }
            set { onError_ = value; }
        }

        /// <summary>
        ///     The OnMessage property represents a function that is called
        ///     whenever a notification sends a message.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The OnMessage property gets the sored AckCallback.
        /// </value> 
        public AckCallback OnMessage
        {
            get { return onMessage_; }
            set { onMessage_ = value; }
        }

        /// <summary>
        ///     The OnShow property represents a function that is called when
        ///     a Notification is shown.
        ///     <para>Default: null</para>
        /// </summary> 
        /// <value>
        ///     The OnShow property gets the sored AckCallback.
        /// </value> 
        public AckCallback OnShow
        {
            get { return onShow_; }
            set { onShow_ = value; }
        }

        /// <summary>
        ///     The Timeout property represents the time for which a
        ///     notification is displayed in milliseconds.
        ///     <para>
        ///         When set to -1 the notification will remain until 
        ///         explicitly closed by the API or user.
        ///     </para>
        ///     <para>Default: 3000</para>
        /// </summary> 
        /// <value>
        ///     The Timeout property gets the value of the underlying 
        ///     JObject field, "timeout".
        /// </value> 
        public int Timeout
        {
            get { return DesktopUtils.getJSONInt(options_, "timeout", 3000); }
            set { DesktopUtils.updateJSONValue(options_, "timeout", value); }
        }

    }
}
