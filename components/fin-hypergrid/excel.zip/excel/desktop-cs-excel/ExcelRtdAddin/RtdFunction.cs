﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ExcelDna.Integration;
using ExcelDna.Integration.Rtd;

using Excel = Microsoft.Office.Interop.Excel;

using System.Reflection;
using System.Diagnostics;



namespace Openfin.RTDAddin
{
    public static class RtdFunction
    {


        [ExcelFunction(Name = "FinDesktop")]
        public static object FinDesktop(string appId, string topic, string param)
        {
			return XlCall.RTD("Openfin.RTDAddin.SubscriptionRtdServer", null, appId, topic, param);
        }


        [ExcelFunction(Name = "FinDesktopSync")]
        public static object FinDesktopSync(string appId, string topic, string param)
        {   
			// Synchronise a group of cells which are selected in the grid with excel, updates from
			// excel are pushed back to the grid for the active region.
			return XlCall.RTD("Openfin.RTDAddin.SelectionRtdServer", null, appId, topic, param);

        }
    }
}
