﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Runtime.InteropServices;
using System.Linq;

using ExcelDna.Integration;
using ExcelDna.Integration.Rtd;

using System.Reflection;
using System.Diagnostics;

using Excel = Microsoft.Office.Interop.Excel;

using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;

using Openfin.Desktop;


namespace Openfin.RTDAddin
{

	public enum RtdRequestState
	{
		None,
		Pending,
		Connected,
		Disconnected,
	}


	public class RtdRequest
	{
		public RtdRequest(ExcelRtdServer.Topic topic, IList<String> topicInfo, RtdRequestState state=RtdRequestState.None) 
		{
			this.Topic = topic;
			this.TopicInfo = topicInfo;
			this.State = state;
		}

		public ExcelRtdServer.Topic Topic;
		public IList<String> TopicInfo;
		public RtdRequestState State;


	}

	public enum DesktopRtdState
	{
		None,
		Ready,
		Closed,
		Error,
	}

	public abstract class DesktopRtdServer : ExcelRtdServer, DesktopStateListener
	{

		public DesktopRtdState State = DesktopRtdState.None;

		protected Openfin.Desktop.DesktopConnection controller;
		protected Openfin.Desktop.Application application;
		protected List<RtdRequest> requests;


		protected override bool ServerStart()
		{
			requests = new List<RtdRequest>();
			controller = new DesktopConnection(getDesktopAppId(), "localhost", 9696);
			controller.connect(this);

			return true;
		}

		protected override void ServerTerminate()
		{
			this.controller.disconnect();
		}

		protected override object ConnectData(Topic topic, IList<string> topicInfo, ref bool newValues)
		{
			// The Topic identifies the RTD cell, which unfortunately conflicts with our internal use of a pub/sub 
			// bus, for which we use an app id and topic so that is abstracted out into the SubscriptionRtdServer
			// which encapsulates the Subscription and hides the underlying details of the RTD connection.

			RtdRequest request = new RtdRequest(topic, topicInfo); 
			if (State == DesktopRtdState.Ready)
			{
				request.State = RtdRequestState.Connected;
				this.requests.Add(request);
				connectRequest(request);
			}
			else
			{
				request.State = RtdRequestState.Pending;
				this.requests.Add(request);
			}

			return "";
				
		}

		protected override void DisconnectData(Topic topic)
		{
			foreach(RtdRequest request in this.requests)
			{
				request.State = RtdRequestState.Disconnected;
				disconnectRequest(request);
			}
		}

		protected virtual String getDesktopAppId()
		{
			// Return the application id for use with this OpenFin connection
			return "DesktopRtdServer";
		}

		public void onReady()
		{
			// Connection authorized, application ready
			this.State = DesktopRtdState.Ready;
			foreach (RtdRequest request in requests)
			{
				if (request.State == RtdRequestState.Pending)
				{
					request.State = RtdRequestState.Connected;
					connectRequest(request);
				}
			}
		}

		public void onClosed()
		{
			this.State = DesktopRtdState.Closed;
		}

		public void onError(String reason)
		{
			this.State = DesktopRtdState.Error;
			Console.WriteLine("onError: {0}", reason);
		}

		public void onMessage(String message)
		{
			Console.WriteLine("onMessage: {0}", message);
		}

		public void onOutgoingMessage(String message)
		{
			Console.WriteLine("onOutgoingMessage: {0}", message);
		}

		protected virtual void connectRequest(RtdRequest request)
		{

		}

		protected virtual void disconnectRequest(RtdRequest request)
		{

		}
	}



	public class Subscription
	{
		public RtdRequest Request;

		public Subscription(RtdRequest request)
		{
			this.Request = request;
		}

		public String AppId {get {return Request.TopicInfo[0];}}
		public String Topic {get {return Request.TopicInfo[1];}}

		public String Key 
		{ 
			get 
			{
				return CreateKey(AppId, Topic);  
			} 
		}

		public static String CreateKey(string uuid, string topic)
		{
			return uuid + "/" + topic;
		}
	}


	public class SubscriptionRtdServer : DesktopRtdServer
	{
		protected Dictionary<String, HashSet<Subscription>> subscriptions = new Dictionary<string, HashSet<Subscription>>();
	   
		protected override void connectRequest(RtdRequest request)
		{
			Subscription sub = new Subscription(request);

			HashSet<Subscription> set;
			if (!this.subscriptions.TryGetValue(sub.Key, out set))
			{
				set = new HashSet<Subscription>();
				this.subscriptions.Add(sub.Key, set);
				subscribe(sub);
			}

			set.Add(sub);
		}


		protected override void disconnectRequest(RtdRequest request)
		{
			Subscription sub = new Subscription(request);

			foreach (KeyValuePair<String, HashSet<Subscription>> pair in this.subscriptions)
			{
				foreach (Subscription subscription in pair.Value)
				{
					if (sub.Topic == subscription.Topic)
					{
						pair.Value.Remove(subscription);
						unsubscribe(subscription);
						break;
					}
				}
			}
		}


		protected virtual void subscribe(Subscription sub)
		{
			controller.getInterApplicationBus().subscribe(sub.AppId, sub.Topic, processMessage);
		}

		protected virtual void unsubscribe(Subscription sub)
		{
			controller.getInterApplicationBus().unsubscribe(sub.AppId, sub.Topic, processMessage);
		}


		protected virtual void processMessage(String sourceUuid, String topic, object message)
		{
			// Callback for messages received from OpenFin InterApplicationBus
			JObject jMessage = (JObject)message;
			HashSet<Subscription> set;
			if (this.subscriptions.TryGetValue(Subscription.CreateKey(sourceUuid, topic), out set))
			{
				foreach (Subscription subscription in set)
				{
					subscription.Request.Topic.UpdateValue(message.ToString());
				}
			}
			else
			{
				Console.WriteLine("Missing topic {0}", topic);
			}
		}
	}



	public class Selections
	{
		public double Now {get;set;}
		public List<Selection> Selection { get; set; }
	}

	public class Selection
	{
		public List<int> Region { get; set; }
		public List<object> Values { get; set; }
	}


	public class SelectionRtdServer : SubscriptionRtdServer
	{

		protected const String TOPIC_ON_SELECT = "onSelect";
		protected const String TOPIC_ON_EXCEL_CHANGE = "onExcelChange";
		
		// We cache the region so that we know when the selection has changed.  If its a single cell
		// then the change event will have the same dimensions so we cache the value in this case.
		protected List<int> region = new List<int>();
		protected object value = null;

		protected Excel.Application xlApp = null;
		protected Excel.Worksheet xlSheet = null;

		public SelectionRtdServer()
		{
			xlApp = (Excel.Application) ExcelDnaUtil.Application;
			xlSheet = (Excel.Worksheet)xlApp.ActiveWorkbook.Sheets[1];

			try
			{
                xlApp = (Excel.Application)ExcelDnaUtil.Application;
                Excel.Workbook book = xlApp.ActiveWorkbook;
                // book.SheetChange += new Excel.WorkbookEvents_SheetChangeEventHandler(OnBookSheetChange);
                Excel.Sheets sheets = book.Sheets;
                for (int i = 1; i <= sheets.Count; i++)
                {
                    var sheet = sheets[i];
                    ((Excel.DocEvents_Event)sheet).Change += new Excel.DocEvents_ChangeEventHandler(OnSheetChanged);
                }
            }
            catch (Exception e)
            {
                System.Console.WriteLine("Error accessing Excel: '{0}' ", e);
            }
            System.Console.WriteLine("Listening to changes from worksheet");

		}


		protected override void processMessage(String sourceUuid, String topic, object message)
		{
			JObject json = (JObject) message;
			if (topic.Equals(TOPIC_ON_SELECT))
			{
				try
				{
					// {
 					//	now:21234123, 
					//	selection: [ 
					//		{ "region": [ 1, 1, 3, 3 ], "values": [ 0.1, 0.25, 0.3, 0.6, 0.12, 1.5, 3.5, 2.1, 1.1 ] }, 
					//		{ "region": [ 10, 10 ], "values": [ 10.1 ] } ] }
						
					Selections selections = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Selections>((string)message.ToString());
					List<int> region = selections.Selection[0].Region;
					List<object> values = selections.Selection[0].Values;

					
					// Unix timestamp, only limited accuracy but better than nothing since .net doesn't expose
					// high resolution timers without going to the win32 dll's but its available in JavsScript 
					// via performance.now()
					double unixTimestamp = (DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalMilliseconds;

					// If were out by more than 1 second then dump the message as we dont want a backlog
					if (unixTimestamp > selections.Now+1000)
						return;

					bool change = false;
					for (int i = 0; i < region.Count; ++i)
					{
						//if (i >= this.region.Count || this.region[i] != region[i])
						if (!this.region.SequenceEqual(region))
						{
							change = true;
							break;
						}
					}

					if (change)
					{
						// Clear all cells if the region has changed
						if (this.region.Count == 4)
						{
							int r1 = this.region[0], r2 = this.region[2];
							int c1 = this.region[1], c2 = this.region[3];
							int cols = c2 - c1+1, rows = r2 - r1+1;

                            string[,] data = new string[rows, cols];

							// The rows and cols are absolute from the grid but must be offset to 0 for the
							// data we are going to bulk write to a given range, so this can be done either way.
							// For consistency and easy of understanding, we use the long form here so its the
							// same looping logic everywhere and the concept is clear...

							//for (int row = 0; row < rows; ++row)
							//	for (int col = 0; col < cols; ++col)
                            //        data[row,col] = "";
                           
							for (int row=r1;row<=r2;++row)
	                        {
								for (int col=c1;col<=c2;++col)
								{
									int r = row - r1;
									int c = col - c1;
									data[r,c] = "";
								}
							}

							// Bulk write the data from start to end coordinates using an Excel style
							// alphanumeric row/col reference id.
							
                            //string id = colCode(c1) + "" + r1 +":" + colCode(c2) +""+ r2;
							//xlSheet.Range[id].Value = data;	

                            var from = (Excel.Range)xlSheet.Cells[r1,c1];
                            var to = (Excel.Range)xlSheet.Cells[r2,c2];
                            xlSheet.Range[from, to].Value = data;

						}
						else
						if (this.region.Count == 2)
						{
							//string id = colCode(this.region[1]) + "" + this.region[0];
							//xlSheet.Range[id].Cells[1, 1] = "";

                            var from = (Excel.Range)xlSheet.Cells[this.region[0], this.region[1]];
                            var to = (Excel.Range)xlSheet.Cells[this.region[0], this.region[1]];
                            xlSheet.Range[from,to].Value = "";

						}

						this.region = region;
					}



					// Write new values to cells, having cleared the previous ones...

					if (region.Count == 4)
					{
						int r1 = region[0], r2 = region[2];
						int c1 = region[1], c2 = region[3];
						int cols = c2 - c1+1, rows = r2 - r1+1;

                        object[,] data = new object[rows, cols];

                        for (int row=r1;row<=r2;++row)
                        {
                            for (int col=c1;col<=c2;++col)
                            {
                                // Starting at col A set cell values to values...
                                int r = row - r1;
                                int c = col - c1;
                                int index = ((r)*cols)+(c);

								data[r, c] = values[index].ToString();
                            }
                        }

						//string id = colCode(c1) + "" + r1 + ":" + colCode(c2) + "" + r2;
						//xlSheet.Range[id].Value = data;	
                        var from = (Excel.Range)xlSheet.Cells[r1, c1];
                        var to = (Excel.Range)xlSheet.Cells[r2, c2];
                        xlSheet.Range[from, to].Value = data;
                        
                        value = null;
					}
					else
					if (region.Count == 2)
					{
						// For fun, set the single cell to the same exact cell number...
						//string id = colCode(region[1]) +""+ region[0];
                        //xlSheet.Range[id].Cells[1, 1] = values[0].ToString();

                        var from = (Excel.Range)xlSheet.Cells[this.region[0], this.region[1]];
                        var to = (Excel.Range)xlSheet.Cells[this.region[0], this.region[1]];
                        xlSheet.Range[from, to].Value = values[0].ToString();						
                        
                        value = values[0];
					}

				}
				catch (Exception ex)
				{
					Debug.WriteLine(ex.StackTrace);
					Debug.WriteLine(ex.Message);
					
				}
			}
			else
			{
				base.processMessage(sourceUuid, topic, message);
			}
		}


		private string colCode(int col) 
		{
			// Taken from grid.html JavaScript code for producing an alpha col code from numeric code

			// Name the column headers in A, .., AA, AB, AC, .., AZ format
			// quotient/remainder
			int quo = (int)Math.Floor((double)((col-1)/26));
			int rem = (col - 1) % 26;

			string code = "";
			if (quo > 0)
				code += (char)((int)'A'+quo-1);
			code += (char)((int)'A'+rem);		
			return code;
		}

		public void OnBookSheetChange(object sh, Excel.Range target)
        {
            Debug.WriteLine("OnBookSheetChange: "+ sh.ToString() +" "+ target.ToString());
            foreach (Excel.Range cell in target.Cells)
            {
                string address = cell.get_Address(Type.Missing, Type.Missing, Excel.XlReferenceStyle.xlA1, Type.Missing, Type.Missing);
                Debug.WriteLine("Worksheet {0}, Address: {1}, Fromula: {2}, Value: {3}, Value2: {4}", 
					target.Worksheet.Name,address, cell.Formula.ToString(),cell.Value.ToString(),cell.Value2.ToString());
            }
        }

        public void OnSheetChanged(Excel.Range target)
        {
            try
            {
				int[] region;
				var from = target.Cells[1];
				var to = target.Cells[target.Cells.Count];
				if (target.Cells.Count == 1)
					region = new int[]{from.Row,from.Column};
				else
					region = new int[]{from.Row,from.Column,to.Row,to.Column};

				// If the changed region is the region we just updated from the grid then this is not 
				// a real change that we want to publish. If it was a single cell update then the region
				// will always be the same so we check that the value hasn't changed.
				if (this.region == null || 
					(this.region.SequenceEqual(region) && (value == null || value.ToString() == target.Cells[1].Value.ToString())))
					return;


                JObject message = new JObject();
                DesktopUtils.updateJSONValue(message, "workSheet", target.Worksheet.Name);
                JArray cells = new JArray();
                for (int i = 1; i <= target.Cells.Count; i++)
                {
                    JObject obj = new JObject();
                    Excel.Range cell = target.Cells[i];
                    
                    DesktopUtils.updateJSONValue(obj, "row", cell.Row);
                    DesktopUtils.updateJSONValue(obj, "column", cell.Column);
                    DesktopUtils.updateJSONValue(obj, "address", cell.Address);

					// Value can be null, thats ok !

					string s = null;
                    if (cell.Value != null)
                        s = cell.Value.ToString();
                    
					double d;
					if (s != null && Double.TryParse(s, out d))
						DesktopUtils.updateJSONValue(obj, "value", d); 
					else
						DesktopUtils.updateJSONValue(obj, "value", s); 
                    
                    cells.Add(obj);
                }
                DesktopUtils.updateJSONValue(message, "cells", cells);
                controller.getInterApplicationBus().publish(TOPIC_ON_EXCEL_CHANGE, message);
            }
            catch (Exception e)
            {
                System.Console.WriteLine("Error publishing Excel: '{0}' ", e);
            }            
        }

	}


}