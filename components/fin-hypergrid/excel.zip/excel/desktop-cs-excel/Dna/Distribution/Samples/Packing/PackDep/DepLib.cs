public class SomeDepClass
{
    public static string OtherMessage()
    {
        return "Hello from The Other Lib (SomeDepClass.OtherMessage)";
    }
}
