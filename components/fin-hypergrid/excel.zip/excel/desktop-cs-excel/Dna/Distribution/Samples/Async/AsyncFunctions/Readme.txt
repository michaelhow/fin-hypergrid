The AsyncFunctions project contains samples for the RTD-based asynchronous function support in Excel-DNA.

This includes an easy path to integrate the Reactive Extensions into your Excel add-in - an Observable can by published as a 'live' UDF in Excel.

To rebuild, you should ensure that the Rx-Main package is installed from NuGet, then recompile to create AsyncFunctions.xll.
There is also an Excel test file called AsyncFunctionsTest.xlsx.